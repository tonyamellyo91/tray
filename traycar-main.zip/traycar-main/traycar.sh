#!/bin/bash
bash tray-logo.sh
echo ""
echo ""
printf "\e[100;330m[\e[10m **** ]\e[1;40m\e[10m Desenvolvedor: Tony Amellyo, Luziania-GO, Brazil :\e[1;32m Especialista em softwares para seguranca & estrutura para empresas !\e[0m"
sleep 4
echo ""
echo""
echo""
echo ""
echo ""
echo ""
read -p $'\e[1;40m\e[96m FERRAMENTA DISPONIVEL APENAS PARA TESTES! É EXTREMAMENTE PROIBIDA A ALTERACAO DO CODIGO FONTE, CONCORDA ? \e[1;91m (Y/N) : \e[0m' option
echo""
echo""
echo""

if [[ $option == *'N'* ]]; then
clear
exit
fi
if [[ $option == *'n'* ]]; then
clear
exit
fi

php="$(ps -efw | grep php | grep -v grep | awk '{print $2}')"
ngrok="$(ps -efw | grep ngrok | grep -v grep | awk '{print $2}')"
kill -9 $php
kill -9 $ngrok
clear
        bash tray-logo.sh
        cat membros.txt | lolcat
        echo ""
        echo ""

                 echo -e $'\e[1;33m[\e[0m\e[1;33m *** \e[0m\e[1;96m]\e[0m\e[1;96m    -----------------      \e[1;33m  [ ]\e[0m'
                 read -p $'\e[1;91m[\e[0m\e[1;91m *** \e[0m\e[1;96m]\e[0m\e[1;96m    Escolha uma opcao  \e[1;91m  > > > > > \e[0m' option
                 echo ""
                 if [ $option = 01 ] || [ $option = 1 ]
                 then
                           cd membros/
                           cd tony/
			   read -sp $'\e[1;91mDigite a senha: \e[0m' input_password
  			   echo ""
    			   saved_password=$(cat password.txt)

   			   if [ "$input_password" == "$saved_password" ]; then
       			   echo "Autenticação bem-sucedida!"
			        sleep 3
				clear
         			bash  tray-logo.sh
			        # Exibir o menu1.txt
       			        cat menu1.txt | lolcat
       			        echo ""
       			   	echo ""

		           	# Lógica para tratar a opção selecionada no menu1.txt
       			   	read -p $'\e[1;91mEscolha uma opcao: \e[0m' sub_option
		           	case $sub_option in
           		   	01|1)
               		   	echo "Opção 1 selecionada: Pré análise"
               		   	# Adicione aqui os comandos para a opção "Pré análise"
               		   	;;
           		   	02|2)
               	           	echo "Opção 2 selecionada: Fichas"
            		   	# Adicione aqui os comandos para a opção "Fichas"
              		   	;;
           		   	03|3)
              		   	echo "Opção 3 selecionada: Vendas/caixa"
            		   	# Adicione aqui os comandos para a opção "Vendas/caixa"
              		   	;;
           		   	04|4)
               	       	   	echo "Opção 4 selecionada: Desempenho"
              		   	# Adicione aqui os comandos para a opção "Desempenho"
               		   	;;
           		   	*)
              		   	echo "Opção inválida."
              		   	;;

       			   esac
   			   else
       			   echo "Senha incorreta. Acesso negado."
       		           exit 1
   			   fi
		      	   fi
