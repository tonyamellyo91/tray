/**
 * Prop�sito: Scripts js do componente UIFontSize
 * 
 * Descri��o: Arquivo que define o comportamento do componente
 */
var $jB = jQuery.noConflict();
function UICollapsible (triggerElements, collapsibleElements, 
		closingOnTriggerElements,effect,eventType,collapsed,delay,speed,callbackBefore, callbackAfter,parentID) {
	
	this.triggerElements = triggerElements;
	this.collapsibleElements = collapsibleElements;
	this.closingOnTriggerElements =closingOnTriggerElements;
	this.effect = effect;
	this.eventType = eventType;
	this.collapsed = collapsed;
	this.delay = delay;
	this.callbackAfter = callbackAfter;
	this.callbackBefore = callbackBefore;
	this.speed = speed;
	this.parentID = parentID;
	
	this.componentState = null;
	
	this.getComponentState = function () {
		try {
		this.componentState = new Function ('return componentState_'+this.parentID+';')();
		} catch (e) {}
	};
	
	this.isCollapsed = function ()
	{
		if ($jB(this.collapsibleElements).css ("display")=='none') {
				this.collapsed = true;
		}
		return this.collapsed;
	};
	
	
	this.readExternalState = function () {
		
		var state = null;
		if (this.componentState==null)
			return;		
		var param = new Object ();		
		param['asyncObj']=this;
		param['asyncFunc']=this.restoreState;
		state = this.componentState.readState (param);
		this.restoreState(state);	
	};
	
	this.restoreState = function (state) {
		if (state==null)
			return;
		if (state['collapsed']!=null)
			if (state['collapsed']=='true')
				this.collapsed = true;
			else
				this.collapsed = false;	
		this.execCollapsable (!this.collapsed);
		
	};
	
	this.saveExternalState = function () {
		var state = new Object ();
		if (this.componentState==null)
			return;		
		state['collapsed'] = ''+ this.collapsed;
		this.componentState.saveState (state);
		
	}
	
	this.init = function () {
	
		
		var obj = this;	
		this.execCollapsable = function(collapse){
			try	{			
				if (collapse!=null)
					obj.collapsed=collapse;
				if (obj.collapsed==true) {
					if (obj.effect == 'show/hide') {
						try { if (obj.callbackBefore!=null) obj.callbackBefore (false,obj); } catch (err) {}
						if (obj.callbackAfter==null) {
							try {$jB(obj.collapsibleElements).show (obj.speed);} catch (err) {}
						} else {
							try {$jB(obj.collapsibleElements).show (obj.speed, function () { obj.callbackAfter (false,obj); } );} catch (err) {}
						}
						if (obj.closingOnTriggerElements!=null )
							try {$jB(obj.closingOnTriggerElements).hide (obj.speed);    } catch (err) {}
					}
					if (obj.effect == 'slide') {
						try { if (obj.callbackBefore!=null) obj.callbackBefore (false,obj) ;} catch (err) {}
						if (obj.callbackAfter==null) {
							try {$jB(obj.collapsibleElements).slideDown (obj.speed);} catch (err) {}
						} else {
							try {$jB(obj.collapsibleElements).slideDown (obj.speed, function () { obj.callbackAfter (false,obj); } );} catch (err) {}
						}
						if (obj.closingOnTriggerElements!=null )
							try {$jB(obj.closingOnTriggerElements).slideUp (obj.speed); } catch (err) {}
					}
					if (obj.effect == 'fade') {
						try { if (obj.callbackBefore!=null) obj.callbackBefore (false,obj); } catch (err) {}
						if (obj.callbackAfter==null) {
							try {$jB(obj.collapsibleElements).fadeIn (obj.speed);} catch (err) {}
						} else {
							try {$jB(obj.collapsibleElements).fadeIn (obj.speed, function () { obj.callbackAfter (false,obj); } );} catch (err) {}
						}
						if (obj.closingOnTriggerElements!=null )
							try {$jB(obj.closingOnTriggerElements).fadeOut (obj.speed); } catch (err) {}
					}
					obj.collapsed=false;
				} else {
					if (obj.effect == 'show/hide') {
						try { if (obj.callbackBefore!=null) obj.callbackBefore (true,obj); } catch (err) {}
						if (obj.callbackAfter==null) {
							try {$jB(obj.collapsibleElements).hide (obj.speed);} catch (err) {}
						} else {
							try {$jB(obj.collapsibleElements).hide (obj.speed, function () { obj.callbackAfter (true,obj); } );} catch (err) {}
						}
					}
					if (obj.effect == 'slide') {
						try { if (obj.callbackBefore!=null) obj.callbackBefore (true,obj); } catch (err) {}
						if (obj.callbackAfter==null) {
							try {$jB(obj.collapsibleElements).slideUp (obj.speed);} catch (err) {}
						} else {
							try {$jB(obj.collapsibleElements).slideUp (obj.speed, function () { obj.callbackAfter (true,obj); } );} catch (err) {}
						}
					}
					if (obj.effect == 'fade') {
						try { if (obj.callbackBefore!=null) obj.callbackBefore (true,obj); } catch (err) {}
						if (obj.callbackAfter==null) {
							try {$jB(obj.collapsibleElements).fadeOut (obj.speed);} catch (err) {}
						} else {
							try {$jB(obj.collapsibleElements).fadeOut (obj.speed, function () { obj.callbackAfter (true,obj); } );} catch (err) {}
						}
						
					}
					obj.collapsed=true;
				}
				
			} catch (err) {
		
			}
			
		};
		
		this.getComponentState();
		this.readExternalState ();	
		
		if (obj.closingOnTriggerElements!=null)
			if (obj.closingOnTriggerElements=="")
				obj.closingOnTriggerElements = null;
		
		
		
		var fnc = function (collapse) {
			obj.execCollapsable (collapse);
			obj.saveExternalState ();
		}
		
		if (obj.delay==null)
			obj.delay=0;
		
		var timeout = null;
		
		if (this.eventType == 'onClick') {
			try {
				$jB(this.triggerElements).click ( function ()
					{ timeout = setTimeout (function (){fnc(null)},obj.delay) }
				);
			} catch (err) {}
		}
		if (this.eventType == 'onMouseOver') {
			try {	
				$jB(this.triggerElements).hover (
					function (){ timeout = setTimeout (function (){fnc(true)},obj.delay) }
				,
					function (){ clearTimeout (timeout) }
				);
			} catch (err) {}
		}
		if (this.eventType == 'onMouseOver/Out'){
			try {
				$jB(this.triggerElements).hover (
						function (){ timeout = setTimeout (function (){fnc(true)},obj.delay) }
					,
						function (){ clearTimeout (timeout); fnc (false); }
					);
			} catch (err) {}
		}
		
		
		
		//if (obj.collapsed==true && $jB(obj.collapsibleElements).css("display")!="none")
			//fnc (false);
		this.execCollapsable (!this.collapsed);
			
						
	};
};
