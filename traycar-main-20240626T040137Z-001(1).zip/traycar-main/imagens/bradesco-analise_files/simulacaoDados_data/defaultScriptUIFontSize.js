/**
 * Prop�sito: Scripts js do componente UIFontSize
 * 
 * Descri��o: Arquivo que define o comportamento do componente
 */
var $jB = jQuery.noConflict();
function UIFontSize (queryStringElements,componentID, byFontSize, parentID, onFontSelected) {
	
	this.fontMin = 1;
	this.fontMax = 3;
	this.elements = new Array ();
	this.flag = null;
	this.fonteAtual = 1;
	this.queryStringElements = queryStringElements;
	this.componentID = componentID;
	this.byFontSize = byFontSize; 
	this.parentID = parentID;
	this.onFontSelected = onFontSelected;
	
	this.componentState = null;
	
	this.getComponentState = function () {
		try {
		this.componentState = new Function ('return componentState_'+this.parentID+';')();
		} catch (e) {}
	};
	
	this.readExternalState = function () {
		
		var state = null;
		if (this.componentState==null)
			return;		
		var param = new Object ();		
		param['asyncObj']=this;
		param['asyncFunc']=this.restoreState;
		state = this.componentState.readState (param);
		this.restoreState (state);
	};
	
	this.restoreState = function (state) {
		if (state==null)
			return;
		if (state['fontSize']!=null) {			
			this.fonteAtual = parseInt (state['fontSize']);
		}
		this.refreshFontSize ();
		
	}
	
	
	this.saveExternalState = function () {
		var state = new Object ();
		if (this.componentState==null)
			return;		
		state['fontSize'] = ''+ this.fonteAtual;
		this.componentState.saveState (state);
		
	};
	
	this.callOnFontSelected = function (qs, oldClass, newClass) {
		if (this.onFontSelected==null || this.onFontSelected =='')
			return;
		var callback = new Function ('return '+this.onFontSelected+';')();
		if (typeof (callback) != 'function')
			return;
		var param = new Object ();
		param['queryString']=qs;
		param['oldClass']=this.getClass(oldClass);
		param['newClass']=this.getClass(newClass);
		callback(param);
		
		
	};
	
	this.getClass = function (fontSize) {
		if (fontSize==1)
			return "UIFontSize-level-1";
		if (fontSize==2)
			return "UIFontSize-level-2";
		if (fontSize==3)
			return "UIFontSize-level-3";
	};
	
	this.selectFontSize1 = function () {
		this.fonteAtual = 1;
		$jB('#'+this.componentID+"-firstButton").addClass ("UIFontSize-firstButton-li-On");
		$jB('#'+this.componentID+"-secondButton").removeClass ("UIFontSize-secondButton-li-On");
		$jB('#'+this.componentID+"-thirdButton").removeClass ("UIFontSize-thirdButton-li-On");
		
		$jB(this.queryStringElements).addClass ("UIFontSize-level-1");
		$jB(this.queryStringElements).removeClass ("UIFontSize-level-2");
		$jB(this.queryStringElements).removeClass ("UIFontSize-level-3");
	};
	
	this.selectFontSize2 = function () {
		this.fonteAtual = 2;
		$jB('#'+this.componentID+"-firstButton").removeClass ("UIFontSize-firstButton-li-On");
		$jB('#'+this.componentID+"-secondButton").addClass ("UIFontSize-secondButton-li-On");
		$jB('#'+this.componentID+"-thirdButton").removeClass ("UIFontSize-thirdButton-li-On");
		
		$jB(this.queryStringElements).removeClass ("UIFontSize-level-1");
		$jB(this.queryStringElements).addClass ("UIFontSize-level-2");
		$jB(this.queryStringElements).removeClass ("UIFontSize-level-3");
	};
	
	this.selectFontSize3 = function () {
		this.fonteAtual = 3;
		$jB('#'+this.componentID+"-firstButton").removeClass ("UIFontSize-firstButton-li-On");
		$jB('#'+this.componentID+"-secondButton").removeClass ("UIFontSize-secondButton-li-On");
		$jB('#'+this.componentID+"-thirdButton").addClass ("UIFontSize-thirdButton-li-On");
		
		$jB(this.queryStringElements).removeClass ("UIFontSize-level-1");
		$jB(this.queryStringElements).removeClass ("UIFontSize-level-2");
		$jB(this.queryStringElements).addClass ("UIFontSize-level-3");
	};
	
	this.refreshFontSize = function () {
		if (this.fonteAtual==1)
			this.selectFontSize1 ();
		if (this.fonteAtual==2)
			this.selectFontSize2 ();
		if (this.fonteAtual==3)
			this.selectFontSize3 ();
	};
	
	/* Construtor do calendario */
	this.init = function () {
		
		var oldSize = this.fonteAtual;
		
		this.getComponentState ();
		this.readExternalState ();
		
		var obj = this;
		
		this.callOnFontSelected (obj.queryStringElements, oldSize, this.fonteAtual);
		this.refreshFontSize ();
		
		/* adiciona os eventos nos bot�es */
		$jB('#'+this.componentID+"-firstButton").click(function(){
			var oldSize = obj.fonteAtual;
			obj.selectFontSize1 ();		
			obj.saveExternalState();
			obj.callOnFontSelected (obj.queryStringElements, oldSize, obj.fonteAtual);
		});
		
		
		$jB('#'+this.componentID+"-secondButton").click(function(){
			var oldSize = obj.fonteAtual;
			obj.selectFontSize2 ();	
			obj.saveExternalState();
			obj.callOnFontSelected (obj.queryStringElements, oldSize, obj.fonteAtual);		
		});
		
		$jB('#'+this.componentID+"-thirdButton").click(function(){
			var oldSize = obj.fonteAtual;
			obj.selectFontSize3 ();	
			obj.saveExternalState();
			obj.callOnFontSelected (obj.queryStringElements, oldSize, obj.fonteAtual);

		});
		
						
	};
};
