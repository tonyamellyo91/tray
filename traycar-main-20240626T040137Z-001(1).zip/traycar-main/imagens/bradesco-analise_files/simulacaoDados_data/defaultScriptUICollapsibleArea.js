/**
 * Prop�sito: Scripts js do componente UIHelp
 * 
 * Descri��o: Arquivo que define o comportamento do componente
 */
var $jB = jQuery.noConflict();
function UICollapsibleArea () {
	
	//callback chamada antes do evento de abertura da janela de help
	this.callbackBefore = function (collapsing, uicollapsible ) 
	{
		if (!collapsing)
			$jB(uicollapsible.triggerElements).addClass ("active");
		
	};
	
	//callback chamada antes do evento de abertura da janela de help
	this.callbackAfter = function (collapsing, uicollapsible ) 
	{		
		if (collapsing)
			$jB(uicollapsible.triggerElements).removeClass ("active");		
	};
};
