var ajxCoparam = [];
// valores
var isCompleta = false;
var indexProd = 0;
jQuery(document).ready(function() {
	
	// Desabilita a fun��o padr�o do ENTER
	jQuery(document).keypress(function(event) {
		if (event.which == '13') {
			event.preventDefault();
		}
	});
	verificarParcelaBalaoFixa();
	// Configurando mascaras
	jQuery("input[class*='perc']").each(function(event) {
		var reg = new RegExp("perc(\\d*)", "gi");
		var match = reg.exec(jQuery(this).attr("class"));
		if (match != null) {
			jQuery(this).bind("keypress", function(event) {
				_percKeyPress(jQuery(this), event, parseInt(match[1]));
			}).bind("blur", function() {
				_percBlur(jQuery(this), parseInt(match[1]));
			}).bind("focus", function() {
				var zeroValue = "0,";
				var scale = parseInt(match[1]);
				for (var i = 0; i < scale; i++) {
					zeroValue += "0";
				}
				if (jQuery(this).val() == zeroValue) {
					jQuery(this).val("");
				}
				jQuery(this).select();
			});

			if (jQuery(this).val() == "") {
				var zeroValue = "0,";
				var scale = parseInt(match[1]);
				for (var i = 0; i < scale; i++) {
					zeroValue += "0";
				}
				jQuery(this).val(zeroValue);
			}
		}
		
	});
	if (window.parent.autoIframe) {
		window.parent.autoIframe();
	}
});

// ao finalizizar o carregamento da pagina
jQuery(window).load(function() {
	setTimeout(function() {
		acertarToolTip();
	}, 2000);
	verificarParcelaBalaoFixa();
	validarExibicaoBtnAvancar();
});

function ajxCleanCombo() {
	for (var i = 0; i < arguments.length; i++) {
		_cleanCombo(arguments[i]);
	}
}

function ajxError(req, status) {
	if (status != "timeout") {
		if (req.status == 400) {
			const regex = /^[a-zA-Z0-9 _.,!"'/$]*$/;
			  if (!regex.test(req.responseText)) {
			    console.error('Invalid characters detected');
			    return null;
			  }
			  else {
				  const sanitizedJsonString = jsonString.replace(/'/g, '"');
				  let jsonData = null;
				  try {
				    jsonData = JSON.parse(sanitizedJsonString);
				    exibirErro(jsonData.id, jsonData.msg);
					document.getElementById(jsonData.id).focus();
				  } catch (e) {
				    console.error('Error parsing JSON:', e.message);
				  }			  
			  }

		}
	}
}

function ajxDisableFields() {
	for (var i = 0; i < arguments.length; i++) {
		document.getElementById(arguments[i]).disabled = true;
	}
}

function ajxUndisableFields() {
	for (var i = 0; i < arguments.length; i++) {
		document.getElementById(arguments[i]).disabled = false;
	}
}

function ajxCleanField() {
	var elem = null;
	for (var i = 0; i < arguments.length; i++) {
		elem = jQuery(document.getElementById(arguments[i]));
		if (!elem.is(":disabled")) {
			elem.val("");
			_cleanHiddenValues(elem);
		}
	}
}

function _cleanCombo(id) {
	var element = document.forms['frm'].elements[id];
	element.options.length = 1;
	_cleanHiddenValues(jQuery(element));
}

function _cleanHiddenValues(element) {
	var elemParent = element.parent();

	var hvl = elemParent.find("#frm\\:hvl_" + element.attr("id"));
	if (hvl != null) {
		hvl.val("");
	}

	var hdesc = elemParent.find("#frm\\:hdesc_" + element.attr("id"));
	if (hdesc != null) {
		hdesc.val("");
	}
}

function ajxCreateCombo(id, lista) {
	var item = null;
	var combo = jQuery('#' + id);
	for (var i = 0; i < lista.length; i++) {
		item = lista[i];
		combo.append(jQuery("<option></option>").attr("value", item.value).text(jQuery("#boxHelper").html(item.label).text()));
	}

}

// Loading
function showLoading(id) {
	jQuery("#" + id).show();
}

function hideLoading(id) {
	jQuery("#" + id).hide();
}

/**
 * trim function
 * 
 */
String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g, "");
};

/**
 * Exibe o erro no padr�o AWB e define o foco no campo de origem do erro. Caso o
 * erro foi exibido, deve permitir a navega��o normal e n�o dar foco no campo de
 * origem do erro.
 */
function exibirErroFoco(id, msg, focoJQuery) {
	var elem = document.getElementById(id);
	if (jQuery(elem).parents(".campos_form").hasClass("form_erro")) {
		exibirErro(id, msg);
		return;
	} else {
		exibirErro(id, msg);
		if (focoJQuery != null) {
			setTimeout(function() {
				jQuery(focoJQuery).focus();
			}, 10);
		} else {
			setTimeout(function() {
				elem.focus();
			}, 10);
		}
	}
}

function stopEvent(event) {
	if (event != null) {
		if (event.preventDefault)
			event.preventDefault();
		else
			event.returnValue = false;
	}
}

jQuery.fn.serializeDisabled = function() {
	var obj = {};
	obj[jQuery(this).attr("name")] = jQuery(this).val();
	return jQuery.param(obj);
};

function habilitarCampoCombo() {
	if (arguments.length == 1) {
		jQuery("#frm\\:" + campo).attr("disabled", false);
	} else if (arguments.length > 1) {
		for (var i = 0; i < arguments.length; i++) {
			if (jQuery("#frm\\:" + arguments[i]).val() == '9999') {
				if (jQuery("#frm\\:" + arguments[i + 1]).attr("type") == 'select-one') {
					jQuery("#frm\\:" + arguments[i + 1]).val('9999');
				}
				desabilitarCampo(arguments[i + 1]);
			} else {
				habilitarCampo(arguments[i + 1]);
			}
		}
	}
}

function habilitarCampo(campo) {
	jQuery("#frm\\:" + campo).attr("disabled", false);
}

function desabilitarCampo(campo) {
	jQuery("#frm\\:" + campo).attr("disabled", true);
}

function verificarSelecaoTodosProdutosAvulsos(element) {
	isCompleta = false;
	jQuery("#hiddenRadioCombo").val("");
	jQuery("#hiddenHtmlRadioCombo").val(element.id);
	nextElementSibling(element).value = element.checked;
	var combos = document.getElementsByName("radioComboSelecionado");
	for (var i = 0; i < combos.length; i++) {
		nextElementSibling(combos[i]).value = false;
	}
	nextElementSibling(element).value = true;
	if (element.id == "radioProdutosAvulsos") {
		list = jQuery(".produtoAvulsos");
		list.each(function(index, element) {
			element.checked = true;
			element.value = true;
		});
	} else {
		list = jQuery(".produtoAvulsos");
		list.each(function(index, element) {
			if (document.getElementById("hiddenCalcularAtivado").value == true || document.getElementById("hiddenCalcularAtivado").value == 'true') {
				alterarPMTCmbAvulso();
				el = document.getElementById(element.id);
				idMsg = element.id.replace('produtoSelecionado', 'msgProduto');
				if (el.className.indexOf('tipo4') !== -1) {
					if (el.checked == false) {
						idVrProduto = el.className.substring(el.className.indexOf('idProd') + 6, el.className.length);
						if (jQuery("#hiddenFlagCalculado").val() == 'true') {
							document.getElementById(idMsg).style.display = 'inline';
						}
						if (document.getElementById("vrProdutoAvulso" + idVrProduto) != null) {
							document.getElementById("vrProdutoAvulso" + idVrProduto).style.display = 'none';
						}
					}
				}
			}
			element.checked = false;
			element.value = false;
		});
	}
}

function nextElementSibling(element) {
	var element2 = element.nextSibling;
	while (element2.nodeType != 1) {
		element2 = element2.nextSibling;
	}
	return element2;
}

function finalizarSelecaoProdutosAlvusos() {
	if (isCompleta) {
		list = jQuery(".produtoAvulsos");
		list.each(function(index, ele) {
			ele.checked = false;
		});
		if (!list[indexProd].checked) {
			list[indexProd].checked = true;
		} else {
			list[indexProd].checked = false;
		}
	}

	if (document.getElementById("hiddenCalcularAtivado").value == true || document.getElementById("hiddenCalcularAtivado").value == 'true') {
		list = jQuery(".produtoAvulsos");
		list.each(function(index, element) {
			el = document.getElementById(element.id);
			idMsg = element.id.replace('produtoSelecionado', 'msgProduto');
			if (el.className.indexOf('tipo4') !== -1) {
				idVrProduto = el.className.substring(el.className.indexOf('idProd') + 6, el.className.length);
				if (jQuery("#hiddenFlagCalculado").val() == 'true') {
					document.getElementById(idMsg).style.display = 'inline';
				}
				document.getElementById("vrProdutoAvulso" + idVrProduto).style.display = 'none';
			}
		});
	}
	acertarToolTip();
}

function esconderBotaoAvancar() {
	document.getElementById('frm:botaoAvancar').style.display = 'none';
}

function mostrarBotaoAvancar() {
	document.getElementById('frm:botaoAvancar').style.display = '';
}

function validarExibicaoBtnAvancar() {
	if (jQuery("#frm\\:divSelectParcelasBalao").is(":visible")) {
		if (jQuery("#frm\\:cmbNumeroParcelaBalao").val() == '-1' || jQuery("#msgErroValidacao").val() != '') {
			esconderBotaoAvancar();
		}else{
			mostrarBotaoAvancar();
		}
	}else{
		if (verificarRadioPrazoSelecionado() && jQuery("#msgErroValidacao").val() == ''){
			mostrarBotaoAvancar();
		}else{
			esconderBotaoAvancar();
		}
	}
}

function verificarRadioPrazoSelecionado(){
	var radio = document.forms['frm']['frm:radioPlanoParcelaFixa'];
	// Tratamento para quando o radio tiver apenas um registro no array,
	// pois nesse caso o javascript trata como um objeto s�, e n�o como uma lista.
	if( typeof radio.length == 'undefined' && typeof radio != 'undefined' ){
		radio = [radio];
	}
	
	for (var i=0 ; i < radio.length ; i++){
		if (radio[i].checked){
			return true;
		}
	}
	return false;
}

function validarErroCampos() {
	var errBoxes = jQuery("div.form_erro");
	if (errBoxes.length > 0 && errBoxes.find(":input").attr("id") != "frm:valorBem" && errBoxes.find(":input").attr("id") != "frm:valorSeguro") {
		errBoxes.find(":input").first().focus();
		return true;
	}
	return false;
}

function mostrarLupaProdutos() {
	document.getElementById('frm:btnModalVisivel').style.display = '';
}

/**
 * Obter o retorno m�ximo.
 */
function obterRetMax(elem) {
	var cdcRet = jQuery("#frm\\:cmbTabelaFaixaProdutoCdc").val();
	var leasingRet = jQuery("#frm\\:cmbTabelaFaixaProdutoLeasing").val();
	// Recuperando o menor valor para ser o m�ximo, caso seja CDC/Leasing
	var retMax = 0;
	if (cdcRet != undefined && cdcRet != "") {
		cdcRet = cdcRet == "" ? -1 : parseFloat(cdcRet.split("|")[2].replace(",", "."));
		if (cdcRet >= 0 && jQuery("#frm\\:hdesc_cmbProdutos").val() == "CDC") {
			retMax = cdcRet;
			errSelTabFaiPro = true;
		} else if (cdcRet >= 0 && leasingRet >= 0 && jQuery("#frm\\:hdesc_cmbProdutos").val() == "CDC/LEASING") {
			retMax = cdcRet < leasingRet ? cdcRet : leasingRet;
			errSelTabFaiPro = true;
		}
	} else if (leasingRet != undefined && leasingRet != "") {
		leasingRet = leasingRet == "" ? -1 : parseFloat(leasingRet.split("|")[2].replace(",", "."));
		if (leasingRet >= 0 && jQuery("#frm\\:hdesc_cmbProdutos").val() == "LEASING") {
			retMax = leasingRet;
			errSelTabFaiPro = true;
		} else {
			exibirErroFoco(elem.attr("id"), msgErrSelTabFaiPro);
			errSelTabFaiPro = false;
			return retMax;
		}
	}
	return retMax;
}

/**
 * Obter o retorno m�ximo.
 */
function obterRetMaxCoeficiente(elem) {
	var cdcRet = jQuery("#coeficienteHidden").val();
	cdcRet = cdcRet == "" ? -1 : parseFloat(cdcRet.split("|")[1].replace(",", "."));
	// Recuperando o menor valor para ser o m�ximo, caso seja CDC/Leasing
	var retMax = 0;
	if (cdcRet >= 0) {
		retMax = cdcRet;
		errSelTabFaiPro = true;
	} else {
		exibirErroFoco(elem.attr("id"), msgErrSelTabFaiPro);
		errSelTabFaiPro = false;
		return retMax;
	}
	return retMax;
}

function validarEntrada(entrada) {
	var valor = entrada.val().replace(/\./gi, "").replace(/\./gi, "").replace(",", ".");
	if (valor != "" && valor != "0.00" && valor != null) {
		valor = parseFloat(valor);

		var valorBem = jQuery("#frm\\:valorBem").val().replace(/\./gi, "").replace(",", ".");
		valorBem = valorBem == "" ? 0 : parseFloat(valorBem);
		if (valor > valorBem) {
			exibirErroFoco(entrada.attr("id"), msgErrValEntBem);
			return false;
		} else if (valor == valorBem) {
			exibirErroFoco(entrada.attr("id"), msgErrValEntMenBem);
			return false;
		}

		var result = true;
		for (var i = 0; i < ajxCoparam.length; i++) {
			result = validarCoparam(ajxCoparam[i], valorBem, valor, entrada) && result;
		}

		if (!result) {
			return false;
		}

	}
	removerErro(entrada.attr("id"));
	return true;
}

// validar campos obrigat�rios em Simula��o
function validarSimulacao() {
	ret = true;
	// PARCELAS
	// --------------------------------------------------------------------------------------

	if (jQuery("#frm\\:divSelectParcelasBalao").is(":visible")) {
		if (jQuery("#frm\\:cmbNumeroParcelaBalao").val() == "-1") {
			exibirErro("frm:cmbNumeroParcelaBalao", "Selecione uma op��o de prazo");
			jQuery("#frm\\:cmbNumeroParcelaBalao").focus();
			ret = false;
		} else {
			removerErro("frm:cmbNumeroParcelaBalao");
		}
	}
	return ret;
}

function validarCoeficiente() {
	var cmbPlano = jQuery("#cmbPlano").val();
	var entrada = jQuery("#frm\\:valorEntrada").val();
	var coeficiente = jQuery("#frm\\:coeficiente");

	var coef = coeficiente.val();
	if ((coef == "" || coef == "0,00000") && (cmbPlano == "" || entrada == "" || entrada == "0,00")) {
		return false;
	} else if ((coef == "" || coef == "0,00000") && (cmbPlano != "") && (entrada != "" && entrada != "0,00")) {
		exibirErroFoco(coeficiente.attr("id"), msgErrInfValCoef);
		return false;
	}

	var coefMax = jQuery("#cmbPlano").val();
	coefMax = coefMax == "" ? 0 : parseFloat(coefMax.split("|")[1].replace(",", "."));
	coef = parseFloat(coef.replace(",", "."));
	if (coef < Math.round(coefMax * 100000) / 100000) {
		exibirErroFoco(coeficiente.attr("id"), msgErrValCoefNET);
		return false;
	}
	var nRetornoMaximo = obterRetMaxCoeficiente(coeficiente);
	var nCoeficienteRet = (coef / (Math.round(coefMax * 100000) / 100000) - 1) * 100;
	var nCoeficienteAux = nCoeficienteRet + "";
	var indice = nCoeficienteAux.indexOf(".", 0);
	nCoeficienteAux = parseInt(nCoeficienteAux, 0) + "." + nCoeficienteAux.substring(indice + 1, indice + 3);
	nCoeficienteRet = parseFloat(nCoeficienteAux);
	if (parseFloat(nCoeficienteRet) > parseFloat(nRetornoMaximo)) {
		exibirErroFoco(coeficiente.attr("id"), "Valor de retorno maior que m�ximo permitido");
		return false;
	}
	removerErro(coeficiente.attr("id"));
	return true;
}

function acertarToolTip() {
	var autoTip = jQuery(".auto_Tip");
	if (autoTip) {
		autoTip.removeAttr("href");
		if (autoTip.attr("title")) {
			autoTip.tooltip({
				extraClass : "tooltip_auto",
				track : true,
				left : 20,
				top : 0,
			});
		}
	}
}

function setarDefaultSelect(id) {
	document.getElementById("frm:" + id).value = 9999;
}

function verificarParcelaBalaoFixa() {
	if (jQuery("#idMostraTabelaParcelasBalao").val() == 'S') {
		tratarDivsParcelaBalao();
	}else{
		tratarDivsParcelaFixa();
	}
}

function validarExibicaoParcelasBalao() {
	if (jQuery("#frm\\:cmbNumeroParcelaBalao").val() == '-1') {
		// Esconde os detalhes da parcela bal�o
		jQuery("#divInformacoesParcelasBalao").hide();
	} else {
		// Esconde os detalhes da parcela bal�o
		jQuery("#divInformacoesParcelasBalao").show();
	}
}

function comumRegraComboParcela(valor) {

	if (valor == true || valor == 'true') {
		jQuery("#blocoNaoComboVendas").hide();
	} else {
		jQuery("#blocoNaoComboVendas").show();
	}
}

function tratarDivsParcelaBalao() {
	// Exibe o combo de prazos Parcela Bal�o
	jQuery("#frm\\:divSelectParcelasBalao").show();
	validarExibicaoParcelasBalao();
}

function tratarDivsParcelaFixa(){
	// Exibe o grid de Parcela Fixa
	jQuery("#frm\\:divSelectParcelasFixa").show();
}

function autoIframeCombo() {
	if (window.parent.autoIframe) {
		window.parent.autoIframe();
	}
}

// esconde a mensagem quando visival na altera��o da proposta, ao clicar em
// calcular.
function escondeMSGProduto() {
	setTimeout(function() {
		document.getElementById('frm:idAlertaDivValidacaoCombo').style.display = 'none';
	}, 1000);
}

/**
 * This function format the input to percent, it must be used with onblur event.
 * elem - input that generated the event scale - the scale of the field
 */
function _percBlur(elem, scale) {
	var value = elem.val();

	var reg = RegExp("^(\\d+|(\\d+,\\d+))$", "gi");
	if (!reg.test(value)) {
		value = "0,";
		for (var i = 0; i < scale; i++) {
			value += "0";
		}
		elem.val(value);
		return;
	}

	var commaIndex = value.indexOf(","); // Posicao da virgula
	var maxLength = elem.attr("maxlength"); // Tamanho total do campo

	if (commaIndex != -1) {
		while (value.length - commaIndex <= scale) {
			value += "0";
		}
		if (value.length >= maxLength) {
			value = value.substring(0, maxLength);
			var aux = value.replace(/,/gi, "");
			if (aux.length - scale > 0) {
				var v1 = aux.substring(0, aux.length - scale);
				var v2 = aux.substring(aux.length - scale);
				value = v1 + "," + v2;
			} else {
				value += ",";
				for (var i = 0; i < scale; i++) {
					value += "0";
				}
			}
		}
	} else {
		if (value.length == 0) {
			value = "0,";
			for (var i = 0; i < scale; i++) {
				value += "0";
			}
		} else {
			while (value.length <= scale) {
				value += "0";
			}
			if (value.length >= maxLength) {
				value = value.substring(0, maxLength - 1); // -1 por causa da
				// virgula que n�o
				// foi digitada
			}
			var aux = value.replace(/,/gi, "");
			if (aux.length - scale > 0) {
				var v1 = aux.substring(0, aux.length - scale);
				var v2 = aux.substring(aux.length - scale);
				value = v1 + "," + v2;
			} else {
				value += ",";
				for (var i = 0; i < scale; i++) {
					value += "0";
				}
			}
		}
	}
	elem.val(value);
}


/**
 * This function format the input to percent, it must be used with onkeypress
 * event. e - event elem - input that generated the event scale - the scale of
 * the field
 */
function _percKeyPress(elem, e, scale) {
	var selText = _percSelText();
	if (selText == elem.val()) {
		elem.val("");
	}

	var code = window.event ? window.event.keyCode : e.which;

	if (code == 0 || code == 8 /* Backspace */
			|| code == 9 /* Tab */
			|| code == 13 /* Esc */
			|| code == 27 /* Enter */) {
		return true;
	}

	// Verificando se � um n�mero ou v�rgula
	var reg = new RegExp(/\d|,/gi);
	var charCode = String.fromCharCode(code);
	if (!reg.test(charCode)) {
		if (e.preventDefault) { // standart browsers
			e.preventDefault();
		} else { // internet explorer
			e.returnValue = false;
		}
		return;
	}

	var value = elem.val();
	var commaIndex = value.indexOf(","); // Posicao da virgula
	var maxLength = elem.attr("maxlength"); // Tamanho total do campo
	var elemLength = value.length; // Tamanho do valor do campo
	var caret = elem.caret(); // Posicao do cursor

	// Prevenindo virgula: caso j� existe, com o cursor no inicio, maior que
	// scale
	if (code == 44 && (commaIndex != -1 || caret == 0 || caret < elemLength - scale || caret > maxLength - scale - 1)) {
		if (e.preventDefault) { // standart browsers
			e.preventDefault();
		} else { // internet explorer
			e.returnValue = false;
		}
		return;
	}

	// Prevenindo digitos ap�s virgula maior que o scale
	if (commaIndex != -1 && caret > commaIndex && caret - commaIndex > scale) {
		if (e.preventDefault) { // standart browsers
			e.preventDefault();
		} else { // internet explorer
			e.returnValue = false;
		}
		return;
	}

	// Concatenando virgula, caso n�o exista nenhuma e tecla pressionada n�o for
	// virgula
	if (code != 44 && commaIndex == -1 && elemLength == maxLength - scale - 1) {
		value += ",";
		elem.val(value);
	}
}

function validarParecer() {
	var a = "frm:txtParecer";
	if (jQuery("#frm\\:txtParecer").val() == "") {
		exibirErro(a, msgRequired[a]);
		return false;
		// Verifica, se no parecer tem menos que 15 caracters
		// Se tiver menos, ele da uma menssagem de erro e n�o deixa ava�ar.
	} else if (jQuery ("#frm\\:txtParecer").attr("value").replace(/\s/g,'').length < 15){
		exibirErro("frm:txtParecer", msgErrInfParecer);
		return false;
	} else {
		jQuery("#frm\\:txtParecer").attr("title", jQuery("#frm\\:txtParecer").attr("title_ori")).parents("div.form_erro").removeClass("form_erro").find("span.erro_msg").html("<strong></strong>");
		return true;
	}
}

function maxLength(field, maxChars) {
	if (field.value.length >= maxChars) {
		field.value = field.value.substring(0, maxChars - 1);
	}
}

function maxCaract(b, a) {
	if (b.value.length >= a) {
		b.value = b.value.substring(0, a - 1);
	}
	resto = a - b.value.length -1;
	document.getElementById('frm:cont').innerText = resto;
}