var loginName = null;
var loginCookie = null;
var loginRealCookie = null;
jQuery.fn.expandirMenu = function(a) {
	a = jQuery.extend({
		ativo : "ativo",
		visible : ":visible"
	}, a);
	return this.each(function() {
		var b = jQuery(this).parents("dt").next(), c = jQuery(this);
		jQuery(this).click(function() {
			if (b.is(a.visible)) {
				b.slideUp(function() {
					c.removeClass(a.ativo)
				})
			} else {
				b.slideDown(function() {
					c.addClass(a.ativo)
				})
			}
		})
	})
};
jQuery(function() {
	jQuery(".lstExpansivel dt a").expandirMenu();
	jQuery(".navMenuSuperior .tp5 a.target").click(function() {
		jQuery(this).attr("target", "_blank")
	});
	var b = jQuery("#lateral").height(), f = jQuery("#conteudo").height();
	if (b > f) {
		jQuery("#conteudo").css("minHeight", b)
	} else {
		jQuery("#lateral").css("minHeight", f)
	}
	jQuery(".btnVoltar").click(function() {
		window.history.go(-1)
	});
	jQuery(".btn_collapse").click(function(g) {
		var h = jQuery(this);
		h.siblings("a").removeClass("btn_collapse_on");
		h.next("div").siblings("div").slideUp();
		h.toggleClass("btn_collapse_on");
		h.next().slideToggle(250);
		g.preventDefault()
	});
	jQuery("#aumentoFonte li").click(function() {
		jQuery(this).addClass("atual").siblings().removeClass("atual");
		if (jQuery(this).hasClass("tp1")) {
			jQuery("#conteudo").css("font-size", "1.00em")
		} else {
			if (jQuery(this).hasClass("tp2")) {
				jQuery("#conteudo").css("font-size", "1.08em")
			} else {
				jQuery("#conteudo").css("font-size", "1.17em")
			}
		}
	});
	jQuery(".tabRadio tbody > tr td:not(.noClick)").click(function() {
		if (!jQuery(this).find(":radio")[0]) {
			var g = jQuery(this).parent().find(":radio:first");
			g.attr("checked", "checked")
		}
	}).hover(function() {
		jQuery(this).parent().addClass("over")
	}, function() {
		jQuery(this).parent().removeClass("over")
	});
	if (jQuery.fn.tooltip) {
		jQuery(".tooltip").tooltip({
			track: true,
			delay : 0,
			showURL : false,
		})
	}
	var a = "01/01/1900", d;
	if (jQuery(".dataIntervalo")[0]) {
		var c = jQuery(".dataIntervalo").attr("class").replace(/-/gi, "/");
		a = c.match("/inicial[0-9/]*/gi");
		d = c.match("/final[0-9/]*/gi");
		a = a ? a[0].substring(8) : "01/01/1900";
		d = d ? d[0].substring(6) : null
	}
	if (jQuery(".ico_calendario").size() > 0) {
		jQuery(".ico_calendario").datePicker({
			startDate : a,
			endDate : d,
			createButton : false
		});
		jQuery(".ico_calendario").bind("click", function() {
			if (!jQuery(this).parent().parent().hasClass("inativo")) {
				jQuery(this).dpDisplay();
				return false
			}
		}).bind("dateSelected", function(k, h, l, j) {
			var g = e(h);
			jQuery(this).parents(".dataCalendario").find(".dia").val(g[0]);
			jQuery(this).parents(".dataCalendario").find(".mes").val(g[1]);
			jQuery(this).parents(".dataCalendario").find(".ano").val(g[2])
		});
		jQuery("input.dia, input.mes, input.ano").focus(function() {
			jQuery(this).parents(".dataCalendario").find(".ico_calendario").dpDisplay()
		});
		jQuery("body").keyup(function(g) {
			timerCalendario = window.setTimeout(function() {
				if (g.keyCode == 9 && jQuery(".dp-popup")[0] && !!jQuery(":focus")[0] && !jQuery(":focus").is(".dia, .ano, .mes")) {
					jQuery(".dp-applied").dpClose()
				}
			}, 500)
		});
		function e(j) {
			c = new Date(j);
			var k = c.getDate();
			var h = c.getMonth() + 1;
			var l = c.getFullYear();
			if (k < 10) {
				k = "0" + k
			}
			if (h < 10) {
				h = "0" + h
			}
			var g = new Array(k, h, l);
			return g
		}
	}
	jQuery(".tabela-expansivel .expansor td:not(.noClick)").click(function() {		
		var g = jQuery(this).parents("tbody, tfoot"), h = g.find(".box-expansivel");
		if (!h.is(":visible")) {
			g.siblings().find(".box-expansivel").hide();
			g.siblings().removeClass("ativo hover").find(".expansivel").hide();
			g.removeClass("hover");
			g.addClass("ativo").find(".expansivel").show();
			h.slideDown()
		} else {
			h.slideUp(function() {
				g.removeClass("ativo").find(".expansivel").hide()
			})
		}
		setTimeout(function() {
			window.parent.autoIframe();
		}, 500);
	});
	jQuery(".tabela-expansivel .expansor td").hover(function() {
		var g = jQuery(this).parents("tbody, tfoot");
		if (!g.hasClass("ativo")) {
			g.addClass("hover")
		}
	}, function() {
		jQuery(this).parents("tbody, tfoot").removeClass("hover")
	});
	jQuery(".tabela-expansivel th:contains(div)").click(function() {
		jQuery(this).siblings().removeClass("desc asc");
		if (jQuery(this).hasClass("desc")) {
			jQuery(this).removeClass("desc").addClass("asc")
		} else {
			jQuery(this).removeClass("asc").addClass("desc")
		}
	});
	jQuery(".tabela-expansivel th.colOrder").hover(function() {
		if (jQuery(this).hasClass("overPrev")) {
			jQuery(this).prev().addClass("celOver")
		}
		if (jQuery(this).hasClass("overNext")) {
			jQuery(this).next().addClass("celOver")
		}
		jQuery(this).not(".celVazia,.celLast,.check").addClass("celOver")
	}, function() {
		if (jQuery(this).hasClass("overPrev")) {
			jQuery(this).prev().removeClass("celOver")
		}
		if (jQuery(this).hasClass("overNext")) {
			jQuery(this).next().removeClass("celOver")
		}
		jQuery(this).not(".celVazia,.celLast,.check").removeClass("celOver")
	});
	jQuery(".tabela-expansivel th.celValor").hover(function() {
		if (jQuery(this).parents("tr").hasClass("rowOrdenacao")) {
			jQuery(this).css("border-right", "1px solid #E2E2E2")
		}
	}, function() {
		if (jQuery(this).parents("tr").hasClass("rowOrdenacao")) {
			jQuery(this).css("border-right", "1px solid #F0F0F0")
		}
	});
	jQuery(".lstPassos li").hover(function() {
		jQuery(this).find(".exp").removeClass("none")
	}, function() {
		jQuery(this).find(".exp").addClass("none")
	});
	jQuery(".jqmWindow").jqm({
		onShow : initModal,
		onHide : exitModal,
		modal : true
	});
	jQuery(".openModal").live("click", function(g) {
		jQuery(".jqmWindow").jqmHide();
		jQuery(jQuery(this).attr("href")).jqmShow()
	});
	jQuery(".closeModal").click(function() {
		jQuery(this).parents(".jqmWindow").jqmHide();
		return false
	});
	jQuery(document).keypress(function(g) {
		if (g.keyCode == 27 && window.top.frames.modal_infra_estrutura.jQuery(".modalBloqueado").length == 0) {
			jQuery(".jqmWindow:visible").jqmHide()
		}
	});
	jQuery(".valor").each(function() {
		if (jQuery(this).val() == "") {
			jQuery(this).val("0,00")
		}
	});
	jQuery(".valor").blur(function(g) {
		onBlurInputMoney(g, this);
		if (jQuery(this).val() == "") {
			jQuery(this).val("0,00")
		}
	});
	jQuery(".valor").keyup(function(g) {
		onKeyUpInputMoney(g, this)
	});
	jQuery(".valor").keypress(function(g) {
		return onKeyPressInputMoney(g, this)
	});
	jQuery(".valor").focus(function() {
		if (jQuery(this).val() == "0,00") {
			jQuery(this).val("")
		}
	});
	jQuery(".valorWithComma").keypress(function(g) {
		return onKeyPressInputMoneyWithComma(g, this)
	});
	jQuery(".valorWithComma").focus(function() {
		if (jQuery(this).val() == "0,00") {
			jQuery(this).val("")
		}
	});
	jQuery(".valorWithComma").each(function() {
		if (jQuery(this).val() == "") {
			jQuery(this).val("0,00")
		}
	})
});
function initModal(f) {
	var e = jQuery(window).width();
	var c = jQuery(window).height();
	var h = f.w.width();
	var d = f.w.height();
	var b = jQuery(window).scrollTop();
	var a = h > e ? 0 : (e - h) / 2;
	var g = d > c ? (b) : b + ((c - d) / 2);
	f.w.css({
		top : g,
		left : a
	}).fadeIn();
	if (window.top.frames.modal_infra_estrutura.jQuery(".modalBloqueado").length > 0) {
		jQuery(".jqmOverlay", window.top.document).unbind().die()
	}
}
function exitModal(c) {
	c.o.hide();
	c.w.hide();
	try {
		var b = top.focusStack.pop();
		jQuery(b).focus()
	} catch (a) {
	}
}
var hiddenTabFirst = null;
var hiddenTabLast = null;
var btnImpressao = null;
var printChecked = false;
var modalFadeIn = 400;
var modalWindowName = "modal_infra_estrutura";
var mioloWindowName = "paginaCentral";
var inicializando = false;
var flagTabFirst = true;
(function($) {
	$(function() {
		var codigoTelaComPasso = null;
		var codigoTela = null;
		var numeroPasso = null;
		var re = /^([a-zA-Z]+)([\d]+)$/;
		codigoTelaComPasso = $(".txt-codigoTela").html();
		if (codigoTelaComPasso && codigoTelaComPasso.length && re.test(codigoTelaComPasso)) {
			codigoTela = RegExp.$1;
			numeroPasso = RegExp.$2
		} else {
			codigoTelaComPasso = ""
		}
		$(".btnKeyboardVirtual li * , .btnKeyboardVirtualSingle li *").live("keypress", function(e) {
			if (e.which == 32) {
				$(this).click()
			}
		});
		$(".limpar").click(function() {
			$(".input_fields li input").attr("value", "");
			$("#inativo").addClass("inativo");
			$("#inativo").find("input").attr("disabled", "disabled");
			count = 0
		});
		(function() {
			var transparencias = new Array("0.25", "0.35", "0.6", "1");
			var index = 3;
			var teclado = $(".btnKeyboardVirtualSingle li:not(.limpar) > div");
			if (teclado.length == 0) {
				teclado = $(".btnKeyboardVirtualSingle li:not(.limpar)")
			}
			$("#diminuiContraste").click(function(evt) {
				if (index > 0) {
					teclado.animate({
						opacity : transparencias[(--index)]
					})
				}
				evt.preventDefault()
			});
			$("#aumentaContraste").click(function(evt) {
				if (index < transparencias.length - 1) {
					teclado.animate({
						opacity : transparencias[(++index)]
					})
				}
				evt.preventDefault()
			})
		})();
		$(".cont_caracteres").keyup(function() {
			var idCampo = $(this).attr("id");
			if (idCampo.indexOf(":") >= 0) {
				idCampo = idCampo.split(":")[1]
			}
			try {
				$("span.cont_" + idCampo).text("[" + ($(this).val().length) + "]")
			} catch (err) {
			}
		});
		$(".cont_regr_caracteres").keyup(function() {
			var idCampo = $(this).attr("id");
			if (idCampo.indexOf(":") >= 0) {
				idCampo = idCampo.split(":")[1]
			}
			try {
				$("span.cont_" + idCampo).text("[" + ($(this).attr("maxlength") - $(this).val().length) + "]")
			} catch (err) {
			}
		});
		if ($("#UIFontSize").length == 0) {
			var tamanhoFonte = [];
			var $aux = $(".listaPersonalizacao .tp2");
			var seletorTamanhoFonte = "#conteudo > .miolo";
			if ($aux.length > 0) {
				tamanhoFonte[0] = $aux;
				tamanhoFonte[1] = $(".listaPersonalizacao .tp3");
				tamanhoFonte[2] = $(".listaPersonalizacao .tp4");
				for (var i = 0; i < tamanhoFonte.length; i++) {
					$(tamanhoFonte[i]).bind("click", {
						tamanho : i + 1
					}, function(event) {
						$(this).closest("ul").find("li").removeClass("On");
						$(this).addClass("On");
						aplicaTamanhoFonte(seletorTamanhoFonte, window, event.data.tamanho);
						if (!inicializando) {
							salvaTamanhoFonte(event.data.tamanho, codigoTela, numeroPasso)
						}
					})
				}
			}
		}
		$("#btn_ajuda").click(function() {
			var btnAjuda = $(this);
			var ajudaLeitura = $(".box-ajuda .ajuda-leitura");
			if (btnAjuda.hasClass("active")) {
				$(".box-ajuda").slideUp(300, function() {
					btnAjuda.removeClass("active");
					if (ajudaLeitura.length > 0) {
						btnAjuda.attr("tabindex", ajudaLeitura.attr("tabindex"));
						ajudaLeitura.removeAttr("tabindex");
						btnAjuda.focus()
					}
				})
			} else {
				btnAjuda.addClass("active");
				$(".box-ajuda").slideDown(300, function() {
					if (ajudaLeitura.length > 0) {
						ajudaLeitura.attr("tabindex", btnAjuda.attr("tabindex"));
						btnAjuda.removeAttr("tabindex");
						ajudaLeitura.focus()
					}
				})
			}
		});
		$(".box-ajuda .btn-fechar").click(function() {
			$("#btn_ajuda").click()
		});
		$(".box-ajuda .ajuda-leitura").keyup(function(e) {
			if (e.which == 13) {
				$("#btn_ajuda").click()
			}
		});
		$("#lateral dt").hover(function() {
			$(this).find("a.editar, span.drag").addClass("visible")
		}, function() {
			$(this).find("a.editar, span.drag").removeClass("visible")
		});
		$(".inativo a").live("click", function() {
			return false
		});
		$("input.numeric").live("keyup", function(e) {
			if ($.checkKey(e)) {
				var caretPos = $(this).caret();
				var len = $(this).val().length;
				$(this).val($(this).val().replace(/\D/g, ""));
				$(this).caret(caretPos - (len - $(this).val().length))
			}
		}).live("blur", function(e) {
			$(this).val($(this).val().replace(/\D/g, ""))
		});
		$.inputCurrency = $(".inputCurrency");
		$.inputCurrency.each(function() {
			if ($(this).val() == "") {
				$(this).val("0,00")
			}
		});
		$.inputCurrency.live("click focus", function(e) {
			if ($(this).val() == "0,00") {
				$(this).val("")
			}
		});
		$.inputCurrency.live("blur", function(e) {
			$(this).val(currencyFormatted($(this).val()));
			if ($(this).val().length == 0) {
				$(this).val("0,00")
			} else {
				if ($(this).val().length <= 2) {
					if (parseInt($(this).val(), 10) == 0) {
						$(this).val("0,00")
					} else {
						$(this).val($(this).val() + ",00")
					}
				}
			}
		});
		$.inputCurrency.live("keyup", function(e) {
			if ($.checkKey(e)) {
				var caretPos = $(this).caret();
				var len = $(this).val().length;
				$(this).val(currencyFormatted($(this).val().replace(/\D/g, "")));
				var caretNewPos = caretPos - (len - $(this).val().length);
				if (caretNewPos < 0) {
					caretNewPos = 0
				}
				$(this).caret(caretNewPos)
			}
		});
		$.checkKey = function(e) {
			var ret = false;
			if (e.which != 9 && e.which != 13 && e.which != 16 && e.which != 17 && e.which != 27 && e.which != 35 && e.which != 36 && e.which != 37 && e.which != 38 && e.which != 39 && e.which != 40) {
				ret = true
			}
			return ret
		};
		var retry = false;
		$.tabindex = function(v) {
			var j, classes, re, bAjuste, ajuste, ti;
			v = $.extend({
				index : 1,
				search : "body .tabindex",
				filter : ":not(font,table)"
			}, v);
			var $itensTabindex = $(v.search + v.filter);
			var isFrameExterno = $("#" + mioloWindowName).length > 0 ? true : false;
			if ($itensTabindex.length > 0) {
				if (window.name == modalWindowName && !retry) {
					retry = true;
					setTimeout("jQuery.tabindex()", modalFadeIn + 100)
				}
				if (isFrameExterno) {
					var $aux1;
					var $aux2;
					var HTML_A = '<a href="javascript:;" title="" class="tabindex" style="font-size:1px;">&nbsp;</a>';
					var HTML_DIV = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />';
					var $topo = $("#topo");
					var $lateral = $("#miolo #lateral");
					var $rodape = $("#rodape");
					var $iframe = $("#miolo #paginaCentral");
					if ($topo.find("#topo_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "topo_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "topo_hiddentablast");
						$topo.prepend($aux1);
						$topo.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
					if ($iframe.parent("div").find("#miolo_hiddentabbeforeout").length == 0) {
						$aux1 = $(HTML_A).attr("id", "miolo_hiddentabbeforeout");
						$aux2 = $(HTML_A).attr("id", "miolo_hiddentabbeforein");
						$iframe.before($aux1);
						$iframe.before($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);
						$aux1 = $(HTML_A).attr("id", "miolo_hiddentabafterout");
						$aux2 = $(HTML_A).attr("id", "miolo_hiddentabafterin");
						$iframe.after($aux1);
						$iframe.after($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
					if ($lateral.find("#lateral_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "lateral_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "lateral_hiddentablast");
						$lateral.prepend($aux1);
						$lateral.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
					if ($rodape.find("#rodape_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "rodape_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "rodape_hiddentablast");
						$rodape.prepend($aux1);
						$rodape.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
				} else {
					if (window.name != modalWindowName) {
						if (!document.getElementById("hiddentablast")) {
							hiddenTabFirst = $('<a href="javascript:;" title="" id="hiddentabfirst" class="tabindex" style="font-size:1px">&nbsp;</a>');
							hiddenTabLast = $('<a href="javascript:;" title="" id="hiddentablast" class="tabindex" style="font-size:1px">&nbsp;</a>');
							$("body").prepend(hiddenTabFirst);
							$("body").append(hiddenTabLast);
							hiddenTabFirst.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />');
							hiddenTabLast.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />')
						}
					}
				}
				$(".tabindexBeforeFrame, .tabindexAfterFrame").remove();
				$itensTabindex = $(v.search + v.filter);
				$itensTabindex.each(function(i) {
					if ($(this).is("iframe") && !(isFrameExterno && ($(this).attr("name") == mioloWindowName))) {
						var $linkAntes = $('<a href="javascript:;" title="" style="font-size:1px">&nbsp;</a>').attr("tabindex", v.index++);
						var $linkDepois = $('<a href="javascript:;" title="" style="font-size:1px">&nbsp;</a>').attr("tabindex", v.index++);
						$(this).before($linkAntes).after($linkDepois);
						$linkAntes.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" class="tabindexBeforeFrame" />');
						$linkDepois.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" class="tabindexAfterFrame" />');
						$linkAntes.unbind("focus", colocaFocoFrame).bind("focus", {
							sentido : 0,
							seletor : v.search + v.filter
						}, colocaFocoFrame);
						$linkDepois.unbind("focus", colocaFocoFrame).bind("focus", {
							sentido : 2,
							seletor : v.search + v.filter
						}, colocaFocoFrame)
					} else {
						bAjuste = false;
						classes = $(this).get(0).className.split(" ");
						re = /^\u0074\u0061\u0062\u002d([\d]+)$/;
						for (j = 0; j < classes.length; j++) {
							if (re.test(classes[j])) {
								bAjuste = true;
								ajuste = parseInt(RegExp.$1, 10);
								break
							}
						}
						if (bAjuste) {
							for (var i = 1; i <= ajuste; i++) {
								var $aux = $("[tabindex=" + (v.index - i) + "]");
								var oldTabindex = parseInt($aux.attr("tabindex"), 10);
								$aux.attr("tabindex", oldTabindex + 1)
							}
							$(this).attr("tabindex", v.index++ - ajuste)
						} else {
							$(this).attr("tabindex", v.index++)
						}
					}
				});
				if (window.name != modalWindowName) {
					if (window.name == mioloWindowName) {
						var $iframe = $("iframe[name=" + window.name + "]", window.parent.document);
						if ($iframe.length > 0) {
							hiddenTabFirst.unbind("focus", colocaFocoFrame).bind("focus", {
								sentido : 3,
								delta : 1,
								seletor : v.search + v.filter
							}, colocaFocoFrame);
							hiddenTabLast.unbind("focus", colocaFocoFrame).bind("focus", {
								sentido : 1,
								delta : 1,
								seletor : v.search + v.filter
							}, colocaFocoFrame)
						} else {
							var $tabfirst = $(".tabindex[tabindex=2]");
							var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
							if ($tablast.length > 0) {
								hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {
									destino : $tablast.get(0)
								}, colocaFoco)
							}
							if ($tabfirst.length > 0) {
								hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {
									destino : $tabfirst.get(0)
								}, colocaFoco)
							}
						}
					} else {
						if (window.parent != window) {
							var $iframe = $("iframe[name=" + window.name + "]", window.parent.document);
							if ($iframe.hasClass("tabindex")) {
								hiddenTabFirst.unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 3,
									seletor : v.search + v.filter
								}, colocaFocoFrame);
								hiddenTabLast.unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 1,
									seletor : v.search + v.filter
								}, colocaFocoFrame)
							} else {
								var $tabfirst = $(".tabindex[tabindex=2]");
								var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
								if ($tablast.length > 0) {
									hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {
										destino : $tablast.get(0)
									}, colocaFoco)
								}
								if ($tabfirst.length > 0) {
									hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {
										destino : $tabfirst.get(0)
									}, colocaFoco)
								}
							}
						} else {
							if (isFrameExterno) {
								var $topo = $("#topo");
								var $topoItens = $topo.find(".tabindex");
								var $topoTabFirst = $topoItens.eq(1);
								var $topoTabLast = $topoItens.eq($topoItens.length - 2);
								var $lateral = $("#miolo #lateral");
								var $lateralItens = $lateral.find(".tabindex");
								var $lateralTabFirst = $lateralItens.eq(1);
								var $lateralTabLast = $lateralItens.eq($lateralItens.length - 2);
								var $rodape = $("#rodape");
								var $rodapeItens = $rodape.find(".tabindex");
								var $rodapeTabFirst = $rodapeItens.eq(1);
								var $rodapeTabLast = $rodapeItens.eq($rodapeItens.length - 2);
								$("#topo_hiddentablast").unbind("focus", colocaFoco).bind("focus", {
									destino : $("#miolo_hiddentabbeforein").get(0)
								}, colocaFoco);
								$("#miolo_hiddentabbeforein").unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 0,
									seletor : v.search + v.filter
								}, colocaFocoFrame);
								$("#miolo_hiddentabafterout").unbind("focus", colocaFoco).bind("focus", {
									destino : $lateralTabFirst.get(0)
								}, colocaFoco);
								$("#lateral_hiddentablast").unbind("focus", colocaFoco).bind("focus", {
									destino : $rodapeTabFirst.get(0)
								}, colocaFoco);
								$("#rodape_hiddentablast").unbind("focus", colocaFoco).bind("focus", {
									destino : $topoTabFirst.get(0)
								}, colocaFoco);
								$("#miolo_hiddentabbeforeout").unbind("focus", colocaFoco).bind("focus", {
									destino : $topoTabLast.get(0)
								}, colocaFoco);
								$("#lateral_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {
									destino : $("#miolo_hiddentabafterin").get(0)
								}, colocaFoco);
								$("#miolo_hiddentabafterin").unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 2,
									seletor : v.search + v.filter
								}, colocaFocoFrame);
								$("#rodape_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {
									destino : $lateralTabLast.get(0)
								}, colocaFoco);
								$("#topo_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {
									destino : $rodapeTabLast.get(0)
								}, colocaFoco)
							} else {
								var $tabfirst = $(".tabindex[tabindex=2]");
								var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
								if ($tablast.length > 0) {
									hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {
										destino : $tablast.get(0)
									}, colocaFoco)
								}
								if ($tabfirst.length > 0) {
									hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {
										destino : $tabfirst.get(0)
									}, colocaFoco)
								}
							}
						}
					}
				}
				var $tabfocus = $itensTabindex.filter(".tabfirst:visible").last();
				if ($tabfocus.length == 0) {
					$tabfocus = $itensTabindex.filter("[tabindex=2]").last()
				}
				if (jQuery(".btnSalvarFoco").length > 0) {
					var ultimoFoco = parent.focusStack.pop();
					if (ultimoFoco != undefined) {
						$tabfocus = jQuery(".btnSalvarFoco")
					}
					if (jQuery(".tituloAutoFoco").length > 0) {
						$tabfocus = jQuery(".tituloAutoFoco:first")
					}
				}
				if (jQuery(".selecaoCEP").length > 0) {
					$tabfocus = jQuery(".selecaoCEP")
				}
				if ($tabfocus.length > 0) {
					try {
						setTimeout(function() {
							if (flagTabFirst) {
								$tabfocus.focus()
							}
						}, 500)
					} catch (err) {
					}
				}
			}
		};
		$.tabindexSemTabfirst = function(v) {
			var j, classes, re, bAjuste, ajuste, ti;
			v = $.extend({
				index : 1,
				search : "body .tabindex",
				filter : ":not(font,table)"
			}, v);
			var $itensTabindex = $(v.search + v.filter);
			var isFrameExterno = $("#" + mioloWindowName).length > 0 ? true : false;
			if ($itensTabindex.length > 0) {
				if (window.name == modalWindowName && !retry) {
					retry = true;
					setTimeout("jQuery.tabindex()", modalFadeIn + 100)
				}
				if (isFrameExterno) {
					var $aux1;
					var $aux2;
					var HTML_A = '<a href="javascript:;" title="" class="tabindex" style="font-size:1px;">&nbsp;</a>';
					var HTML_DIV = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />';
					var $topo = $("#topo");
					var $lateral = $("#miolo #lateral");
					var $rodape = $("#rodape");
					var $iframe = $("#miolo #paginaCentral");
					if ($topo.find("#topo_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "topo_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "topo_hiddentablast");
						$topo.prepend($aux1);
						$topo.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
					if ($iframe.parent("div").find("#miolo_hiddentabbeforeout").length == 0) {
						$aux1 = $(HTML_A).attr("id", "miolo_hiddentabbeforeout");
						$aux2 = $(HTML_A).attr("id", "miolo_hiddentabbeforein");
						$iframe.before($aux1);
						$iframe.before($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);
						$aux1 = $(HTML_A).attr("id", "miolo_hiddentabafterout");
						$aux2 = $(HTML_A).attr("id", "miolo_hiddentabafterin");
						$iframe.after($aux1);
						$iframe.after($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
					if ($lateral.find("#lateral_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "lateral_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "lateral_hiddentablast");
						$lateral.prepend($aux1);
						$lateral.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
					if ($rodape.find("#rodape_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "rodape_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "rodape_hiddentablast");
						$rodape.prepend($aux1);
						$rodape.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV)
					}
				} else {
					if (window.name != modalWindowName) {
						if (!document.getElementById("hiddentablast")) {
							hiddenTabFirst = $('<a href="javascript:;" title="" id="hiddentabfirst" class="tabindex" style="font-size:1px">&nbsp;</a>');
							hiddenTabLast = $('<a href="javascript:;" title="" id="hiddentablast" class="tabindex" style="font-size:1px">&nbsp;</a>');
							$("body").prepend(hiddenTabFirst);
							$("body").append(hiddenTabLast);
							hiddenTabFirst.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />');
							hiddenTabLast.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />')
						}
					}
				}
				$(".tabindexBeforeFrame, .tabindexAfterFrame").remove();
				$itensTabindex = $(v.search + v.filter);
				$itensTabindex.each(function(i) {
					if ($(this).is("iframe") && !(isFrameExterno && ($(this).attr("name") == mioloWindowName))) {
						var $linkAntes = $('<a href="javascript:;" title="" style="font-size:1px">&nbsp;</a>').attr("tabindex", v.index++);
						var $linkDepois = $('<a href="javascript:;" title="" style="font-size:1px">&nbsp;</a>').attr("tabindex", v.index++);
						$(this).before($linkAntes).after($linkDepois);
						$linkAntes.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" class="tabindexBeforeFrame" />');
						$linkDepois.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" class="tabindexAfterFrame" />');
						$linkAntes.unbind("focus", colocaFocoFrame).bind("focus", {
							sentido : 0,
							seletor : v.search + v.filter
						}, colocaFocoFrame);
						$linkDepois.unbind("focus", colocaFocoFrame).bind("focus", {
							sentido : 2,
							seletor : v.search + v.filter
						}, colocaFocoFrame)
					} else {
						bAjuste = false;
						classes = $(this).get(0).className.split(" ");
						re = /^\u0074\u0061\u0062\u002d([\d]+)$/;
						for (j = 0; j < classes.length; j++) {
							if (re.test(classes[j])) {
								bAjuste = true;
								ajuste = parseInt(RegExp.$1, 10);
								break
							}
						}
						if (bAjuste) {
							for (var i = 1; i <= ajuste; i++) {
								var $aux = $("[tabindex=" + (v.index - i) + "]");
								var oldTabindex = parseInt($aux.attr("tabindex"), 10);
								$aux.attr("tabindex", oldTabindex + 1)
							}
							$(this).attr("tabindex", v.index++ - ajuste)
						} else {
							$(this).attr("tabindex", v.index++)
						}
					}
				});
				if (window.name != modalWindowName) {
					if (window.name == mioloWindowName) {
						var $iframe = $("iframe[name=" + window.name + "]", window.parent.document);
						if ($iframe.length > 0) {
							hiddenTabFirst.unbind("focus", colocaFocoFrame).bind("focus", {
								sentido : 3,
								delta : 1,
								seletor : v.search + v.filter
							}, colocaFocoFrame);
							hiddenTabLast.unbind("focus", colocaFocoFrame).bind("focus", {
								sentido : 1,
								delta : 1,
								seletor : v.search + v.filter
							}, colocaFocoFrame)
						} else {
							var $tabfirst = $(".tabindex[tabindex=2]");
							var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
							if ($tablast.length > 0) {
								hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {
									destino : $tablast.get(0)
								}, colocaFoco)
							}
							if ($tabfirst.length > 0) {
								hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {
									destino : $tabfirst.get(0)
								}, colocaFoco)
							}
						}
					} else {
						if (window.parent != window) {
							var $iframe = $("iframe[name=" + window.name + "]", window.parent.document);
							if ($iframe.hasClass("tabindex")) {
								hiddenTabFirst.unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 3,
									seletor : v.search + v.filter
								}, colocaFocoFrame);
								hiddenTabLast.unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 1,
									seletor : v.search + v.filter
								}, colocaFocoFrame)
							} else {
								var $tabfirst = $(".tabindex[tabindex=2]");
								var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
								if ($tablast.length > 0) {
									hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {
										destino : $tablast.get(0)
									}, colocaFoco)
								}
								if ($tabfirst.length > 0) {
									hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {
										destino : $tabfirst.get(0)
									}, colocaFoco)
								}
							}
						} else {
							if (isFrameExterno) {
								var $topo = $("#topo");
								var $topoItens = $topo.find(".tabindex");
								var $topoTabFirst = $topoItens.eq(1);
								var $topoTabLast = $topoItens.eq($topoItens.length - 2);
								var $lateral = $("#miolo #lateral");
								var $lateralItens = $lateral.find(".tabindex");
								var $lateralTabFirst = $lateralItens.eq(1);
								var $lateralTabLast = $lateralItens.eq($lateralItens.length - 2);
								var $rodape = $("#rodape");
								var $rodapeItens = $rodape.find(".tabindex");
								var $rodapeTabFirst = $rodapeItens.eq(1);
								var $rodapeTabLast = $rodapeItens.eq($rodapeItens.length - 2);
								$("#topo_hiddentablast").unbind("focus", colocaFoco).bind("focus", {
									destino : $("#miolo_hiddentabbeforein").get(0)
								}, colocaFoco);
								$("#miolo_hiddentabbeforein").unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 0,
									seletor : v.search + v.filter
								}, colocaFocoFrame);
								$("#miolo_hiddentabafterout").unbind("focus", colocaFoco).bind("focus", {
									destino : $lateralTabFirst.get(0)
								}, colocaFoco);
								$("#lateral_hiddentablast").unbind("focus", colocaFoco).bind("focus", {
									destino : $rodapeTabFirst.get(0)
								}, colocaFoco);
								$("#rodape_hiddentablast").unbind("focus", colocaFoco).bind("focus", {
									destino : $topoTabFirst.get(0)
								}, colocaFoco);
								$("#miolo_hiddentabbeforeout").unbind("focus", colocaFoco).bind("focus", {
									destino : $topoTabLast.get(0)
								}, colocaFoco);
								$("#lateral_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {
									destino : $("#miolo_hiddentabafterin").get(0)
								}, colocaFoco);
								$("#miolo_hiddentabafterin").unbind("focus", colocaFocoFrame).bind("focus", {
									sentido : 2,
									seletor : v.search + v.filter
								}, colocaFocoFrame);
								$("#rodape_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {
									destino : $lateralTabLast.get(0)
								}, colocaFoco);
								$("#topo_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {
									destino : $rodapeTabLast.get(0)
								}, colocaFoco)
							} else {
								var $tabfirst = $(".tabindex[tabindex=2]");
								var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
								if ($tablast.length > 0) {
									hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {
										destino : $tablast.get(0)
									}, colocaFoco)
								}
								if ($tabfirst.length > 0) {
									hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {
										destino : $tabfirst.get(0)
									}, colocaFoco)
								}
							}
						}
					}
				}
			}
		};
		function colocaFoco(evt) {
			try {
				evt.data.destino.focus()
			} catch (err) {
			}
		}
		colocaFocoFrame = function(evt) {
			var destino = null;
			var pos;
			var $iframe, $itens, $itensAux, $aux;
			var delta = (evt.data.delta != undefined) ? evt.data.delta : 0;
			switch (evt.data.sentido) {
			case 0:
				try {
					$iframe = $(this).parent().next();
					$itens = $(evt.data.seletor, $iframe.get(0).contentWindow.document);
					if ($itens.length > 0) {
						destino = $itens.filter("[tabindex=2]").get(0)
					}
				} catch (err) {
				}
				if (destino == null) {
					$itens = $(evt.data.seletor);
					pos = $itens.index($iframe);
					for (var i = pos + 1; i < $itens.length; i++) {
						$aux = $itens.eq(i);
						if ($aux.is(":visible") && !($aux.attr("disabled") == true)) {
							break
						}
					}
					destino = $aux.get(0)
				}
				break;
			case 1:
				$itens = $(evt.data.seletor, window.parent.document);
				if ($itens.length == 0) {
					return
				}
				$iframe = $("iframe[name=" + window.name + "]", window.parent.document);
				pos = $itens.index($iframe);
				for (var i = pos + delta + 1; i < $itens.length; i++) {
					$aux = $itens.eq(i);
					if ($aux.is(":visible") && !($aux.attr("disabled") == true)) {
						break
					}
				}
				destino = $aux.get(0);
				break;
			case 2:
				try {
					$iframe = $(this).parent().prev();
					$itens = $iframe.get(0).contentWindow.jQuery.itensTabIndex();
					if ($itens.length > 0) {
						var itens = ordenaPorTabindex($itens.toArray());
						$aux = $(itens[itens.length - 2]);
						if ($aux.is("iframe")) {
							$itensAux = $aux.get(0).contentWindow.jQuery.itensTabIndex();
							var itensAux = ordenaPorTabindex($itensAux.toArray());
							$aux = $(itensAux[itensAux.length - 2])
						}
						destino = $aux.get(0)
					}
				} catch (err) {
				}
				if (destino == null) {
					$itens = $(evt.data.seletor);
					pos = $itens.index($iframe);
					for (var i = pos - 1; i >= 0; i--) {
						$aux = $itens.eq(i);
						if ($aux.is(":visible") && !($aux.attr("disabled") == true)) {
							break
						}
					}
					destino = $aux.get(0)
				}
				break;
			case 3:
				$itens = $(evt.data.seletor, window.parent.document);
				if ($itens.length == 0) {
					return
				}
				$iframe = $("iframe[name=" + window.name + "]", window.parent.document);
				pos = $itens.index($iframe);
				for (var i = pos - delta - 1; i >= 0; i--) {
					$aux = $itens.eq(i);
					if ($aux.is(":visible") && !($aux.attr("disabled") == true)) {
						break
					}
				}
				destino = $aux.get(0);
				break;
			default:
				return
			}
			evt.data.destino = destino;
			colocaFoco(evt)
		};
		var p_itensTabIndex = null;
		$.itensTabIndex = function() {
			if (p_itensTabIndex == null) {
				var $itens1 = $("[tabindex]");
				var $itens2 = $("[tabindex!=0]");
				p_itensTabIndex = ($itens1.length < $itens2.length) ? $itens1 : $itens2
			}
			return p_itensTabIndex
		};
		function ordenaPorTabindex(vetorDom) {
			var retorno = vetorDom;
			retorno.sort(function(a, b) {
				var compA = parseInt($(a).attr("tabindex"), 10);
				var compB = parseInt($(b).attr("tabindex"), 10);
				return (compA < compB) ? -1 : (compA > compB) ? 1 : 0
			});
			return retorno
		}
		$.criaTooltips = function() {
			if ($.fn.tooltip) {
				$(".loging_Tip,.senha_Tip,.nome_Tip,.lstUtil li a:not([id='btn_ajuda']),.ico_1line_Tip,.ico_2lines_Tip,.ico_3lines_Tip,.ico_4lines_Tip,.ico_5lines_Tip,.auto_Tip").tooltip({
					extraClass : "tooltip_auto",
					track: true,
					left: 20,
					top: 0,
				});
				$("#btn_ajuda").tooltip({
					extraClass : "tooltip_auto",
					top : 8
				});
				var $tipAcesso = $("sup.tooltip");
				if ($tipAcesso.length > 0) {
					var titleAcesso = $tipAcesso.attr("title");
					if (titleAcesso == "") {
						titleAcesso = 'Para acessar as opera��es mais r�pido, selecione a tecla "A"';
						$tipAcesso.attr("title", titleAcesso)
					}
					titleAcesso = titleAcesso.replace(/\"/gi, "");
					var $linkAcesso = $("<a>").attr("href", "javascript:;").attr("title", titleAcesso).attr("class", "tabindex");
					$tipAcesso.before($linkAcesso);
					$tipAcesso.tooltip({
						extraClass : "tooltip_acesso_rapido"
					})
				}
			}
		};
		$("input").live("keyup", function(e) {
			if ($(this).attr("maxlength") > 0 && $(this).caret() >= $(this).attr("maxlength") && $.checkKey(e)) {
				var thisTabIndex = parseInt($(this).attr("tabindex"), 10);
				var $itens = $.itensTabIndex();
				var nextTabIndex = thisTabIndex + 1;
				var proximoCampo = null;
				while (true) {
					if (nextTabIndex > $itens.length) {
						nextTabIndex = 1
					} else {
						if (nextTabIndex == thisTabIndex) {
							proximoCampo = null;
							break
						}
					}
					proximoCampo = $itens.filter("[tabindex=" + nextTabIndex + "]");
					if (proximoCampo.length == 0) {
						proximoCampo = null;
						break
					} else {
						if ((!proximoCampo.is(":visible") || proximoCampo.attr("disabled") == true) && !proximoCampo.hasClass("ajaxFocus")) {
							nextTabIndex = nextTabIndex + 1
						} else {
							break
						}
					}
				}
				if (proximoCampo != null) {
					jQuery(this).change().blur();
					if (proximoCampo.is(":button") || proximoCampo.is(":submit") || proximoCampo.is(":image")) {
						proximoCampo.focus()
					} else {
						proximoCampo.focus();
						proximoCampo.select()
					}
				}
			}
		});
		$("input.clearField,textarea.clearField").each(function() {
			$(this).focus(function() {
				if ($(this).val() == $(this).attr("title")) {
					$(this).val("")
				}
			}).blur(function() {
				if ($(this).val() == "") {
					$(this).val($(this).attr("title"))
				}
			})
		});
		var l;
		if (window.parent.$ && window.parent.$("#lateral")) {
			l = window.parent.$("#lateral").outerHeight()
		} else {
			l = 800
		}
		var c = $("#conteudo").outerHeight();
		var i = $("#conteudo .topo").height() + $("#conteudo .base").height();
		l = l - (i + 10);
		$("a[rel*='external']").click(function(evt) {
			window.open($(this).attr("href"));
			evt.preventDefault()
		});
		$("tr.ordenacao_tabela a").click(function(evt) {
			$(this).parents("tr").find("a").not(this).removeClass("sortAsc").removeClass("sortDesc");
			if ($(this).hasClass("sortAsc")) {
				$(this).removeClass("sortAsc");
				$(this).addClass("sortDesc")
			} else {
				$(this).addClass("sortAsc");
				$(this).removeClass("sortDesc")
			}
			var u = $(this).attr("href");
			if (u == "#") {
				evt.preventDefault()
			}
		});
		$("a[rel*='btn_imprimir']").click(function(evt) {
			$(".printBlock").removeClass("printImportant");
			if ($(this).hasClass("imprimeIndividual")) {
				btnImpressao = $(this);
				btnImpressao.parents(".printBlock").addClass("printImportant")
			} else {
				if ($(this).hasClass("bt_print")) {
					printChecked = true
				} else {
					printChecked = false;
					btnImpressao = null
				}
			}
			evt.preventDefault()
		});
		$(".ico-imprimir").click(function(e) {
			$(this).parents("tr").next().find("a[rel*='btn_imprimir']").click();
			e.stopPropagation();
			e.preventDefault()
		});
		$(".scrollTo").live("click", function(evt) {
			var posTop = $($(this).attr("href")).offset().top;
			$("html, body").animate({
				scrollTop : posTop
			}, 500);
			evt.preventDefault()
		});
		$(".tabCollapse tbody .linhaConta").hover(function() {
			$(this).addClass("over")
		}, function() {
			$(this).removeClass("over")
		});
		$(".tabCollapse tbody .linhacheck input:checkbox , .tabCollapse tbody .tdCheck input:checkbox").click(function(evt) {
			evt.stopPropagation()
		});
		$(".tabCollapse tbody .linhacheck").click(function() {
			if ($(this).find("input").is(":checked")) {
				$(this).find("input").not(":disabled").attr("checked", "")
			} else {
				$(this).find("input").not(":disabled").attr("checked", "checked")
			}
		});
		$("thead input:checkbox").click(function() {
			if ($(this).is(":checked")) {
				$("tbody").find("input").not(":disabled").attr("checked", "checked")
			} else {
				$("tbody").find("input").not(":disabled").attr("checked", "")
			}
		});
		$(".ativa_formulario, .ativa_formulario_txt").blur(function() {
			var loading = $(this).parents(".formulario").find(".loading");
			loading.removeClass("none_i");
			setTimeout(function() {
				$(".inativo").removeClass("inativo").find("input:not(.disabled)").attr("disabled", "");
				loading.addClass("none_i")
			}, 2000)
		});
		$("input.limpaCampo,textarea.limpaCampo").each(function() {
			$(this).focus(function() {
				if (($(this).attr("title_ori") != undefined && $(this).val() == $(this).attr("title_ori")) || ($(this).attr("limpa_campo") != undefined && $(this).val() == $(this).attr("limpa_campo"))) {
					$(this).val("")
				} else {
					if ($(this).val() == $(this).attr("title")) {
						$(this).val("")
					}
				}
			}).blur(function() {
				if ($(this).val() == "") {
					if ($(this).attr("limpa_campo") != undefined) {
						$(this).val($(this).attr("limpa_campo"))
					} else {
						if ($(this).attr("title_ori") != undefined) {
							$(this).val($(this).attr("title_ori"))
						} else {
							$(this).val($(this).attr("title"))
						}
					}
				}
			})
		});
		$(".btn_collapse").click(function(evt) {
			var conteudo = $(this).next();
			var btnCollapse = $(this);
			if (conteudo.is(":visible")) {
				conteudo.slideUp(500, function() {
					btnCollapse.removeClass("btn_collapse_on")
				})
			} else {
				btnCollapse.addClass("btn_collapse_on");
				conteudo.slideDown(500)
			}
			evt.preventDefault()
		});
		$(".tabela-expansivel .expansor td:not(.check, .icone, .noClick)").click(function() {
			var $tbody = $(this).closest("tbody");
			var $box = $tbody.find(".box-expansivel");
			var $callback = $tbody.find(".box-expansivel-callback");
			var $callbackTable = $tbody.closest("table").prev(".tabela-expansivel-callback");
			if ($box.is(":hidden")) {
				$(".tabela-expansivel .box-expansivel").hide();
				$(".tabela-expansivel tbody").removeClass("ativo hover").find(".expansivel").hide();
				$tbody.addClass("ativo").find(".expansivel").show();
				$box.slideDown(400, function() {
					if (window.parent.autoIframe) {
						window.parent.autoIframe()
					}
					$callback.click();
					$callbackTable.click()
				})
			}
		});
		$(".tabela-expansivel .expansor td").hover(function() {
			var $tbody = $(this).parents("tbody");
			if (!$tbody.hasClass("ativo")) {
				$tbody.addClass("hover")
			}
		}, function() {
			$(this).parents("tbody").removeClass("hover")
		});
		$(".tabela-expansivel th:contains(a)").click(function() {
			$(this).siblings().removeClass("desc asc");
			if ($(this).hasClass("desc")) {
				$(this).removeClass("desc").addClass("asc")
			} else {
				$(this).removeClass("asc").addClass("desc")
			}
		});
		$("a,:input").focus(function(evt) {
			top.currentFocus = this
		});
		if (window.name == modalWindowName) {
			var divPre = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;"><a href="javascript:;" title="" class="tabindex focoUltimo" style="font-size:1px">&nbsp;</a></div>';
			var divPos = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;"><a href="javascript:;" title="" class="tabindex focoPrimeiro" style="font-size:1px">&nbsp;</a><a href="javascript:;" title="" class="focoPrimeiro" style="font-size:1px">&nbsp;</a></div>';
			$("body").prepend(divPre);
			$("body").append(divPos);
			$(".focoUltimo").focus(function(evt) {
				setTimeout("focoUltimo();", 10)
			});
			$(".focoPrimeiro").focus(function(evt) {
				setTimeout("focoPrimeiro();", 10)
			})
		}
		if ($.fn.datePicker) {
			var visivel = new Array();
			var $ico_calendario = $(".ico_calendario");
			if ($ico_calendario.size() > 0) {
				Date.format = "dd/mm/yyyy";
				$ico_calendario.each(function() {
					visivel[$(this).closest(".dataCalendario").attr("id")] = false
				});
				$ico_calendario.datePicker({
					createButton : false,
					startDate : "01/01/1900"
				}).click(function(evt) {
					if ((!$(this).parent().parent().hasClass("inativo")) && (!$(this).parent().parent().parent().hasClass("inativo"))) {
						var $dataCalendario = $(this).closest(".dataCalendario");
						var dataInicial = $dataCalendario.find(".dataInicial").val();
						var dataFinal = $dataCalendario.find(".dataFinal").val();
						if (dataInicial != "undefined") {
							$(this).dpSetStartDate(dataInicial)
						}
						if (dataFinal != "undefined") {
							$(this).dpSetEndDate(dataFinal)
						}
						var dia = $.trim($dataCalendario.find(".dia").val());
						var mes = $dataCalendario.find(".mes").val();
						var ano = $dataCalendario.find(".ano").val();
						if (dia != "" && dia.length == 2 && mes != "" && mes.length == 2 && ano != "" && ano.length == 4) {
							$(this).dpSetSelected(dia + "/" + mes + "/" + ano)
						}
						$(this).dpDisplay();
						evt.preventDefault()
					}
				}).bind("dateSelected", function(e, selectedDate, $td, state) {
					var $dataCalendario = $(this).closest(".dataCalendario");
					var arrDataSel = arrDate(selectedDate);
					var elDia = $dataCalendario.find(".dia");
					var elMes = $dataCalendario.find(".mes");
					var elAno = $dataCalendario.find(".ano");
					$(elDia).val(arrDataSel[0]);
					$(elMes).val(arrDataSel[1]);
					$(elAno).val(arrDataSel[2]);
					removerErroCampoCal(elDia);
					removerErroCampoCal(elMes);
					removerErroCampoCal(elAno);
					$(elDia).closest(".campos_form").removeClass("form_erro").find(".erro_msg").html("<strong></strong>");
					var $onDS = $dataCalendario.find("#OnDateSelected");
					if ($onDS.length > 0) {
						eval($onDS.val())
					}
				}).bind("dpDisplayed", function(event, datePickerDiv) {
					visivel[$(this).closest(".dataCalendario").attr("id")] = true
				}).bind("dpClosed", function(event, selected) {
					visivel[$(this).closest(".dataCalendario").attr("id")] = false
				});
				$("input.dia, input.mes, input.ano").each(function() {
					$(this).click(function(evt) {
						var $dataCalendario = $(this).closest(".dataCalendario");
						var $icoCalendario = $dataCalendario.find(".ico_calendario");
						if (!visivel[$dataCalendario.attr("id")]) {
							$icoCalendario.click()
						}
					});
					$(this).focus(function(evt) {
						var $dataCalendario = $(this).closest(".dataCalendario");
						var $icoCalendario = $dataCalendario.find(".ico_calendario");
						var dia = $.trim($dataCalendario.find("input.dia").val());
						var mes = $.trim($dataCalendario.find("input.mes").val());
						var ano = $.trim($dataCalendario.find("input.ano").val());
						if (dia == "" || mes == "" || ano == "") {
							var d = new Date();
							$icoCalendario.dpSetSelected("00/00/0000").dpSetDisplayedMonth(d.getMonth(), d.getFullYear())
						}
						setTimeout(function() {
							$icoCalendario.dpClose().click()
						}, 10)
					});
					$(this).blur(function(evt) {
						var $dataCalendario = $(this).closest(".dataCalendario");
						var $icoCalendario = $dataCalendario.find(".ico_calendario");
						var dia = $.trim($dataCalendario.find("input.dia").val());
						var mes = $.trim($dataCalendario.find("input.mes").val());
						var ano = $.trim($dataCalendario.find("input.ano").val());
						if (validaDataDigitada(this, evt)) {
							if (dia != "" && dia.length == 2 && mes != "" && mes.length == 2 && ano != "" && ano.length == 4) {
								$icoCalendario.dpSetSelected(dia + "/" + mes + "/" + ano);
								var $onDS = $dataCalendario.find("#OnDateSelected");
								if ($onDS.length > 0) {
									var selectedDate = new Date(parseInt($icoCalendario.dpGetSelected(), 10));
									eval($onDS.val())
								}
							}
						} else {
							var d = new Date();
							$icoCalendario.dpSetSelected("00/00/0000").dpSetDisplayedMonth(d.getMonth(), d.getFullYear())
						}
					});
					$(this).keyup(function(evt) {
						if ($.checkKey(evt)) {
							validaDataDigitada(this, evt)
						}
					})
				});
				function validaDataDigitada(el, evt) {
					var $camposForm = $(el).closest(".campos_form");
					var $dataCalendario = $(el).closest(".dataCalendario");
					var $icoCalendario = $dataCalendario.find(".ico_calendario");
					var bErroAnterior = false;
					var erro = "";
					var erroDia = false;
					var erroMes = false;
					var erroAno = false;
					var erroLimite = false;
					var contErro = 0;
					var prefixoErro = "Erro: ";
					if ($camposForm.hasClass("form_erro")) {
						bErroAnterior = true
					}
					var elDia = $dataCalendario.find(".dia");
					var elMes = $dataCalendario.find(".mes");
					var elAno = $dataCalendario.find(".ano");
					var dia = $(elDia).val();
					var mes = $(elMes).val();
					var ano = $(elAno).val();
					if ($(el).hasClass("dia") && ((dia == "0") || (dia == "1") || (dia == "2") || (dia == "3")) && (evt.type == "keyup")) {
						dia = ""
					} else {
						if ((dia != "") && (dia.length < 2)) {
							dia = "0"
						}
					}
					if ($(el).hasClass("mes") && ((mes == "0") || (mes == "1")) && (evt.type == "keyup")) {
						mes = ""
					} else {
						if ((mes != "") && (mes.length < 2)) {
							mes = "0"
						}
					}
					if ($(el).hasClass("ano") && (ano.length < 4) && (evt.type == "keyup")) {
						ano = ""
					} else {
						if ((ano != "") && (ano.length < 4)) {
							ano = "0"
						}
					}
					if (dia != "") {
						dia = parseInt(dia, 10)
					} else {
						dia = -1
					}
					if (mes != "") {
						mes = parseInt(mes, 10)
					} else {
						mes = -1
					}
					if (ano != "") {
						ano = parseInt(ano, 10)
					} else {
						ano = -1
					}
					if ((dia == 0) || (dia > 31)) {
						erroDia = true;
						contErro++
					} else {
						if ((dia > 30) && ((mes == 4) || (mes == 6) || (mes == 9) || (mes == 11))) {
							erroDia = true;
							erroMes = true;
							contErro = contErro + 2
						} else {
							if (mes == 2) {
								if (dia > 29) {
									erroDia = true;
									erroMes = true;
									contErro = contErro + 2
								} else {
									if ((dia == 29) && !((ano < 0) || (ano % 4 == 0) && ((ano % 100 != 0) || (ano % 400 == 0)))) {
										erroDia = true;
										erroMes = true;
										erroAno = true;
										contErro = contErro + 3
									}
								}
							}
						}
					}
					if ((!erroMes) && ((mes == 0) || (mes > 12))) {
						erroMes = true;
						contErro++
					}
					if ((!erroAno) && (ano == 0)) {
						erroAno = true;
						contErro++
					}
					if (erroDia) {
						erro = "O dia"
					}
					if (erroMes) {
						if (erroDia && !erroAno) {
							erro = erro + " e o m�s"
						} else {
							if (!erroDia) {
								erro = "O m�s"
							} else {
								erro = erro + ", o m�s"
							}
						}
					}
					if (erroAno) {
						if (erro != "") {
							erro = erro + " e o ano"
						} else {
							erro = "O ano"
						}
					}
					if (contErro == 1) {
						erro = erro + " informado � inv�lido."
					} else {
						if (contErro > 1) {
							erro = erro + " informados s�o inv�lidos."
						} else {
							if ((dia > 0) && (mes > 0) && (ano > 0)) {
								var $onDS = $dataCalendario.find("#OnDateSelected");
								if ($onDS.length > 0) {
									var dataSelecionada = new Date(ano, mes - 1, dia);
									var dataInicial = $dataCalendario.find(".dataInicial").val();
									var dataFinal = $dataCalendario.find(".dataFinal").val();
									var dataAux = new Date();
									if (dataInicial != undefined) {
										dataAux = new Date(parseInt(dataInicial.substring(6, 10), 10), parseInt(dataInicial.substring(3, 5), 10) - 1, parseInt(dataInicial.substring(0, 2), 10));
										if (dataSelecionada < dataAux) {
											erro = "A data deve ser maior ou igual a " + dataInicial + ".";
											contErro = 1;
											erroLimite = true
										}
									} else {
										if (dataFinal != undefined) {
											dataAux = new Date(parseInt(dataFinal.substring(6, 10), 10), parseInt(dataFinal.substring(3, 5), 10) - 1, parseInt(dataFinal.substring(0, 2), 10));
											if (dataSelecionada > dataAux) {
												erro = "A data deve ser menor ou igual a " + dataFinal + ".";
												contErro = 1;
												erroLimite = true
											}
										}
									}
								}
							}
						}
					}
					if (erroDia) {
						incluirErroCampoCal(elDia, erro, prefixoErro);
						if ($(el).hasClass("dia")) {
							evt.stopImmediatePropagation()
						}
					} else {
						removerErroCampoCal(elDia)
					}
					if (erroMes) {
						incluirErroCampoCal(elMes, erro, prefixoErro);
						if ($(el).hasClass("mes")) {
							evt.stopImmediatePropagation()
						}
					} else {
						removerErroCampoCal(elMes)
					}
					if (erroAno) {
						incluirErroCampoCal(elAno, erro, prefixoErro);
						if ($(el).hasClass("ano")) {
							evt.stopImmediatePropagation()
						}
					} else {
						removerErroCampoCal(elAno)
					}
					if (erroLimite) {
						incluirErroCampoCal(elDia, erro, prefixoErro);
						incluirErroCampoCal(elMes, erro, prefixoErro);
						incluirErroCampoCal(elAno, erro, prefixoErro);
						evt.stopImmediatePropagation()
					}
					if (contErro > 0) {
						incluirErroGrupoCampos($camposForm.get(0), erro);
						if (!bErroAnterior && (evt.type == "keyup")) {
							$icoCalendario.dpClose().click()
						}
						return false
					} else {
						removerErroGrupoCampos($camposForm.get(0));
						if (bErroAnterior && (evt.type == "keyup")) {
							$icoCalendario.dpClose().click()
						}
						return true
					}
				}
				$(".tabindex:not(input.dia, input.mes, input.ano, .ico_calendario)").focus(function(evt) {
					$ico_calendario.dpClose()
				});
				function arrDate(dataSelect) {
					date = new Date(dataSelect);
					var d = date.getDate();
					var m = date.getMonth() + 1;
					var y = date.getFullYear();
					if (d < 10) {
						d = "0" + d
					}
					if (m < 10) {
						m = "0" + m
					}
					var arr = new Array(d, m, y);
					return arr
				}
			}
		}
		$("#servico_concessonaria").change(function() {
			$("#loading_concessonaria").removeClass("none_i");
			setTimeout(function() {
				$("#loading_concessonaria").addClass("none_i")
			}, 1000)
		});
		$("#estConc").change(function() {
			$("#loading_concessonaria").removeClass("none_i");
			var vl = $(this).val();
			setTimeout(function() {
				$("#loading_concessonaria").addClass("none_i");
				if (vl == "sp") {
					$("#ConcSaoPaulo").show();
					$("#ConcRio").hide()
				}
				if (vl == "rj") {
					$("#ConcSaoPaulo").hide();
					$("#ConcRio").show()
				}
			}, 1000)
		});
		$("label:not([class*=naoSubstituirLabel])").each(function() {
			var caracteresEspeciaisSeletores = "#;&,.+*~':\"!^$[]()=>|";
			var vFor = $(this).attr("for");
			var vHtml = $(this).html();
			var vClass = $(this).attr("class");
			var vStyle = $(this).attr("style");
			var vId = $(this).attr("id");
			var $span = $("<span>");
			$span.addClass("label");
			if ((vClass != undefined) && (vClass != "")) {
				$span.addClass(vClass)
			}
			if ((vStyle != undefined) && (vStyle != "")) {
				$span.attr("style", vStyle)
			}
			if ((vId != undefined) && (vId != "")) {
				$span.attr("id", vId)
			}
			$span.html(vHtml);
			if ((vFor != undefined) && (vFor != "")) {
				var i, c, p;
				for (i = 0; i < caracteresEspeciaisSeletores.length; i++) {
					c = caracteresEspeciaisSeletores.substring(i, i + 1);
					p = vFor.indexOf(c);
					while (p > -1) {
						vFor = vFor.substring(0, p) + "\\" + vFor.substring(p);
						p = p + 2;
						p = vFor.indexOf(c, p)
					}
				}
				try {
					var $alvo = $("#" + vFor);
					$span.click(function() {
						try {
							if (!$alvo.is(":disabled")) {
								$alvo.focus().select();
								if ($alvo.is(":checkbox")) {
									if ($alvo.is(":checked")) {
										$alvo.removeAttr("checked")
									} else {
										$alvo.attr("checked", "checked")
									}
									$alvo.change();
									$alvo.triggerHandler("click")
								} else {
									if ($alvo.is(":radio")) {
										var change = false;
										if ($alvo.is(":checked")) {
										} else {
											change = true
										}
										$alvo.attr("checked", "checked");
										if (change) {
											$alvo.change()
										}
										$alvo.triggerHandler("click")
									}
								}
							}
						} catch (err) {
						}
					})
				} catch (err) {
				}
			}
			$(this).replaceWith($span)
		});
		$(function() {
			$(".tabAbreFecha tr.click").click(function() {
				$(this).parent("tbody").find("div.expansible").slideToggle();
				$(this).parent("tbody").toggleClass("clicked")
			});
			$(".tabAbreFecha tr.click").hover(function() {
				$(this).addClass("over")
			}, function() {
				$(this).removeClass("over")
			});
			$(".tabOrdena thead tr th a.sortDesc").live("click", function(evt) {
				$(this).removeClass("sortDesc");
				$(this).addClass("sortAsc");
				evt.preventDefault()
			});
			$(".tabOrdena thead tr th a.sortAsc").live("click", function(evt) {
				$(this).removeClass("sortAsc");
				$(this).addClass("sortDesc");
				evt.preventDefault()
			});
			$(".tabOrdena thead tr th a.sortOff").live("click", function(evt) {
				$(".tabOrdena thead tr th a").each(function() {
					$(this).addClass("sortOff");
					$(this).removeClass("sortDesc");
					$(this).removeClass("sortAsc")
				});
				$(this).removeClass("sortOff");
				$(this).addClass("sortDesc");
				evt.preventDefault()
			})
		});
		$(".btn_horarios_limites").click(function(evt) {
			var status = $(this).hasClass("active");
			var box = $(this).parent().next();
			$(this).toggleClass("active");
			if (status) {
				box.slideUp(200)
			} else {
				box.slideDown(200)
			}
			salvaStatusHorarioLimite(!status, codigoTela, numeroPasso)
		});
		if (codigoTela && numeroPasso) {
			obtemStatusHorarioLimiteConfiguradoAssicrono(codigoTela, numeroPasso)
		}
		$(document).keypress(function(e) {
			if ($(e.target).is(":input") || $(".jqmWindow").is(":visible")) {
				return
			}
			if (e.which == 97 || e.which == 65) {
				parent.abrirAcessoRapido();
				return false
			}
			if (e.which == 90) {
				parent.abrirAcessoRapido2();
				return false
			}
		})
	});
	$(window).load(function() {
		$.criaTooltips();
		if (!$(".semAutoTab").length) {
			$.tabindex()
		}
		$("#lateral_apoio_atendimento a").removeAttr("tabindex")
	});
	$.highLight = function(value, term) {
		return value.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + term.replace(/([\^\$\(\)\[\]\{\}\*\.\+\?\|\\])/gi, "\\$1") + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<strong>$1</strong>")
	};
	$.extend($.expr[":"], {
		containsI : function(elem, i, match, array) {
			return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0
		}
	});
	$.fn.caret = function(pos) {
		var el = $(this).get(0);
		var caretPos;
		if (pos >= 0) {
			caretPos = pos;
			if (document.selection) {
				var range;
				range = document.selection.createRange();
				if (el.type == "text") {
					range.moveStart("character", -el.value.length);
					range.moveEnd("character", -el.value.length);
					range.moveStart("character", caretPos);
					range.select()
				} else {
					range.collapse(false);
					range.move("character", caretPos - el.value.length + el.value.substring(caretPos).split("\n").length - 1);
					range.select()
				}
			} else {
				if (el.selectionStart || el.selectionStart == "0") {
					el.setSelectionRange(caretPos, caretPos)
				}
			}
		} else {
			caretPos = 0;
			if (document.selection) {
				if (el.type == "text") {
					var selectionRange = document.selection.createRange();
					selectionRange.moveStart("word", -el.value.length);
					caretPos = selectionRange.text.length
				} else {
					caretPos = Math.abs(document.selection.createRange().moveStart("character", -1000000)) - 193
				}
			} else {
				if (el.selectionStart || el.selectionStart == "0") {
					caretPos = el.selectionStart
				}
			}
			return caretPos
		}
	}
})(jQuery);
var currentFocus = null;
var focusStack = [];
function focoPrimeiro() {
	var b = jQuery(".tabindex");
	var a = jQuery(".tabindex[tabindex=2]");
	if (a.length > 0) {
		a[0].focus()
	}
}
function focoUltimo() {
	var c = jQuery(".tabindex");
	if (c.length > 1) {
		var b = c.length - 1;
		for (; b > 0; b--) {
			var a = jQuery(".tabindex[tabindex=" + b + "]:visible");
			if (a.length > 0) {
				a[0].focus();
				break
			}
		}
	}
}
function analisaExibicaoErroSessao(d) {
	var a = 'var urlTriggerFimSessao = "([^"]*)";';
	var c = new RegExp(a);
	var b = c.exec(d);
	if (b != null) {
		window.top.location = b[1];
		return true
	} else {
		return false
	}
}
if (typeof (A4J) != "undefined") {
	A4J.AJAX.onError = function(c, a, b) {
		if (a == 401) {
			analisaExibicaoErroSessao(c.getResponseText())
		}
	}
}
jQuery(document).ajaxError(function(d, e, a, c) {
	try {
		if (e.status == 401) {
			analisaExibicaoErroSessao(e.responseText)
		}
	} catch (b) {
	}
});
function fonefacil() {
	url = "http://www.bradesco.com.br/indexpf.phtml?pag=/html/content/centrais/fone_facil.shtm";
	if (typeof (isPrime) != "undefined") {
		if (isPrime) {
			url = "http://www.bradescoprime.com.br/Conteudo/centrais/fone.aspx"
		}
	}
	window.open(url, "popup");
	return false
}
function aplicaTamanhoFonte(b, c, e) {
	try {
		jQuery(b, c.document.body).removeClass().addClass("miolo mioloFs1" + (e + 1) + " after")
	} catch (d) {
		return
	}
	for (var a = 0; a < c.frames.length; a++) {
		aplicaTamanhoFonte(b, c.frames[a], e)
	}
}
function existeTamanhoFonte(b) {
	var d = false;
	try {
		var a = jQuery(".listaPersonalizacao .tp2", b.document.body);
		if (a.length > 0) {
			d = true
		} else {
			if (b.parent != b) {
				d = existeTamanhoFonte(b.parent)
			}
		}
	} catch (c) {
		d = false
	}
	return d
}
function callbackObtencaoTamanhoFonte(c) {
	try {
		if (c != null) {
			var d;
			for (iConteudo = 0; iConteudo < c.length; iConteudo++) {
				d = c[iConteudo];
				if (d && jQuery.trim(d.getChave()) == "tamanho") {
					e = d.getValor();
					break
				}
			}
		}
		if ((e == null) || (e == "") || (isNaN(e))) {
			e = "1"
		}
	} catch (f) {
		e = obtemCookie("tamanhoFonte");
		if ((e == null) || (e == "") || (isNaN(e))) {
			e = "1"
		}
		return (parseInt(e, 10))
	}
	var g = (parseInt(e, 10));
	var e = [];
	var b = jQuery(".listaPersonalizacao .tp2");
	var a = "#conteudo > .miolo";
	if (b.length > 0) {
		e[0] = b;
		e[1] = jQuery(".listaPersonalizacao .tp3");
		e[2] = jQuery(".listaPersonalizacao .tp4");
		inicializando = true;
		jQuery(e[g - 1]).click();
		inicializando = false
	} else {
		if ((window.parent != window) && (existeTamanhoFonte(window.parent))) {
			aplicaTamanhoFonte(a, window, g)
		}
	}
	if (window.parent.autoIframe) {
		window.parent.autoIframe()
	}
}
function obtemTamanhoFonteConfiguradoAssincrono(c, a) {
	var b = getComponentePersonalizacao();
	b.obterCategoria("ibpf.geral.tamanhoFonte", c, a, callbackObtencaoTamanhoFonte)
}
function obtemTamanhoFonteConfigurado(e, b) {
	var g = null;
	try {
		var d = getComponentePersonalizacao();
		var a = d.obterCategoria("ibpf.geral.tamanhoFonte", e, b);
		if (a != null) {
			var c;
			for (iConteudo = 0; iConteudo < a.length; iConteudo++) {
				c = a[iConteudo];
				if (c && jQuery.trim(c.getChave()) == "tamanho") {
					g = c.getValor();
					break
				}
			}
		}
		if ((g == null) || (g == "") || (isNaN(g))) {
			g = "1"
		}
	} catch (f) {
		g = obtemCookie("tamanhoFonte");
		if ((g == null) || (g == "") || (isNaN(g))) {
			g = "1"
		}
		return (parseInt(g, 10))
	}
	return (parseInt(g, 10))
}
function salvaTamanhoFonte(f, c, a) {
	try {
		var b = getComponentePersonalizacao();
		var e = new Array();
		e.push(new Conteudo("tamanho", f));
		b.salvarCategoriaArray("ibpf.geral.tamanhoFonte", e, c, a)
	} catch (d) {
		setaCookie("tamanhoFonte", "", -1);
		setaCookie("tamanhoFonte", "", -1, "/");
		setaCookie("tamanhoFonte", f, 365, "/", document.domain)
	}
}
function inicializaUIFontSize(b) {
	var a = JSON.stringify({
		fontSize : obtemTamanhoFonteConfigurado()
	});
	return a
}
function salvaUIFontSize(b) {
	var a = JSON.parse(b.state);
	salvaTamanhoFonte(a.fontSize);
	if (window.parent.autoIframe) {
		setTimeout("window.parent.autoIframe()", 300)
	}
}
function callbackObtencaoHorariosLimites(b) {
	var a = null;
	try {
		if (b != null) {
			var d;
			for (iConteudo = 0; iConteudo < b.length; iConteudo++) {
				d = b[iConteudo];
				if (d && jQuery.trim(d.getChave()) == "horariosLimites") {
					a = d.getValor();
					break
				}
			}
		}
		if ((a == null) || (a == "")) {
			a = "false"
		}
	} catch (e) {
		var c = jQuery(".txt-codigoTela").text();
		var f = "horariosLimites" + (jQuery.trim(c) != "" ? "." + c : "");
		var a = obtemCookie(f);
		return !(a === "false")
	}
	var g = !(a === "false");
	var a = g;
	jQuery(".btn_horarios_limites").each(function() {
		var h = jQuery(this).parent().next();
		if (!a) {
			jQuery(this).removeClass("active");
			h.hide()
		}
	});
	if (window.parent.autoIframe) {
		window.parent.autoIframe()
	}
}
function obtemStatusHorarioLimiteConfiguradoAssicrono(c, a) {
	try {
		var b = getComponentePersonalizacao();
		b.obterCategoria("ibpf." + c + "." + a, c, a, callbackObtencaoHorariosLimites)
	} catch (d) {
	}
}
function obtemStatusHorarioLimiteConfigurado(f, c) {
	var a = null;
	try {
		var e = getComponentePersonalizacao();
		var b = e.obterCategoria("ibpf." + f + "." + c, f, c);
		if (b != null) {
			var d;
			for (iConteudo = 0; iConteudo < b.length; iConteudo++) {
				d = b[iConteudo];
				if (d && jQuery.trim(d.getChave()) == "horariosLimites") {
					a = d.getValor();
					break
				}
			}
		}
		if ((a == null) || (a == "")) {
			a = "false"
		}
	} catch (g) {
		var f = jQuery(".txt-codigoTela").text();
		var h = "horariosLimites" + (jQuery.trim(f) != "" ? "." + f : "");
		var a = obtemCookie(h);
		return !(a === "false")
	}
	return !(a === "false")
}
function salvaStatusHorarioLimite(a, d, b) {
	try {
		var c = getComponentePersonalizacao();
		var g = new Array();
		g.push(new Conteudo("horariosLimites", a));
		c.salvarCategoriaArray("ibpf." + d + "." + b, g, d, b)
	} catch (e) {
		var d = jQuery(".txt-codigoTela").text();
		var f = "horariosLimites" + (jQuery.trim(d) != "" ? "." + d : "");
		setaCookie(f, a, 365, "/", document.domain)
	}
}
function inicializaUICollapsibleArea(c) {
	var b = "" + !obtemStatusHorarioLimiteConfigurado();
	var a = JSON.stringify({
		collapsed : b
	});
	return a
}
function salvaUICollapsibleArea(b) {
	var a = JSON.parse(b.state);
	salvaStatusHorarioLimite(a.collapsed === "false");
	if (window.parent.autoIframe) {
		setTimeout("window.parent.autoIframe()", 300)
	}
}
function incluirErroCampoCal(c, a, b) {
	jQuery(c).each(function() {
		jQuery(this).addClass("erro_input");
		if (jQuery(this).attr("title") == undefined) {
			jQuery(this).attr("title", "")
		}
		if (jQuery(this).attr("title_ori") == undefined) {
			jQuery(this).attr("title_ori", jQuery(this).attr("title"))
		}
		jQuery(this).attr("title", b + a + " " + jQuery(this).attr("title_ori"))
	})
}
function removerErroCampoCal(a) {
	jQuery(a).each(function() {
		jQuery(this).removeClass("erro_input");
		jQuery(this).attr("title", jQuery(this).attr("title_ori"))
	})
}
function incluirErroGrupoCampos(b, a) {
	jQuery(b).addClass("form_erro").find(".erro_msg").html("<strong>" + a + "</strong>")
}
function removerErroGrupoCampos(a) {
	jQuery(a).removeClass("form_erro").find(".erro_msg").html("<strong></strong>")
}
function aplicaFormatacaoCalendario(a) {
	var p = "UICalendar_";
	var r = "error";
	if (a.type != undefined) {
		try {
			console.log("data");
			console.log(a)
		} catch (n) {
		}
		var f = a.dayObject;
		var o = a.monthObject;
		var d = a.yearObject;
		var s = (a.day == "INVALID");
		var m = (a.month == "INVALID");
		var q = (a.year == "INVALID");
		var j = (a.period == "INVALID");
		var c = !a.overall;
		var b = jQuery(d).closest(".campos_form").get(0);
		var k = replaceAscii(obtemMensagemBundle(a.bundleFunction, a.bundlePrefix, "UICalendar_title_prefix"));
		if ((k != "") && (k.substring(k.length - 1) != " ")) {
			k += " "
		}
		var h = "";
		var g = "";
		if (s || m || q) {
			if (s) {
				h += "day_"
			}
			if (m) {
				h += "month_"
			}
			if (q) {
				h += "year_"
			}
			h = p + h + r;
			g = replaceAscii(obtemMensagemBundle(a.bundleFunction, a.bundlePrefix, h));
			if (s) {
				incluirErroCampoCal(f, g, k)
			} else {
				removerErroCampoCal(f)
			}
			if (m) {
				incluirErroCampoCal(o, g, k)
			} else {
				removerErroCampoCal(o)
			}
			if (q) {
				incluirErroCampoCal(d, g, k)
			} else {
				removerErroCampoCal(d)
			}
		} else {
			if (j) {
				c = true;
				h = p + "limit_" + r;
				g = replaceAscii(obtemMensagemBundle(a.bundleFunction, a.bundlePrefix, h))
			}
		}
		if (c) {
			incluirErroGrupoCampos(b, g)
		} else {
			removerErroGrupoCampos(b)
		}
	} else {
		try {
			console.log("periodo");
			console.log(a)
		} catch (n) {
		}
		var j = !a.period;
		var l = "#" + a.beginDayID.replace(":", "\\:");
		var b = jQuery(l).closest(".campos_form").get(0);
		if (j) {
			h = p + "period_" + r;
			g = replaceAscii(obtemMensagemBundle(a.bundleFunction, a.bundlePrefix, h));
			incluirErroGrupoCampos(b, g)
		} else {
			removerErroGrupoCampos(b)
		}
	}
}
function obtemMensagemBundle(b, c, e) {
	var a = new Function("return " + b + "();")();
	var d = a[c + e];
	if (d == null || d == undefined) {
		d = a[e]
	}
	if (d == null || d == undefined) {
		d = ""
	}
	return d
}
function replaceAscii(b) {
	var c = b.indexOf("&#");
	var e = b.indexOf(";", c);
	while (c >= 0 && e > c) {
		var a = b.substring(c + 2, e);
		if (a > 0) {
			var d = String.fromCharCode(a);
			b = b.replace("&#" + a + ";", d)
		}
		c = b.indexOf("&#", c + 1);
		e = b.indexOf(";", c)
	}
	return b
}
function setaCookie(a, e, c, d, f) {
	var b = new Date();
	if (c) {
		b.setDate(b.getDate() + c)
	}
	document.cookie = a + "=" + escape(e) + ((c) ? ";expires=" + b.toUTCString() : "") + ((d) ? ";path=" + d : "") + ((f) ? ";domain=" + f : "")
}
function obtemCookie(b) {
	if (document.cookie.length > 0) {
		var c = document.cookie.indexOf(b + "=");
		if (c != -1) {
			c = c + b.length + 1;
			var a = document.cookie.indexOf(";", c);
			if (a == -1) {
				a = document.cookie.length
			}
			return unescape(document.cookie.substring(c, a))
		}
	}
	return ""
}
var personalizacaoContexto = "/ibpfpersonalizacaocomponente";
function Cookie(a) {
	this.cliente = a;
	this.init = function() {
	};
	this.obterCategoria = function(b) {
		var e = null;
		var c = this.gerarChave(b);
		var d = jQuery.cookie(c);
		if (d) {
			e = new Categoria(b);
			e.setStringConteudo(d)
		}
		return e
	};
	this.salvarCategoria = function(d) {
		var c = this.gerarChave(d.getNome());
		var b = {
			expires : 7
		};
		jQuery.cookie(c, d.getStringConteudo(), b)
	};
	this.obter = function(c, b) {
		var e = null;
		var d = this.obterCategoria(c);
		if (d) {
			e = d.obterValorConteudo(b)
		}
		return e
	};
	this.salvar = function(c, b, d) {
		var f = new Categoria(c);
		var e = this.obterCategoria(f);
		if (e) {
			e.adicionarConteudo(new Conteudo(b, d));
			f = e
		} else {
			f.adicionarConteudo(new Conteudo(b, d))
		}
		this.salvarCategoria(f)
	};
	this.remover = function(c, b) {
		var d = this.obterCategoria(c);
		if (d) {
			if (d.removerConteudo(b)) {
				this.salvarCategoria(d)
			}
		}
	};
	this.removerCategoria = function(b) {
		var c = this.gerarChave(b);
		jQuery.cookie(c, null)
	};
	this.gerarChave = function(b) {
		var c = this.cliente.getChave() + "." + b;
		return c
	}
}
function CacheJavaScript(a) {
	this.cliente = a;
	this.init = function(b) {
		jQuery.jCache.maxSize = b
	};
	this.salvarCategoria = function(c) {
		var b = this.gerarChave(c.getNome());
		jQuery.jCache.setItem(b, c.getStringConteudo())
	};
	this.obterCategoria = function(b) {
		var e = null;
		var c = this.gerarChave(b);
		var d = jQuery.jCache.getItem(c);
		if (d) {
			e = new Categoria(b);
			e.setStringConteudo(d)
		}
		return e
	};
	this.obter = function(c, b) {
		var e = null;
		var d = this.obterCategoria(c);
		if (d) {
			e = d.obterValorConteudo(b)
		}
		return e
	};
	this.salvar = function(c, b, d) {
		var f = new Categoria(c);
		var e = this.obterCategoria(f);
		if (e) {
			e.adicionarConteudo(new Conteudo(b, d));
			f = e
		} else {
			f.adicionarConteudo(new Conteudo(b, d))
		}
		this.salvarCategoria(f)
	};
	this.gerarChave = function(b) {
		var c = this.cliente.getChave() + "." + b;
		return c
	};
	this.remover = function(c, b) {
		var d = this.obterCategoria(c);
		if (d) {
			if (d.removerConteudo(b)) {
				this.salvarCategoria(d)
			}
		}
	};
	this.removerCategoria = function(b) {
		var c = this.gerarChave(b);
		jQuery.jCache.removeItem(c)
	}
}
function BaseDados(a) {
	this.cliente = a;
	this.init = function() {
	};
	this.salvarCategoria = function(e, b, c) {
		var d = new Array();
		d.push(e);
		this.salvarArrayCategoria(d, b, c)
	};
	this.salvar = function(e, d, f, b, c) {
		var g = new Categoria(e);
		g.adicionarConteudo(new Conteudo(d, f));
		this.salvarCategoria(g, b, c)
	};
	this.obterCategoria = function(e, b, c, f) {
		var g = null;
		var h = "CTL=" + this.cliente.getCTL() + "&$action=personalizacaoBean&$method=obterCategoria";
		h += "&codServico=" + b + "&numPasso=" + c;
		h += "&nomeCategoria=" + e;
		var d = this;
		if (f) {
			jQuery.ajax({
				type : "POST",
				url : personalizacaoContexto + "/obterCategoria.ajax",
				data : h,
				dataType : "text",
				success : function(j) {
					g = d.parserCategoria(j);
					f.finalizar(g)
				},
				error : function() {
				},
				async : true
			})
		} else {
			jQuery.ajax({
				type : "POST",
				url : personalizacaoContexto + "/obterCategoria.ajax",
				data : h,
				dataType : "text",
				success : function(j) {
					g = d.parserCategoria(j)
				},
				error : function() {
				},
				async : false
			})
		}
		return g
	};
	this.obter = function(f, e, b, c) {
		var h = null;
		var g = null;
		var j = "CTL=" + this.cliente.getCTL() + "&$action=personalizacaoBean&$method=obterConteudo";
		j += "&codServico=" + b + "&numPasso=" + c;
		j += "&nomeCategoria=" + f + "&nomeConteudo=" + e;
		var d = this;
		jQuery.ajax({
			type : "POST",
			url : personalizacaoContexto + "/obterConteudo.ajax",
			data : j,
			dataType : "text",
			success : function(k) {
				g = d.parserCategoria(k)
			},
			error : function() {
			},
			async : false
		});
		if (g != null && g.getArrayConteudo()) {
			h = g.getArrayConteudo()[0].getValor()
		}
		return h
	};
	this.salvarArrayCategoria = function(f, b, c) {
		var g = "CTL=" + this.cliente.getCTL() + "&$action=personalizacaoBean&$method=salvarCategoria";
		g += "&codServico=" + b + "&numPasso=" + c;
		var e = this.montarXML(f);
		var d = this;
		jQuery.ajax({
			type : "POST",
			url : personalizacaoContexto + "/salvarCategoria.ajax?" + g,
			data : {
				xml : escape(e)
			},
			success : function(h) {
			},
			error : function() {
			},
			async : true
		})
	};
	this.parserCategoria = function(e) {
		var d = null;
		var c = e.indexOf("&");
		if (c > 0) {
			var b = e.substring(0, c);
			var f = b.split("=");
			if (f[0] == "nomeCategoria") {
				d = new Categoria(f[1]);
				d.setStringConteudo(e.substring(c + 1, e.length))
			}
		}
		return d
	};
	this.montarXML = function(b) {
		var c = "<?xml version='1.0' encoding='UTF-8'?><documento>";
		for (i = 0; i < b.length; i++) {
			var d = b[i];
			c += "<categoria nome='" + d.getNome() + "'>";
			c += "<conteudo><![CDATA[" + d.getStringConteudo() + "]]></conteudo>";
			c += "</categoria>"
		}
		c += "</documento>";
		return c
	};
	this.removerCategoria = function(b) {
	};
	this.remover = function(c, b) {
	}
}
function CallbackPersonalizacaoComponente(b, g, c, e, a, d, f) {
	this.modoGravacao = e;
	this.modoGravacaoCookie = a;
	this.modoGravacaoBase = d;
	this.nomeCategoria = b;
	this.cd_servico = g;
	this.numero_passo = c;
	this._infra_sei_funcaoCallback = f;
	this.finalizar = function(j) {
		this.modoGravacao = this.modoGravacaoCookie;
		var l = null;
		var h = this.modoGravacao.obterCategoria(this.nomeCategoria, this.cd_servico, this.numero_passo);
		if (h != null) {
			h.adicao(j);
			l = h
		} else {
			l = j
		}
		var k = null;
		if (l) {
			k = l.getArrayConteudo()
		}
		this._infra_sei_funcaoCallback(k)
	}
}
function Wrapper(a) {
	this.CTL = a.getCTL();
	this.modoGravacaoCookie = new Cookie(a);
	this.modoGravacaoBase = new BaseDados(a);
	this.modoGravacao = this.modoGravacaoCookie;
	this.dadosBase = new Array();
	this.salvar = function(e, d, f, b, c) {
		var g = new Conteudo(d, f);
		var h = new Array();
		h.push(g);
		this.salvarCategoria(new Categoria(e, h), b, c)
	};
	this.salvarCategoria = function(f, b, c) {
		var e = this.verificarListaBase(f);
		f.diff(e);
		this.modoGravacao = this.modoGravacaoCookie;
		if (f.getArrayConteudo().length > 0) {
			var d = f.getStringConteudo();
			categoriaExistente = this.modoGravacao.obterCategoria(f.getNome(), b, c);
			if (categoriaExistente) {
				categoriaExistente.adicao(f);
				f = categoriaExistente
			}
			this.modoGravacao.salvarCategoria(f, b, c)
		}
		this.modoGravacao = this.modoGravacaoBase;
		if (e.getArrayConteudo().length > 0) {
			this.modoGravacao.salvarCategoria(e, b, c)
		}
	};
	this.obter = function(e, d, b, c) {
		var h = new Categoria(e);
		h.adicionarConteudo(new Conteudo(d));
		var g = null;
		var f = this.verificarListaBase(h);
		if (f.getArrayConteudo().length > 0) {
			this.modoGravacao = this.modoGravacaoBase;
			g = this.modoGravacao.obter(e, d, b, c)
		} else {
			this.modoGravacao = this.modoGravacaoCookie;
			g = this.modoGravacao.obter(e, d, b, c)
		}
		return g
	};
	this.obterCategoria = function(g, b, d, h) {
		this.modoGravacao = this.modoGravacaoCookie;
		var e = null;
		var f = null;
		var k = this.modoGravacao.obterCategoria(g, b, d);
		var j = this.verificarStringListaBase(g);
		if (j.getArrayConteudo().length != 0) {
			if (h) {
				this.modoGravacao = this.modoGravacaoBase;
				var c = new CallbackPersonalizacaoComponente(g, b, d, this.modoGravacao, this.modoGravacaoCookie, this.modoGravacaoBase, h);
				this.modoGravacao.obterCategoria(j.getNome(), b, d, c)
			} else {
				this.modoGravacao = this.modoGravacaoBase;
				f = this.modoGravacao.obterCategoria(j.getNome(), b, d);
				if (k != null) {
					k.adicao(f);
					e = k
				} else {
					e = f
				}
			}
		} else {
			if (h) {
				var c = new CallbackPersonalizacaoComponente(g, b, d, this.modoGravacao, this.modoGravacaoCookie, this.modoGravacaoBase, h);
				c.finalizar(k)
			} else {
				e = k
			}
		}
		return e
	};
	this.init = function() {
		var c = "CTL=" + this.CTL + "&$action=personalizacaoBaseBean&$method=obterInformacoes";
		var b = this;
		jQuery.ajax({
			type : "POST",
			url : personalizacaoContexto + "/personalizacaoBase.ajax",
			data : c,
			dataType : "text",
			success : function(d) {
				b.processarLista(d)
			},
			error : function() {
			},
			async : false
		})
	};
	this.processarLista = function(b) {
		this.dadosBase = b.split("&");
		this.dadosBase.sort()
	};
	this.binarySearch = function(d, f) {
		var e = this.dadosBase.length, b = -1, c;
		while (e - b > 1) {
			if (this.dadosBase[c = e + b >> 1] < d) {
				b = c
			} else {
				e = c
			}
		}
		return this.dadosBase[e] != d ? f ? e : -1 : e
	};
	this.verificarListaBase = function(f) {
		var b = f.getNome();
		var d = f.getArrayConteudo();
		var c = new Categoria(b);
		for (pos = 0; pos < d.length; pos++) {
			var e = this.binarySearch(b + "." + d[pos].getChave());
			if (e >= 0) {
				c.adicionarConteudo(d[pos])
			}
		}
		return c
	};
	this.verificarStringListaBase = function(c) {
		var d = new Categoria(c);
		c += ".";
		var e = this.binarySearch(c, true);
		if (e < 0) {
			e = -e
		}
		for (pos = e; pos < this.dadosBase.length; pos++) {
			var b = this.dadosBase[pos].replace(c, "");
			if (b == null) {
				break
			}
			if (b.indexOf(".") == -1) {
				d.adicionarConteudo(new Conteudo(b))
			}
		}
		return d
	}
}
function PersonalizacaoComponente() {
	this.wrapper = null;
	this.inicializado = "false";
	this.isInicializado = function() {
		return this.inicializado
	};
	this.setCliente = function(a, d, b, c) {
		this.wrapper = new Wrapper(new Cliente(a, d, b, c));
		this.wrapper.init();
		this.inicializado = "true"
	};
	this.salvarCategoria = function(c, a, b) {
		if (this.wrapper) {
			this.wrapper.salvarCategoria(c, a, b)
		}
	};
	this.salvarCategoriaArray = function(c, d, a, b) {
		if (this.wrapper) {
			var e = new Categoria(c, d);
			this.wrapper.salvarCategoria(e, a, b)
		}
	};
	this.obterCategoria = function(c, a, b, e) {
		if (this.wrapper) {
			var d = null;
			var f = this.wrapper.obterCategoria(c, a, b, e);
			if (f) {
				d = f.getArrayConteudo()
			}
			return d
		}
	};
	this.salvar = function(d, c, e, a, b) {
		if (this.wrapper) {
			this.wrapper.salvar(d, c, e, a, b)
		}
	};
	this.obter = function(d, c, a, b) {
		if (this.wrapper) {
			return this.wrapper.obter(d, c, a, b)
		}
		return null
	};
	this.setWrapper = function(a) {
		this.wrapper = a
	}
}
function Categoria(a, b) {
	this.nome = a;
	if (b) {
		this.arrayConteudo = b
	} else {
		this.arrayConteudo = new Array()
	}
	this.getNome = function() {
		return this.nome
	};
	this.getArrayConteudo = function() {
		return this.arrayConteudo
	};
	this.adicionarConteudo = function(c) {
		if (!this.arrayConteudo) {
			this.arrayConteudo = new Array()
		}
		var d = this.obterIndiceConteudo(c.getChave());
		if (d != null) {
			this.arrayConteudo[d] = c
		} else {
			this.arrayConteudo.push(c)
		}
	};
	this.obterIndiceConteudo = function(d) {
		var e = null;
		if (this.arrayConteudo) {
			for (var c = 0; c < this.arrayConteudo.length; c++) {
				if (this.arrayConteudo[c].getChave() == d) {
					e = c;
					break
				}
			}
		}
		return e
	};
	this.obterConteudo = function(d) {
		var c = null;
		var e = this.obterIndiceConteudo(d);
		if (e != null) {
			c = this.arrayConteudo[e]
		}
		return c
	};
	this.obterValorConteudo = function(e) {
		var c = null;
		var d = this.obterConteudo(e);
		if (d) {
			c = d.getValor()
		}
		return c
	};
	this.removerConteudo = function(c) {
		var e = false;
		if (this.arrayConteudo) {
			for (var d = 0; d < this.arrayConteudo.length; d++) {
				if (this.arrayConteudo[d].getChave() == c) {
					this.arrayConteudo.splice(d, 1);
					e = true;
					break
				}
			}
		}
		return e
	};
	this.getStringConteudo = function() {
		var c = null;
		var e = new Array();
		if (this.arrayConteudo) {
			for (var d = 0; d < this.arrayConteudo.length; d++) {
				e.push(this.arrayConteudo[d].getChave() + "=" + this.arrayConteudo[d].getValor())
			}
			c = e.join("&")
		}
		return c
	};
	this.diff = function(f) {
		if (this.nome == f.getNome()) {
			var d = f.getArrayConteudo();
			if (d) {
				for (var c = 0; c < d.length; c++) {
					var e = this.obterIndiceConteudo(d[c].getChave());
					if (e != null) {
						this.arrayConteudo.splice(e, 1)
					}
				}
			}
		}
	};
	this.adicao = function(f) {
		if (this.nome == f.getNome()) {
			var e = f.getArrayConteudo();
			if (e) {
				for (var c = 0; c < e.length; c++) {
					var d = this.obterConteudo(e[c].getChave());
					if (d) {
						d.setValor(e[c].getValor())
					} else {
						this.arrayConteudo.push(e[c])
					}
				}
			}
		}
	};
	this.setStringConteudo = function(g) {
		this.arrayConteudo = new Array();
		var f = g.split("&");
		for (var d = 0; d < f.length; d++) {
			var c = f[d].split("=");
			if (c[0] && c[1]) {
				var e = new Conteudo(c[0], c[1]);
				this.arrayConteudo.push(e)
			}
		}
	}
}
function Conteudo(b, a) {
	this.chave = b;
	this.valor = a;
	this.getChave = function() {
		return this.chave
	};
	this.getValor = function() {
		return this.valor
	};
	this.setValor = function(c) {
		return this.valor = c
	}
}
function Cliente(a, d, b, c) {
	this.agencia = a;
	this.conta = d;
	this.titularidade = b;
	this.CTL = c;
	this.getAgencia = function() {
		return this.agencia
	};
	this.getConta = function() {
		return this.conta
	};
	this.getTitularidade = function() {
		return this.getTitularidade()
	};
	this.getCTL = function() {
		return this.CTL
	};
	this.getChave = function() {
		return this.agencia + "_" + this.conta + "_" + this.titularidade
	}
}
function inicializarComponentePersonalizacao(a, e, b, d) {
	var c = (window.top) ? window.top : window;
	c.personalizacao = new PersonalizacaoComponente();
	c.personalizacao.setCliente(a, e, b, d)
}
function getComponentePersonalizacao() {
	var c = (window.top) ? window.top : window;
	if (!c.personalizacao) {
		c.personalizacao = new PersonalizacaoComponente();
		var a = c.document.getElementsByName("agencia");
		var e = c.document.getElementsByName("conta");
		var b = c.document.getElementsByName("titularidade");
		var d = c.document.getElementsByName("CTL");
		if (a.length == 1 && e.length == 1 && b.length == 1 && d.length == 1) {
			c.personalizacao.setCliente(a[0].value, e[0].value, b[0].value, d[0].value)
		}
	}
	return c.personalizacao
}
function disableTabFirst() {
	flagTabFirst = false
}
function createCookie(c, d, e) {
	if (e) {
		var b = new Date();
		b.setTime(b.getTime() + (e * 24 * 60 * 60 * 1000));
		var a = "; expires=" + b.toGMTString()
	} else {
		var a = ""
	}
	document.cookie = c + "=" + d + a + "; path=/" + location.pathname.split("/")[1]
}
function readCookie(b) {
	var e = b + "=";
	var a = document.cookie.split(";");
	for (var d = 0; d < a.length; d++) {
		var f = a[d];
		while (f.charAt(0) == " ") {
			f = f.substring(1, f.length)
		}
		if (f.indexOf(e) == 0) {
			return f.substring(e.length, f.length)
		}
	}
	return null
}
function eraseCookie(a) {
	document.cookie = a + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
	document.cookie = a + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/" + location.pathname.split("/")[1]
}
function setJSessionId() {
	var a = readCookie("JSESSIONID");
	if (a != loginRealCookie) {
		if (a != null && a.indexOf(loginCookie) > -1) {
			loginRealCookie = a
		}
		eraseCookie("JSESSIONID");
		createCookie("JSESSIONID", loginRealCookie)
	}
};