$(function() {
	var a = {
		requestURL : "../SHAREDDATA/XML/homeHighlights.xml"
	};
	var c = {
		menu : "false",
		wmode : "transparent"
	};
	var b = {};
	swfobject.embedSWF("../../swf/10_495_banners_area_logada_veiculos_sb.swf", "flashHome", "692", "190", "9.0.0", "", a, c, b)
});
function ajustaTitleCollapsibleArea() {
	jQuery(".UICollapsibleArea-trigger").each(function() {
		if (jQuery(this).hasClass("active")) {
			jQuery(this).attr("title", "Pressione ENTER para ocultar " + jQuery(this).html())
		} else {
			jQuery(this).attr("title", "Pressione ENTER para exibir " + jQuery(this).html())
		}
	})
}
jQuery(document).ready(function() {
	setTimeout("ajustaTitleCollapsibleArea()", 250);
	jQuery(".UICollapsibleArea-trigger").click(function() {
		if (jQuery(this).hasClass("active")) {
			jQuery(this).attr("title", "Pressione ENTER para exibir " + jQuery(this).html())
		} else {
			jQuery(this).attr("title", "Pressione ENTER para ocultar " + jQuery(this).html())
		}
		setTimeout("window.parent.autoIframe()", 450)
	});
	jQuery(".legendasExp").click(function() {
		if (!jQuery(this).hasClass("ativo")) {
			jQuery(this).attr("title", "Pressione ENTER para fechar as informa��es  sobre a Legenda do Status da Simula��o do Financiamento")
		} else {
			jQuery(this).attr("title", "Pressione ENTER para abrir as informa��es  sobre a Legenda do Status da Simula��o do Financiamento")
		}
	});
	jQuery(".bto_input").click(function() {
		setTimeout("window.parent.autoIframe()", 10)
	});
	jQuery(".expansaoLnk").click(function() {
		setTimeout("window.parent.autoIframe()", 10)
	});
	jQuery(".UIFontSize-li").click(function() {
		setTimeout("window.parent.autoIframe()", 10)
	});
	jQuery(".homeBF").click(function() {
		jQuery("body").removeAttr("id")
	});
	jQuery(".navMenuSuperior li.tp1").click(function() {
		jQuery("body").attr("id", "simular")
	});
	jQuery(".navMenuSuperior li.tp2").click(function() {
		jQuery("body").attr("id", "localizar")
	});
	jQuery(".navMenuSuperior li.tp3").click(function() {
		jQuery("body").attr("id", "relatorios")
	});
	jQuery(".navMenuSuperior li.tp4").click(function() {
		jQuery("body").attr("id", "gerenciar")
	})
});
function definirOrigemCEP(a) {
	jQuery("#origemBuscaCEP").val(a)
}
function atualizaSaudacao(c, a, d) {
	if (d >= 59) {
		d = -1;
		a = a + 1;
		if (a >= 60) {
			a = 0;
			c = c + 1;
			if (c >= 24) {
				c = 0
			}
		}
	}
	d = d + 1;
	var b = "Boa noite, ";
	if (0 <= c && c < 12) {
		b = "Bom dia, "
	} else {
		if (12 <= c && c < 18) {
			b = "Boa tarde, "
		}
	}
	document.getElementById("saudacao").innerHTML = b;
	setTimeout("atualizaSaudacao(" + c + "," + a + "," + d + ")", 1000);
}
function maxLength(b, a) {
	if (b.value.length >= a) {
		b.value = b.value.substring(0, a - 1)
	}
};
