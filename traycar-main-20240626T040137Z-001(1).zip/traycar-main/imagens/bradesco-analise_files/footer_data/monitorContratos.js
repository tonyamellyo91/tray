var monitorInterval = null;
jQuery(document).ready(function() {
	disableTabFirst();
	monitorInterval = setInterval("timedRefresh()", 300000);
});

function timedRefresh() {
	var CTRL = jQuery("#CTRL").val();
	if (CTRL != null && CTRL != 'null' && CTRL != '') {
		clearInterval(monitorInterval);
		window.top.frames.footer.location = "footer.jsf?CTRL=" + CTRL;
	}
}
jQuery(document).ready(function() {
	if (jQuery("#atualizaMenuConsulta").val() == "S") {
		if (window.top.frames.paginaCentral.jQuery(".btnBuscarMenuConsulta").html() != null && window.top.frames.paginaCentral.jQuery(".tabelaMenuConsulta").html() != null) {
			window.top.frames.paginaCentral.jQuery(".btnBuscarMenuConsulta").click();
		}
	}
});