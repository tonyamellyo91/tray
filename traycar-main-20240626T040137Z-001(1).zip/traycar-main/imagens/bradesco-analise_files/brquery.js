function BRQuery (query)
{
	this.query = query;
	

	this.ready = function (func)
	{	
		var oldonload = window.onload;
		if (typeof window.onload != 'function'){
			window.onload = func;
		} else {
			window.onload = function(){
			oldonload();
			func();
			}
		}

	}

}

function BRQueryOperator (query)
{
	return new BRQuery (query);
}

var $jBR = BRQueryOperator;

if (document) {
  if (!document.nodeType) document.nodeType = 9;
  if (!document.nodeName) document.nodeName = '#document';
}
