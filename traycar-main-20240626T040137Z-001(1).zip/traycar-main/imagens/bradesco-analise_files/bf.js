var msgRequired = new Array();
msgRequired["frm:txtCPF1"] = "Informe um CPF v\u00e1lido.";
msgRequired["frm:txtCNPJ1"] = "Informe um CNPJ v\u00e1lido.";
msgRequired["frm:txtCNPJPgto1"] = "Informe um CNPJ v\u00e1lido.";
msgRequired["frm:txtCEP1"] = "Informe o CEP.";
msgRequired["frm:txtEndereco"] = "Informe o endere\u00e7o.";
msgRequired["frm:listaEstado"] = "Informe o estado.";
msgRequired["frm:txtCidade"] = "Informe a cidade.";
msgRequired["frm:txtNumero"] = " Informe o n\u00e7mero.";
msgRequired["frm:txtBairro"] = " Informe o bairro.";
msgRequired["frm:txtRazaoSocial"] = " Informe a raz\u00e3o social.";
msgRequired["frm:txtNmResponsavel"] = "Informe o nome do respons\u00e1vel.";
msgRequired["frm:listaEstadoCid"] = "Informe o estado.";
msgRequired["frm:txtCidadeCid"] = "Informe a cidade.";
msgRequired["frm:cmbPlano"] = "Informe os campos abaixo.";
msgRequired["frm:valorEntrada"] = "Informe os campos abaixo.";
msgRequired["frm:cmbTabelaFaixaProdutoCdc"] = "Selecione a Tabela do produto.";
msgRequired["frm:cmbTabelaFaixaProdutoLeasing"] = "Selecione a Tabela do produto.";
msgRequired["frm:cmbTabelaFaixaProdutoCdcLeas"] = "Selecione a Tabela do produto CDC.";
msgRequired["frm:cmbTabelaFaixaProdutoLeasingCdc"] = "Selecione a Tabela do produto Leasing.";
msgRequired["frm:cmbProdutoSemTabela"] = "N\u00e3o existe Tabela-Faixa-Produto para esse tipo de condi\u00e7\u00e3o de neg\u00f3cio.";
msgRequired["frm:banco"] = "Informe o banco.";
msgRequired["frm:agencia"] = "Informe a ag\u00eancia.";
msgRequired["frm:conta"] = "Informe uma conta v\u00e1lida.";
msgRequired["frm:digito"] = "Informe uma conta v\u00e1lida.";
msgRequired["frm:valorErro"] = "Informe o valor {0} em reais, incluindo os centavos.";
msgRequired["frm:txtParecer"] = "Informe o parecer.";
msgRequired["frm:telefoneErro"] = "Informe um telefone v\u00e1lido.";
msgRequired["frm:dddErro"] = "Informe um ddd v\u00e1lido.";
msgRequired["frm:rgErro"] = "Informe um RG/RNE v\u00e1lido.";
msgRequired["frm:dataErro"] = "Informe uma data v\u00e1lida.";
msgRequired["frm:diaErro"] = "Informe um dia v\u00e1lido.";
msgRequired["frm:mesErro"] = "Informe um m\u00eas v\u00e1lido.";
msgRequired["frm:anoErro"] = "Informe um ano v\u00e1lido.";
msgRequired["frm:dataNascimento"] = "Informe uma idade superior a 18 anos.";
msgRequired["frm:dataSocio"] = "Data inferior ao início da Empresa.";
msgRequired["frm:txtNomeProponente"] = "Informe o nome do proponente.";
msgRequired["frm:txtNomeCombo"] = "Informe o nome do combo.";
msgRequired.tipoPessoaRepresentante = "Informe o tipo de pessoa do representante/s\u00f3cio.";
msgRequired.nomeRepresentante = "Informe o nome do representante/s\u00f3cio.";
msgRequired.percPartRepresentante = "Informe a participa\u00e7\u00e3o.";
msgRequired.cpfIgualRepresentante = "Informe um CPF diferente dos representantes inseridos.";
msgRequired.cnpjIgualRepresentante = "Informe um CNPJ diferente dos representantes inseridos.";
msgRequired.cnpjIgualProponenteRepr = "Informe um CNPJ diferente do proponente.";
msgRequired.porcentagemRepresentante = "Percentual de participa\u00e7\u00e3o superior a 100%.";
msgRequired.dataAtividadeRepresentante = "Informe a data de início de atividade.";
msgRequired.dataAtualRepresentante = "Data de entrada n\u00e3o deve ser maior que a data atual.";
msgRequired["frm:txtEmpresa"] = " Informe a empresa.";
msgRequired["frm:txtAdmissao"] = " Informe a data de admiss\u00e3o";
msgRequired["frm:txtCEPComercialPF1"] = " Informe um CEP e clique em Pesquisar CEP";
msgRequired["frm:txtEnderecoComercial"] = " Informe o endere\u00e7o.";
msgRequired["frm:txtNumeroComercial"] = " Informe o n\u00e7mero.";
msgRequired["frm:txtComplementoComercial"] = " Selecione o estado.";
msgRequired["frm:listaEstadoComercial"] = " Selecione o estado.";
msgRequired["frm:txtCidadeComercial"] = " Informe a cidade.";
msgRequired["frm:txtBairroComercial"] = " Informe o bairro.";
msgRequired["frm:txtTelefoneComercial1"] = " Informe o DDD";
msgRequired["frm:txtTelefoneComercial2"] = " Informe o n\u00e7mero do telefone.";
msgRequired["frm:txtCNPJPF"] = " Informe o CNPJ.";
msgRequired["frm:txtEstado"] = " UF deve ser igual a UF de licenciamento.";
msgRequired["frm:txtCEPPF1Corresp"] = " Informe um CEP e clique em Pesquisar CEP.";
msgRequired["frm:txtEnderecoCorresp"] = " Informe o endere\u00e7o.";
msgRequired["frm:txtNumeroCorresp"] = " Informe o n\u00e7mero.";
msgRequired["frm:txtEstadoCorresp"] = " Selecione o estado.";
msgRequired["frm:txtCidadeCorresp"] = " Informe a cidade.";
msgRequired["frm:txtBairroCorresp"] = " Informe o bairro.";
msgRequired["frm:listaNumeroBanco"] = " Informe o banco.";
msgRequired["frm:txtAgencia"] = " Informe a ag\u00eancia.";
msgRequired["frm:txtConta1"] = " Informe a conta.";
msgRequired["frm:txtAgenciaComZero"] = " Dados da refer\u00eancia banc\u00e1ria inv\u00e1lidos.";
msgRequired["frm:nomeConjuge"] = " Informe o nome do cônjuge.";
msgRequired["frm:txtNomeContador"] = " Informe o nome do contador.";
msgRequired["frm:txtTelefoneContador1"] = " Informe o telefone do contador.";
msgRequired["frm:txtCPFIgual"] = " Informe um CPF diferente do proponente.";
msgRequired["frm:txtCPFIgualPJ"] = " Informe um CPF diferente do primeiro avalista.";
msgRequired["frm:txtCPFIgualPJ2"] = " Informe um CPF diferente do segundo avalista.";
msgRequired["frm:txtNmUsuario"] = " Informe o nome.";
msgRequired["frm:txtLogin"] = " Informe o login.";
msgRequired["frm:txtSenha"] = " Informe a senha.";
msgRequired["frm:txtDias"] = " Informe a quantidade de dias.";
msgRequired["frm:txtEmail"] = " Email Inv\u00e1lido.";
msgRequired["frm:txtConfSenha"] = "Senha n\u00e3o confere.";
msgRequired["frm:txtEmailAlterar"] = " Email Inv\u00e1lido.";
msgRequired["frm:txtConfSenhaModal"] = " Senha n\u00e3o confere.";
msgRequired["frm:txtSenhaModal"] = " Informe a senha.";
msgRequired["frm:txtDias"] = " Informe a quantidade de dias.";
msgRequired["frm:listaEnviarEndereco"] = " Endere\u00e7o de correspond\u00eancia n\u00e3o permitido para a ocupa\u00e7\u00e3o informada.";
msgRequired["frm:txtNomeVendedor"] = " Informe o nome do vendedor.";
msgRequired["frm:txtCPFVendedor1"] = " Informe um CPF v\u00e1lido.";
msgRequired["frm:listaCarteiras"] = " Informe uma carteira v\u00e1lida.";
var msgValidate = new Array();
msgValidate["frm:txtCPF1"] = " Informe o cpf com 11 n\u00e7meros.";
msgValidate["frm:txtCNPJ1"] = " Informe o cnpj com 14 n\u00e7meros.";
msgValidate["frm:txtSalarioRenda"] = " O valor informado \u00e9 inv\u00e1lido.";
msgValidate["frm:txtSenha"] = " Informe uma senha de 8 a 10 caracteres.";
msgValidate["frm:txtSenhaModal"] = " Informe uma senha de 8 a 10 caracteres.";

var id_frm = "frm";
var id_completo = id_frm + "\\:";

function validarValorMoneatario(a) {
	var c = /^\d{1,3}(\.\d{3})*\,\d{2}$/;
	var b = true;
	var d = a.match(c);
	if (d == null) {
		b = false;
	}
	return b;
}
function validarValor() {
	var b = true;
	var a = "frm:valorErro";
	jQuery(".valor").each(function() {
		if (jQuery(this).hasClass("requerido") && jQuery(this).val() == "0,00") {
			exibirErro(jQuery(this).attr("id"), msgRequired[a].replace("{0}", jQuery(this).parent().parent().find(".label").html().replace(":", "")));
			b = false;
		}
	});
	return b;
}
function onKeyPressInputMoney3(a, b) {
	return onlyNumbers3(a, b);
}
function onlyNumbers3(b, d) {
	var c;
	var a;
	if (window.event) {
		c = window.event.keyCode;
	} else {
		if (b) {
			c = b.which;
		} else {
			return true;
		}
	}
	a = String.fromCharCode(c);
	if ((c == null) || (c == 0) || (c == 8) || (c == 9) || (c == 13) || (c == 27)) {
		return true;
	} else {
		if ((("0123456789").indexOf(a) > -1)) {
			return true;
		} else {
			return false;
		}
	}
}
function onKeyUpInputMoney3(b, d) {
	var c;
	var a;
	if (window.event) {
		c = window.event.keyCode;
	} else {
		if (b) {
			c = b.which;
		} else {
			return;
		}
	}
	a = String.fromCharCode(c);
	if ((c == 8) || (c == 46) || (c >= 96 && c <= 105) || (("0123456789").indexOf(a) > -1)) {
		d.value = currencyFormatted3(d.value);
	}
}
function currencyFormatted3(f) {
	var g = f;
	var h = "";
	var a = "";
	var c = [];
	var e = 0;
	var d = 0;
	var b = 0;
	g = clearString3(g.toString(), "0123456789");
	if (g.length > 3) {
		h = g.substr(0, g.length - 3);
		a = g.substr(g.length - 3, 3);
		if (h.length > 4) {
			c = [];
			for (e = h.length - 1, d = 1, b = 0; e > 0; e--, d++) {
				if ((d % 3) == 0) {
					c.push(h.substr(e, 3));
					b++;
				}
			}
			c.reverse();
			h = h.substr(0, h.length - (3 * b)) + "." + c.join(".");
		}
		g = h + "," + a;
	}
	return g;
}
function clearString3(e, d) {
	var a = "";
	var b = -1;
	var c = 0;
	for (c = 0; c < e.length; c++) {
		b = d.indexOf(e.charAt(c));
		if (b > -1) {
			a += d.charAt(b);
		}
	}
	return a;
}
function onBlurInputMoney3(a, b) {
	b.value = currencyFormatted3(b.value);
	if (b.value.length == 0) {
		b.value = "";
	} else {
		if (b.value.length <= 3) {
			b.value = b.value + ",000";
		}
	}
}
function onKeyUpInputMoneySemDecimal(e, g) {
	var b = g.value.length;
	if (b >= g.maxLength && b > 3 && g.value.indexOf(".") == -1) {
		var d = Math.floor(b / 3);
		var a = b % 3;
		d -= a >= 0 && d > 1 ? 1 : 0;
		g.value = g.value.substring(0, b - d);
	}
	var f;
	var c;
	if (window.event) {
		f = window.event.keyCode;
	} else {
		if (e) {
			f = e.which;
		} else {
			return
		}
	}
	c = String.fromCharCode(f);
	if ((f == 8) || (f == 46) || (f >= 96 && f <= 105) || (("0123456789").indexOf(c) > -1)) {
		g.value = currencyFormattedSemDecimal(g.value);
	}
}
function clearLeftZerosSemDecimal(b) {
	var a = "0";
	if (b != "") {
		a = parseInt(b, 10);
	}
	return a + "";
}
function currencyFormattedSemDecimal(e) {
	var f = e;
	var g = "";
	var b = [];
	var d, c, a = 0;
	f = clearString(f.toString(), "0123456789");
	f = clearLeftZerosSemDecimal(f);
	if (f.length > 3) {
		g = f;
		if (g.length > 3) {
			b = [];
			for (d = g.length - 1, c = 1, a = 0; d > 0; d--, c++) {
				if ((c % 3) == 0) {
					b.push(g.substr(d, 3));
					a++;
				}
			}
			b.reverse();
			g = g.substr(0, g.length - (3 * a)) + "." + b.join(".");
		}
		f = g;
	}
	return f;
}
function onBlurInputMoneySemDecimal(c, e) {
	var a = e.value.length;
	if (a >= e.maxLength && a > 3) {
		var f = e.maxLength;
		var d = f % 3;
		var b = Math.floor(f / 3);
		b -= d >= 0 && b > 1 ? 1 : 0;
		f = e.maxLength - b;
		if (e.value.length > f) {
			e.value = e.value.replace(/\.|\,/g, "").substring(0, f);
		}
	}
	e.value = currencyFormattedSemDecimal(e.value);
	if (e.value.length == 0) {
		e.value = "";
	}
}
jQuery(function() {
	jQuery("a").click(function() {
		if (jQuery(this).attr("target") == "modal_infra_estrutura") {
			parent.focusStack.push(top.currentFocus);
		}
	});
	jQuery(".btnSalvarFoco").click(function() {
		parent.focusStack.push(top.currentFocus);
	});
	jQuery(".valor3decimais").each(function() {
		if (jQuery(this).val() == "") {
			jQuery(this).val("0,000");
		}
	});
	jQuery(".valor3decimais").blur(function(a) {
		onBlurInputMoney3(a, this);
		if (jQuery(this).val() == "") {
			jQuery(this).val("0,000");
		}
	});
	jQuery(".valor3decimais").keyup(function(a) {
		onKeyUpInputMoney3(a, this);
	});
	jQuery(".valor3decimais").keypress(function(a) {
		return onKeyPressInputMoney3(a, this);
	});
	jQuery(".valor3decimais").focus(function() {
		if (jQuery(this).val() == "0,000") {
			jQuery(this).val("");
		}
	});
	jQuery(".valorSemDecimal").each(function() {
		if (jQuery(this).val() == "") {
			jQuery(this).val("0");
		}
	});
	jQuery(".valorSemDecimal").blur(function(a) {
		onBlurInputMoneySemDecimal(a, this);
		if (jQuery(this).val() == "") {
			jQuery(this).val("0");
		}
	});
	jQuery(".valorSemDecimal").keyup(function(a) {
		onKeyUpInputMoneySemDecimal(a, this);
	});
	jQuery(".valorSemDecimal").keypress(function(a) {
		return onKeyPressInputMoney(a, this);
	});
	jQuery(".valorSemDecimal").focus(function() {
		if (jQuery(this).val() == "0") {
			jQuery(this).val("");
		}
	});
	jQuery(".carregarResumo").focusout(function() {
		if (jQuery(".carregarTitleResumo").html() != null) {
			attTitle();
		}
	});
	jQuery(".clickLink").click(function() {
		jQuery(this).parent().find("a:first").click();
	});
});