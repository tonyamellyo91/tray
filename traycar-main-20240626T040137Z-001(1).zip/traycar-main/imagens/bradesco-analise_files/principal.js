var browserName;
var browserVersion;
var alturaAtualFrame = 0;
var alturaAtualModal = 0;
var numeroDeVezesAutoIframeExecutadoSemAlteracaoAltura = 0;
var numeroDeVezesAutoModalExecutadoSemAlteracaoAltura = 0;
var modalInicializado = false;
var modalSemMargemInicializado = false;
var modalSemMargemJaAbertoParaCliente = false;
function log(a) {
}
function getVersaoInternetExplorer() {
	var c = -1;
	if (navigator.appName == "Microsoft Internet Explorer") {
		var a = navigator.userAgent;
		var b = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");
		if (b.exec(a) != null) {
			c = parseFloat(RegExp.$1)
		}
	}
	return c
}
function identificarBrowser() {
	var a = navigator.userAgent.toLowerCase();
	if (a.indexOf("opera") != -1) {
		browserName = "opera"
	} else {
		if (a.indexOf("msie") != -1) {
			browserName = "msie";
			browserVersion = getVersaoInternetExplorer()
		} else {
			if (a.indexOf("safari") != -1) {
				browserName = "safari"
			} else {
				if (a.indexOf("mozilla") != -1) {
					if (a.indexOf("firefox") != -1) {
						browserName = "firefox"
					} else {
						browserName = "mozilla"
					}
				}
			}
		}
	}
}
identificarBrowser();
function f_clientWidth() {
	return f_filterResults(window.innerWidth ? window.innerWidth : 0, document.documentElement ? document.documentElement.clientWidth : 0, document.body ? document.body.clientWidth : 0)
}
function f_clientHeight() {
	return f_filterResults(window.innerHeight ? window.innerHeight : 0, document.documentElement ? document.documentElement.clientHeight : 0, document.body ? document.body.clientHeight : 0)
}
function f_scrollLeft() {
	return f_filterResults(window.pageXOffset ? window.pageXOffset : 0, document.documentElement ? document.documentElement.scrollLeft : 0, document.body ? document.body.scrollLeft : 0)
}
function f_scrollTop() {
	return f_filterResults(window.pageYOffset ? window.pageYOffset : 0, document.documentElement ? document.documentElement.scrollTop : 0, document.body ? document.body.scrollTop : 0)
}
function obtemLarguraIframe(b) {
	var h = document.getElementById(b);
	var f = (h.contentDocument) ? h.contentDocument : h.contentWindow.document;
	var a = (h.style) ? h.style : h;
	var e = 0;
	var d = 0;
	var c;
	if (browserName == "msie") {
		e = f.body.scrollWidth
	} else {
		c = f.getElementsByTagName("div");
		for (var g = 0; g < c.length; g++) {
			tag = c[g];
			if (e < (tag.offsetLeft + tag.scrollWidth)) {
				e = tag.offsetLeft + tag.scrollWidth
			}
		}
	}
	if (d > e) {
		e = d
	}
	return e
}
function obtemAlturaIframe2(c) {
	var h = document.getElementById(c);
	var f = (h.contentDocument) ? h.contentDocument : h.contentWindow.document;
	var b = (h.style) ? h.style : h;
	var a = 0;
	var e = 0;
	var d;
	if (browserName == "msie") {
		a = f.body.scrollHeight
	} else {
		d = f.getElementsByTagName("div");
		for (var g = 0; g < d.length; g++) {
			tag = d[g];
			if (a < (tag.offsetTop + tag.scrollHeight)) {
				a = tag.offsetTop + tag.scrollHeight
			}
		}
	}
	if (e > a) {
		a = e
	}
	return a
}
function obtemAlturaIframe(c) {
	var h = document.getElementById(c);
	var f = (h.contentDocument) ? h.contentDocument : h.contentWindow.document;
	var b = (h.style) ? h.style : h;
	var a = 0;
	var e = 0;
	var d;
	if (browserName == "msie") {
		d = jQuery(f).find("body > *");
		for (var g = 0; g < d.length; g++) {
			tag = d[g];
			if (tag.scrollHeight > a) {
				a = tag.scrollHeight
			}
			if (tag.className == "dp-popup") {
				if (e < tag.offsetTop + tag.scrollHeight + 25) {
					e = tag.offsetTop + tag.scrollHeight + 25
				}
			}
		}
	} else {
		d = f.getElementsByTagName("html");
		for (var g = 0; g < d.length; g++) {
			tag = d[g];
			if (browserName == "safari" || browserName == "opera") {
				a = tag.offsetTop + tag.scrollHeight
			} else {
				a = tag.offsetTop + tag.offsetHeight
			}
		}
		d = f.getElementsByClassName("dp-popup");
		for (var g = 0; g < d.length; g++) {
			tag = d[g];
			if (e < tag.offsetTop + tag.scrollHeight + 25) {
				e = tag.offsetTop + tag.scrollHeight + 25
			}
		}
	}
	if (e > a) {
		a = e
	}
	if (a == 0) {
		a = obtemAlturaIframe2(c)
	}
	return a
}
var filaAnimacaoPaginaCentral = new Array();
var isAnimacaoPaginaCentral = false;
var lastAnimaPaginaCentralHeight = 0;
function _obterPaginaCentralAlturaReal() {
	var d = 0;
	try {
		var e = document.getElementById("paginaCentral");
		var b = (e.contentDocument) ? e.contentDocument : e.contentWindow.document;
		var a = (e.style) ? e.style : e;
		var f = a.height;
		f.replace("px", "");
		d = parseInt(f, 10);
		if (isNaN(d)) {
			d = 0
		}
	} catch (c) {
		log("obterPaginaCentralAlturaReal: " + c.message)
	}
	return d
}
function _forcarPaginaCentralAltura(e) {
	try {
		var d = document.getElementById("paginaCentral");
		var b = (d.contentDocument) ? d.contentDocument : d.contentWindow.document;
		var a = (d.style) ? d.style : d;
		a.height = e + "px"
	} catch (c) {
		log("forcarPaginaCentralAltura: " + c.message)
	}
}
function _animaPaginaCentral() {
	$ = jQuery;
	if (lastAnimaPaginaCentralHeight != 0) {
		var a = _obterPaginaCentralAlturaReal();
		if (a != lastAnimaPaginaCentralHeight) {
			_forcarPaginaCentralAltura(lastAnimaPaginaCentralHeight);
			filaAnimacaoPaginaCentral.push([ lastAnimaPaginaCentralHeight, true ]);
			log("_animaPaginaCentral: falha:" + lastAnimaPaginaCentralHeight)
		}
	}
	var b = filaAnimacaoPaginaCentral.pop();
	if (typeof (b) != "undefined") {
		if (b[1]) {
			$("#paginaCentral").animate({
				height : b[0] + "px"
			}, 500, "linear", _animaPaginaCentral)
		} else {
			$("#paginaCentral").animate({
				height : b[0] + "px"
			}, 1, "linear", _animaPaginaCentral)
		}
		lastAnimaPaginaCentralHeight = b[0];
		log("_animaPaginaCentral: " + b[0])
	} else {
		log("_animaPaginaCentral: fim");
		isAnimacaoPaginaCentral = false;
		lastAnimaPaginaCentralHeight = 0
	}
}
function animaPaginaCentral(d, a) {
	var c = true;
	var b = alturaAtualFrame;
	if (!isAnimacaoPaginaCentral) {
		b = _obterPaginaCentralAlturaReal();
		if (alturaAtualFrame != b) {
			log("animaPaginaCentral: var(" + alturaAtualFrame + "), real(" + b + ")")
		}
	}
	if (d != b) {
		filaAnimacaoPaginaCentral.unshift([ d, a ]);
		alturaAtualFrame = d;
		if (!isAnimacaoPaginaCentral) {
			isAnimacaoPaginaCentral = true;
			_animaPaginaCentral()
		}
	} else {
		c = false
	}
	return c
}
function autoIframe() {
	try {
		var altura = null;
		var conteudo = window.frames['paginaCentral'].document.getElementById('conteudo');
		altura = conteudo.offsetHeight;
		var central = document.getElementById("paginaCentral");
		if (null == central) {
			central = parent.document.getElementById("paginaCentral");
		}
		central.style.height = altura + 'px';

	} catch (d) {
		log("autoIframe: " + d.message);

	}
}
/*
 * function autoIframe() { try { var e =
 * document.getElementById("paginaCentral"); var c = (e.contentDocument) ?
 * e.contentDocument : e.contentWindow.document; var b = (e.style) ? e.style :
 * e; var a; a = obtemAlturaIframe("paginaCentral"); if (animaPaginaCentral(a,
 * true)) { numeroDeVezesAutoIframeExecutadoSemAlteracaoAltura = 0 } else {
 * numeroDeVezesAutoIframeExecutadoSemAlteracaoAltura++ } if
 * (numeroDeVezesAutoIframeExecutadoSemAlteracaoAltura < 4) { return 1 } return
 * 0 } catch (d) { log("autoIframe: " + d.message); return 0 } }
 */
function ajustaAlturaMiolo() {
	try {
		var g = document.getElementById("paginaCentral");
		var e = (g.contentDocument) ? g.contentDocument : g.contentWindow.document;
		var b = (g.style) ? g.style : g;
		var a;
		a = jQuery("#lateral").outerHeight();
		var h = jQuery("#paginaCentral").contents().find("#conteudo").outerHeight();
		var d = jQuery("#paginaCentral").contents().find("#conteudo .topo").height() + jQuery("#paginaCentral").contents().find("#conteudo .base").height();
		a = a - (d + 14);
		if (typeof b.maxHeight === "undefined") {
			if (h < a) {
				jQuery("#paginaCentral").contents().find("#conteudo .miolo:first").css("height", (a) + "px")
			}
		} else {
			jQuery("#paginaCentral").contents().find("#conteudo .miolo:first").css("min-height", (a) + "px")
		}
		autoIframe();
		if (browserName == "msie" && browserVersion == 7) {
			jQuery("#miolo").addClass("margemIE7")
		}
	} catch (f) {
	}
}
function iframeInlineInic() {
	var e = document.getElementById("paginaCentral");
	var c = (e.contentDocument) ? e.contentDocument : e.contentWindow.document;
	var b = (e.style) ? e.style : e;
	var d = obtemAlturaIframe("paginaCentral");
	var a = d;
	animaPaginaCentral(a, false)
}
function autoIframeInicializacao() {
	try {
		var b = document.getElementById("paginaCentral");
		var f = (b.contentDocument) ? b.contentDocument : b.contentWindow.document;
		var h = (b.style) ? b.style : b;
		var j = obtemAlturaIframe("paginaCentral");
		var k = j;
		animaPaginaCentral(k, false);
		var g = f.body.getElementsByTagName("*");
		var i = 0;
		for (var c = 0; c < g.length; c++) {
			var l = g[c];
			i = l.offsetTop + l.scrollHeight;
			if (i > j) {
				j = i
			}
			var d = "var funcaoRedimensionamento = function() { continuaResize=window.parent.autoIframe(); if(continuaResize==1) { setTimeout(funcaoRedimensionamento, 750); } };if (window.parent && window.parent.autoIframe) {    window.parent.numeroDeVezesAutoIframeExecutadoSemAlteracaoAltura=0;    var continuaResize=window.parent.autoIframe();    setTimeout(funcaoRedimensionamento, 750);}";
			if (l.className.indexOf("btnAvancar") >= 0 || l.className.indexOf("bt_avancar") >= 0 || l.className.indexOf("listaAbreFecha") >= 0 || l.className.indexOf("accessTools") >= 0 || l.className.indexOf("zoomOutFont") >= 0 || l.className.indexOf("zoomInFont") >= 0 || l.className.indexOf("btn-fechar") >= 0 || l.className.indexOf("tp2") >= 0 || l.className.indexOf("tp3") >= 0 || l.className.indexOf("tp4") >= 0 || l.className.indexOf("btn_horarios_limites") >= 0 || l.id.indexOf("btn_ajuda") >= 0 || l.className.indexOf("btn_collapse") >= 0) {
				if (l.addEventListener) {
					l.addEventListener("click", function a(m) {
						setTimeout(d, 750)
					}, false)
				} else {
					if (f.body.attachEvent) {
						l.attachEvent("onclick", function a(m) {
							setTimeout(d, 750)
						})
					} else {
					}
				}
			}
			if (l.className.indexOf("dia") >= 0 || l.className.indexOf("mes") >= 0 || l.className.indexOf("ano") >= 0 || l.className.indexOf("ico_calendario") >= 0) {
				if (l.addEventListener) {
					l.addEventListener("click", function a(m) {
						setTimeout(d, 750)
					}, false);
					l.addEventListener("blur", function a(m) {
						setTimeout(d, 750)
					}, true);
					l.addEventListener("keyup", function a(m) {
						setTimeout(d, 750)
					}, true)
				} else {
					if (f.body.attachEvent) {
						l.attachEvent("onclick", function a(m) {
							setTimeout(d, 750)
						});
						l.attachEvent("onblur", function a(m) {
							setTimeout(d, 750)
						});
						l.attachEvent("onkeyup", function a(m) {
							setTimeout(d, 750)
						})
					} else {
					}
				}
			}
		}
	} catch (e) {
	}
}
function getParametroUrlGet(c) {
	var b = "";
	c = c.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	if (c.toLowerCase() == "ctl" && document.getElementById("ctl") != null && typeof (document.getElementById("ctl")) != "undefined") {
		b = document.getElementById("ctl").value
	} else {
		var a = "[\\?&]" + c + "=([^&#]*)";
		var e = new RegExp(a);
		var d = e.exec(window.location.href);
		if (d != null) {
			b = d[1]
		}
	}
	return b
}
function iframeApresentarNovaPagina(a) {
	document.getElementById("paginaCentral").src = a
}
var heightIframeModal;
var widthIframeModal;
var loopRedimensionamentoModalEmOperacao = false;
function exibirModalSemMargemInfraEstrutura(h) {
	$ = jQuery;
	var d = document.getElementById("modal_infra_estrutura");
	var i = (d.contentDocument) ? d.contentDocument : d.contentWindow.document;
	var l = (d.style) ? d.style : d;
	if (modalSemMargemInicializado) {
		var k = false;
		if (modal_infra_estrutura.isBloquearAberturaModal) {
			var e = modal_infra_estrutura.isBloquearAberturaModal();
			if (e == true || e == "true") {
				k = true
			}
		}
		if (!k) {
			d.width = "1";
			d.heigth = "1";
			$("#div_modal_infra_estrutura_sem_margem").jqm();
			$("#div_modal_infra_estrutura_sem_margem").jqmShow();
			var j = (h.contentDocument) ? h.contentDocument : h.contentWindow.document;
			var n = obtemAlturaIframe("modal_infra_estrutura");
			var b = obtemLarguraIframe("modal_infra_estrutura");
			var c = 0;
			var a = 0;
			if (typeof (window.innerWidth) == "number") {
				c = window.innerWidth;
				a = window.innerHeight
			} else {
				if (document.documentElement && document.documentElement.clientWidth) {
					c = document.documentElement.clientWidth;
					a = document.documentElement.clientHeight
				} else {
					if (document.body && document.body.clientWidth) {
						c = document.body.clientWidth;
						a = document.body.clientHeight
					}
				}
			}
			var m = $(document).scrollTop();
			var g = 0;
			widthIframeModal = b;
			if (a - n > 50) {
				g = m + (a - n) / 2;
				heightIframeModal = n + ((a - n) / 2) + 150
			} else {
				g = m + 50;
				heightIframeModal = n + 150
			}
			$(d).attr("height", "" + heightIframeModal + "px");
			$(d).attr("style", "height:" + heightIframeModal + "px;");
			d.width = widthIframeModal;
			d.height = heightIframeModal;
			$(".jqmWindow").css("top", g + "px");
			$(".jqmWindow").css("left", ((c - b) / 2) + "px")
		}
		try {
		} catch (f) {
			alert(f.message)
		}
	}
}
function autoIframeModal() {
	$ = jQuery;
	try {
		var e = document.getElementById("modal_infra_estrutura");
		var c = (e.contentDocument) ? e.contentDocument : e.contentWindow.document;
		var b = (e.style) ? e.style : e;
		var a;
		a = obtemAlturaIframe("modal_infra_estrutura");
		if (alturaAtualModal != a) {
			alturaAtualModal = a;
			numeroDeVezesAutoModalExecutadoSemAlteracaoAltura = 0;
			$(e).attr("height", "" + alturaAtualModal + "px");
			$(e).attr("style", "height:" + alturaAtualModal + "px;");
			e.height = alturaAtualModal
		} else {
			numeroDeVezesAutoModalExecutadoSemAlteracaoAltura++
		}
		if (numeroDeVezesAutoModalExecutadoSemAlteracaoAltura < 11) {
			return 1
		}
		loopRedimensionamentoModalEmOperacao = false;
		return 0
	} catch (d) {
		return 0
	}
}
function fecharModalInfraEstrutura() {
	$ = jQuery;
	$("#div_modal_infra_estrutura").jqmHide();
	$("#div_modal_infra_estrutura_sem_margem").jqmHide();
	if (modal_infra_estrutura.modalFechado) {
		modal_infra_estrutura.modalFechado()
	}
}
var auxModalFrameStyle;
var auxModalHeight;
var retrySetModalIFrameHeight = 0;
function setModalIframeHeight() {
	var a = auxModalFrameStyle.height;
	if (retrySetModalIFrameHeight < 20 && a != "" && a != alturaAtualModal + "px") {
		retrySetModalIFrameHeight++;
		setTimeout("setIframeHeight()", 50)
	} else {
		retrySetModalIFrameHeight = 0;
		auxModalFrameStyle.height = auxModalHeight + "px";
		alturaAtualModal = auxModalHeight
	}
}
var retryModalIFrameHeight = 0;
function inicializarIFrameModalInfraEstrutura(a) {
	retryModalIFrameHeight = 0;
	if (modalSemMargemInicializado) {
		if (retryModalIFrameHeight < 4) {
			setTimeout(function() {
				retryModalIFrameHeight++;
				exibirModalSemMargemInfraEstrutura(a)
			}, 500)
		}
	}
	modalSemMargemInicializado = true
};