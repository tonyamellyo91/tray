/**
 * Prop�sito: Scripts js do componente UISessionTimeout
 * 
 * Descri��o: Arquivo que define o comportamento do componente
 */
var $jB = jQuery.noConflict();
function UISessionTimeout(expireTime, leftTime, refreshRate, baseClazz,
		normalClass, criticalClass, criticalTimeout, sobra) {

	this.expireTime = expireTime;
	this.leftTime = leftTime;
	this.refreshRate = refreshRate;
	this.baseClazz = baseClazz;
	this.sobra = sobra;
	this.normalClass = normalClass;
	this.criticalClass = criticalClass;
	this.criticalTimeout = criticalTimeout;

	/* Construtor do componente */
	this.init = function() {

		var refreshFnc = "new UISessionTimeout ().refresh (" + this.expireTime
				+ "," + this.leftTime + "," + this.refreshRate + ",'"
				+ this.baseClazz + "',";
		refreshFnc += "'" + this.criticalClass + "' ,  '"
				+ this.criticalTimeout + "' , '" + this.normalClass + "')";

		if (sobra != 0) {
			window.setTimeout(refreshFnc, sobra * 1000);

		} else {
			window.setTimeout(refreshFnc, refreshRate * 60 * 1000);
		}

	};

	this.refresh = function(expireTime, leftTime, refreshRate, baseClazz,
			normalClass, criticalClass, criticalTimeout) {
		leftTime = leftTime - refreshRate;

		if (leftTime < 0)
			leftTime = 0;

		var rate = leftTime / expireTime;
		var clazz = "";
		if (rate >= 0 && rate < 0.25)
			clazz = "tR7_8";
		if (rate >= 0.25 && rate < 0.50)
			clazz = "tR5_8";
		if (rate >= 0.50 && rate < 0.75)
			clazz = "tR3_8";
		if (rate >= 0.75)
			clazz = "tR1_8";
		if (rate == 0)
			clazz = "tR0_8"

		var leftTimeLabel = "";
		leftTimeLabel = String(leftTime);
		if (leftTimeLabel.length == 1)
			leftTimeLabel = '0' + leftTimeLabel;
		leftTimeLabel += "min";

		// var pClazz = '.'+baseClazz+'-p';
		var pClazz = 'span.' + baseClazz + '-p';
		var clockClazz = baseClazz + clazz;

		if (criticalTimeout != null) {
			if (leftTime <= criticalTimeout) {
				if (criticalClass != null)
					clockClazz += " " + criticalClass;
			} else {
				if (normalClass != null)
					clockClazz += " " + normalClass;
			}
		}

		$jB(pClazz).removeClass(baseClazz + 'tR7_8');
		$jB(pClazz).removeClass(baseClazz + 'tR5_8');
		$jB(pClazz).removeClass(baseClazz + 'tR3_8');
		$jB(pClazz).removeClass(baseClazz + 'tR1_8');

		$jB(pClazz).addClass(clockClazz);
		$jB(pClazz).text(leftTimeLabel);
		$jB(pClazz).attr("title", leftTimeLabel);

		var refreshFnc = "new UISessionTimeout ().refresh (" + expireTime + ","
				+ leftTime + "," + refreshRate + ",'" + baseClazz + "');";

		window.setTimeout(refreshFnc, refreshRate * 60 * 1000);

	};

};
