#!/bin/bash
clear
echo ""
echo ""
printf "\e[100;330m[\e[10m Desenvolvedor: ]\e[1;40m\e[10m Tony Amellyo, Luziania-GO, Brazil :\e[1;32m Especialista em softwares para seguranca & estrutura para empresas !\e[0m"
sleep 4
echo ""
clear
echo ""
echo ""
echo ""
read -p $'\e[1;40m\e[96m FERRAMENTA DISPONIVEL APENAS PARA TESTES! É EXTREMAMENTE PROIBIDA A ALTERACAO DO CODIGO FONTE, CONCORDA ? \e[1;91m (Y/N) : \e[0m' option
echo ""
echo ""
echo ""

if [[ $option == *'N'* || $option == *'n'* ]]; then
    clear
    exit
fi

php="$(ps -efw | grep php | grep -v grep | awk '{print $2}')"
ngrok="$(ps -efw | grep ngrok | grep -v grep | awk '{print $2}')"
kill -9 $php
kill -9 $ngrok
clear

bash tray-logo.sh
echo -e "$(cat membros.txt)"
echo ""

echo -e $'\e[1;33m[\e[0m\e[1;33m *** \e[0m\e[1;96m]\e[0m\e[1;96m    -----------------      \e[1;33m  [ ]\e[0m'
read -p $'\e[1;91m[\e[0m\e[1;91m *** \e[0m\e[1;96m]\e[0m\e[1;96m    Escolha uma opcao  \e[1;91m  > > > > > \e[0m' option
echo ""
case $option in
    01|1)
        membro="tony"
        ;;
    02|2)
        membro="rayara"
        ;;
    03|3)
        membro="camila"
        ;;
    04|4)
        membro="mirian"
        ;;
    05|5)
        membro="jairo"
        ;;
    06|6)
        membro="ian"
        ;;
    07|7)
        membro="lucas"
        ;;
    08|8)
        membro="silvone"
        ;;
    09|9)
        membro="buguinha"
        ;;
    10)
        membro="petrucio"
        ;;
    11)
        membro="nathan"
        ;;
    12)
        membro="victor"
        ;;
    *)
        echo "Opção inválida."
        exit 1
        ;;
esac

cd membros/
cd $membro/
read -sp $'\e[1;91mDigite a senha: \e[0m' input_password
echo ""
saved_password=$(cat password.txt)

if [ "$input_password" == "$saved_password" ]; then
    echo "Autenticação bem-sucedida"
    sleep 2
    clear
    echo ""
    bash tray-logo.sh
    echo ""
    echo -e $'\e[1;31m[\e[0m\e[1;77m+\e[0m\e[1;31m]\e[0m\e[1;33m >> BEM VINDO ' ${membro^^}'! >> \e[0m'
    echo ""
    # Exibir o menu1.txt
    echo -e "$(cat menu1.txt)"
    echo ""
    echo ""

    # Lógica para tratar a opção selecionada no menu1.txt
    read -p $'\e[1;91mEscolha uma opcao: \e[0m' sub_option
    case $sub_option in
        01|1)
            # Exibir o menu.preanalise.txt
            clear
            bash tray-logo.sh
            echo -e "$(cat menu.preanalise.txt)"
            echo ""
            read -p $'\e[1;91mEscolha uma opção de pré-análise: \e[0m' preanalise_option
            case $preanalise_option in
                01|1)
		    echo -e $'\e[1;33mPré análise padrão selecionada\e[0m'
	            cd preanalises/
	            cd preanalise_padrao/
	            echo -en $'\e[1;96mInsira o cpf: \e[0m'
       		    read cpf
        	    echo "$cpf" > temp_cpf.txt
        	    sleep 1
	            bash automate.sh
        	    sleep 2
    		    python3 automate_bradesco.py
        	    # Pergunta se deseja personalizar o resultado
     		    read -p "Você quer personalizar o resultado? (s/n) " personalizar
 	            if [[ "$personalizar" == "s" || "$personalizar" == "S" ]]; then
       		    # Coloque aqui o script ou os comandos para personalizar o resultado
         		   bash analisepersonalizada.sh
       		    else
          		   echo "Personalização não selecionada. Encerrando."
       		    fi
        	    ;;

                02|2)
                    echo -e $'\e[1;33mPré análise completa selecionada\e[0m'
                    echo -en $'\e[1;96mInsira o cpf: \e[0m'
                    read cpf
                    echo "$cpf" > temp_cpf.txt
                    sleep 1
                    bash automate.sh
                    sleep 2
                    python3 automate_bradesco.py
                    ;;                  
                03|3)
                    echo -e $'\e[1;33mPré análise personalizada selecionada\e[0m'
                    echo -en $'\e[1;96mInsira o cpf: \e[0m'
                    read cpf
                    echo "$cpf" > temp_cpf.txt
                    sleep 1
                    bash automate.sh
                    sleep 2
                    python3 automate_bradesco.py
                    ;;                  
                *)
                    echo -e $'\e[1;33mOpção inválida\e[0m'
                    exit 1
                    ;;
            esac
            ;;
        02|2)
            echo "Opção 2 selecionada: Fichas"
            # Adicione aqui os comandos para a opção "Fichas"
            ;;
        03|3)
            echo "Opção 3 selecionada: Vendas/caixa"
            # Adicione aqui os comandos para a opção "Vendas/caixa"
            ;;
        04|4)
            echo "Opção 4 selecionada: Desempenho"
            # Adicione aqui os comandos para a opção "Desempenho"
            ;;
        *)
            echo "Opção inválida."
            ;;
    esac
else
    echo "Senha incorreta. Acesso negado."
    exit 1
fi
