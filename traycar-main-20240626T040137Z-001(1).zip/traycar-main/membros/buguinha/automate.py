import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Argumentos passados do script bash
cpf_cnpj = sys.argv[1]

# Inicializar o navegador
driver = webdriver.Firefox()
driver.get('https://www.situacao-cadastral.com')

try:
    # Esperar até que o campo de entrada esteja presente
    input_field = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.ID, 'doc'))
    )
    # Inserir o CPF/CNPJ
    input_field.send_keys(cpf_cnpj)
    
    # Encontrar e clicar no botão de consulta
    submit_button = driver.find_element(By.ID, 'consultar')
    submit_button.click()

    # Esperar os resultados serem carregados
    name_element = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, '//span[@class="dados nome"]'))
    )
    status_element = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, '//span[@class="dados situacao"]/span'))
    )

    # Extrair os dados do resultado
    name = name_element.text
    status = status_element.text

    # Escrever os dados em um arquivo de saída
    output_filename = f'{name.replace(" ", "_")}.txt'
    with open(output_filename, 'w') as file:
        file.write(f'{name}\n{status}')

    print(f'Resultado salvo em {output_filename}')

finally:
    # Fechar o navegador
    driver.quit()
