import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def inserir_cpf_digito_a_digito(driver, cpf):
    partes = [cpf[:3], cpf[3:6], cpf[6:9], cpf[9:]]
    ids_campos_cpf = ["frm:txtCPF1", "frm:txtCPF2", "frm:txtCPF3", "frm:txtCPF4"]
    
    for parte, id_campo in zip(partes, ids_campos_cpf):
        campo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, id_campo)))
        campo.click()
        
        for digito in parte:
            campo.send_keys(digito)
            time.sleep(0.2)

        campo.send_keys(Keys.TAB)
        time.sleep(0.2)
    
    # Após inserir todos os dígitos do CPF, pressionar Enter para avançar
    campo.send_keys(Keys.RETURN)

def preencher_dados_veiculo(driver):
    try:
        tipo_bem = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbTiposBem")))
        tipo_bem.click()
        time.sleep(0.5)
        tipo_bem.send_keys("AUTOMÓVEIS")
        tipo_bem.send_keys(Keys.RETURN)
        time.sleep(1)
        
        marca = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbMarca")))
        marca.click()
        time.sleep(0.5)
        marca.send_keys("VOLKSWAGEN")
        marca.send_keys(Keys.RETURN)
        time.sleep(1)
        
        ano_modelo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbAnoModelo")))
        ano_modelo.click()
        time.sleep(0.5)
        ano_modelo.send_keys("2012")
        ano_modelo.send_keys(Keys.RETURN)
        time.sleep(1)
        
        ano_fabricacao = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbAnoFabricacao")))
        ano_fabricacao.click()
        time.sleep(0.5)
        ano_fabricacao.send_keys("2011")
        ano_fabricacao.send_keys(Keys.RETURN)
        time.sleep(1)
        
        modelo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbModelo")))
        modelo.click()
        time.sleep(0.5)
        modelo.send_keys("GOL FLEX COM")
        modelo.send_keys(Keys.RETURN)
        time.sleep(1)
        
        versao = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbVersao")))
        versao.click()
        time.sleep(0.5)
        versao.send_keys("(TREND)G4 1.0 8V A/G 4P")
        versao.send_keys(Keys.RETURN)
        time.sleep(1)
        
        combustivel = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbCombustivel")))
        combustivel.click()
        time.sleep(0.5)
        combustivel.send_keys("FLEX-GASOLINA")
        combustivel.send_keys(Keys.RETURN)
        time.sleep(1)
        
        uf_licenciamento = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbUfLicenciamento")))
        uf_licenciamento.click()
        time.sleep(0.5)
        uf_licenciamento.send_keys("DF - Distrito Federal")
        uf_licenciamento.send_keys(Keys.RETURN)
        time.sleep(1)
        
        valor_bem = driver.find_element(By.ID, "frm:valorBem")
        valor_bem.send_keys("2800000")  # Corrigido para incluir centavos
        valor_bem.send_keys(Keys.TAB)
        time.sleep(1)
        
        valor_entrada = driver.find_element(By.ID, "frm:valorEntrada")
        valor_entrada.send_keys("1400000")  # Corrigido para incluir centavos
        valor_entrada.send_keys(Keys.TAB)
        time.sleep(1)
        
        consultar_btn = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:botaoConsultar")))
        consultar_btn.click()
        
        # Adicionar espera de 12 segundos após clicar em "Consultar"
        time.sleep(12)

    except Exception as e:
        print(f"Ocorreu um erro ao preencher os dados do veículo: {e}")

def preencher_condicoes_negocio(driver):
    try:
        driver.find_element(By.ID, "cmbTabelaFaixaProdutoCdc").click()
        dropdown = driver.find_element(By.ID, "cmbTabelaFaixaProdutoCdc")
        dropdown.find_element(By.XPATH, "//option[. = '50,00% | 51741040 | 2.08 | TAB PBR - NET']").click()
        driver.find_element(By.CSS_SELECTOR, "#cmbTabelaFaixaProdutoCdc > option:nth-child(2)").click()
        driver.find_element(By.ID, "cmbCarencia").click()
        dropdown = driver.find_element(By.ID, "cmbCarencia")
        dropdown.find_element(By.XPATH, "//option[. = '12/07/2024']").click()
        driver.find_element(By.CSS_SELECTOR, "#cmbCarencia > option:nth-child(4)").click()
        driver.find_element(By.ID, "frm:valorRetorno").click()
        driver.find_element(By.ID, "frm:valorRetorno").send_keys("3,6")
        driver.find_element(By.ID, "frm:botaoAvancar").click()
        
    except Exception as e:
        print(f"Ocorreu um erro ao preencher as condições de negócio: {e}")

def main():
    try:
        with open('temp_cpf.txt', 'r') as file:
            cpf_cnpj = file.read().strip()
    except FileNotFoundError:
        print("Arquivo temp_cpf.txt não encontrado.")
        return

    driver = webdriver.Firefox()
    driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")
    
    try:
        usuario = "V01042.44774"
        senha = "bradesco"

        usuario_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
        )
        usuario_input.send_keys(usuario)
        usuario_input.send_keys(Keys.TAB)
        time.sleep(1)

        senha_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
        )
        senha_input.send_keys(senha)
        senha_input.send_keys(Keys.RETURN)
        time.sleep(3)

        incluir_proposta_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="topmenu_2"]'))
        )
        incluir_proposta_link.click()
        time.sleep(3)

        WebDriverWait(driver, 10).until(EC.frame_to_be_available_and_switch_to_it((By.TAG_NAME, 'iframe')))

        radio_botao = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.NAME, "frm:radioAgenteCertificado"))
        )
        radio_botao.click()
        time.sleep(1)
        
        btn_avancar = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "frm:btnAvancarConsultaPrevia"))
        )
        btn_avancar.click()
        time.sleep(3)

        inserir_cpf_digito_a_digito(driver, cpf_cnpj)
        preencher_dados_veiculo(driver)
        
        # Adicionar espera de 12 segundos após preencher os dados do veículo e clicar em "Consultar"
        time.sleep(12)
        
        # Preencher condições de negócio
        preencher_condicoes_negocio(driver)
        
        time.sleep(5)

    except Exception as e:
        print(f"Ocorreu um erro: {e}")
    finally:
        # Manter o navegador aberto para próximas etapas manuais
        print("Navegador estará aberto para próximas etapas manuais. Não será fechado automaticamente.")
        
if __name__ == "__main__":
    main()
