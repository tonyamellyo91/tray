import time
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def inserir_cpf_graduadamente(campo, cpf):
    for i in range(0, len(cpf), 3):
        campo.send_keys(cpf[i:i+3])
        time.sleep(0.5)  # Ajuste o intervalo conforme necessário

# Argumentos passados do script bash
cpf_cnpj = sys.argv[1]

# Inicializar o navegador
driver = webdriver.Firefox()
driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")

try:
    # Credenciais de login
    usuario = "V01042.44774"
    senha = "bradesco"

    # Esperar até que o campo de usuário esteja presente e seja visível
    usuario_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
    )
    usuario_input.send_keys(usuario)

    # Pressionar TAB para mover para o próximo campo (senha)
    usuario_input.send_keys(Keys.TAB)

    # Esperar até que o campo de senha esteja presente e seja visível
    senha_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
    )
    senha_input.send_keys(senha)

    # Enviar o formulário de login
    senha_input.send_keys(Keys.RETURN)

    # Esperar até que o link para "Incluir Proposta" esteja presente e seja clicável
    incluir_proposta_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="topmenu_2"]'))
    )

    # Clicar no link "Incluir Proposta"
    incluir_proposta_link.click()

    # Trocar para o frame necessário
    WebDriverWait(driver, 10).until(EC.frame_to_be_available_and_switch_to_it((By.TAG_NAME, 'iframe')))
    
    # Clicar no botão de rádio e no botão para avançar
    radio_botao = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.NAME, "frm:radioAgenteCertificado"))
    )
    radio_botao.click()
    
    btn_avancar = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "frm:btnAvancarConsultaPrevia"))
    )
    btn_avancar.click()
    
    # Interação com o campo CPF
    campo_cpf = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "frm:txtCPF1"))
    )
    campo_cpf.click()

    # Inserir o CPF gradualmente
    inserir_cpf_graduadamente(campo_cpf, cpf_cnpj)

    # Avançar após inserir o CPF
    btn_avancar_cpf = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "frm:btnAvancarCpf"))
    )
    btn_avancar_cpf.click()

    # Aguardar o próximo passo manual

finally:
    print("Navegador estará aberto para próximas etapas manuais. Não será fechado automaticamente.")
