#!bin/bash
echo -e "$(cat analisepersonalizada.txt)"
