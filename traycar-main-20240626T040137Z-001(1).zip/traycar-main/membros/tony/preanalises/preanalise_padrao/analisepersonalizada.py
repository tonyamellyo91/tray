\e[1;33m\e[0m\e[1;33m  \e[0m\e[1;96m\e[0m\e[1;96m  _________________________________________\e[0m

   \e[1;33m\e[0m\e[1;33m *** \e[0m\e[1;96m\e[0m\e[1;96m  Selecione uma personalização\e[1;33m  ***\e[0m
\e[1;33m\e[0m\e[1;33m  \e[0m\e[1;96m\e[0m\e[1;96m  _________________________________________\e[0m


\e[1;33m01\e[0m - \e[1;96mPré aprovado\e[0m
\e[1;33m02\e[0m - \e[1;96mCliente aceito na mesa de avaliação\e[0m
\e[1;33m03\e[0m - \e[1;96mCliente não enquadrado nos critérios\e[0m
