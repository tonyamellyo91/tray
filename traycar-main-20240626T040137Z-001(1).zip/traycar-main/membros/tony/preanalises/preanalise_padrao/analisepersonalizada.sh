#!bin/bash
clear
bash tray-logo.sh
echo""
echo""
echo -e "$(cat analisepersonalizada.txt)"
echo ""
echo ""
echo ""
echo ""
	read -p $'\e[1;91mEscolha uma opcao: \e[0m' perso_option
        case $perso_option in
             01|1)
                read -p $'\e[1;40m\e[96m Opção 1 selecionada. \e[0m'
		dirname=$(cat temp_cpf.txt)
		read -p "Digite o nome do diretório a ser criado: " dirname
                mkdir -p "$dirname"
    	        cd "$dirname"
      	        echo "Diretório '$dirname' criado e navegado com sucesso."
                ;;

            02|2)
                read -p read -p $'\e[1;40m\e[96m Opção 2 selecionada. \e[0m'
		;;
	    03|3)
                read -p read -p $'\e[1;40m\e[96m Opção 3 selecionada. \e[0m'
                # Lógica adicional para personalização será necessária.
		;;
             *)
                    echo -e $'\e[1;33mOpção inválida\e[0m'
                    exit 1
                    ;;
          esac

