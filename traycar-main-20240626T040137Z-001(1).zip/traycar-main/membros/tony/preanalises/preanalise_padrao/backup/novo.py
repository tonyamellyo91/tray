import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

def inserir_cpf_digito_a_digito(driver, cpf):
    partes = [cpf[:3], cpf[3:6], cpf[6:9], cpf[9:]]
    ids_campos_cpf = ["frm:txtCPF1", "frm:txtCPF2", "frm:txtCPF3", "frm:txtCPF4"]

    for parte, id_campo in zip(partes, ids_campos_cpf):
        campo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, id_campo)))
        campo.click()

        for digito in parte:
            campo.send_keys(digito)
            time.sleep(0.2)

        campo.send_keys(Keys.TAB)
        time.sleep(0.2)

    campo.send_keys(Keys.RETURN)

def preencher_dados_veiculo(driver):
    try:
        tipo_bem = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbTiposBem")))
        tipo_bem.click()
        tipo_bem.send_keys("AUTOMÓVEIS")
        tipo_bem.send_keys(Keys.RETURN)

        marca = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbMarca")))
        marca.click()
        marca.send_keys("VOLKSWAGEN")
        marca.send_keys(Keys.RETURN)

        ano_modelo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbAnoModelo")))
        ano_modelo.click()
        ano_modelo.send_keys("2012")
        ano_modelo.send_keys(Keys.RETURN)

        ano_fabricacao = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbAnoFabricacao")))
        ano_fabricacao.click()
        ano_fabricacao.send_keys("2011")
        ano_fabricacao.send_keys(Keys.RETURN)

        modelo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbModelo")))
        modelo.click()
        modelo.send_keys("GOL FLEX COM")
        modelo.send_keys(Keys.RETURN)

        versao = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbVersao")))
        versao.click()
        versao.send_keys("(TREND)G4 1.0 8V A/G 4P")
        versao.send_keys(Keys.RETURN)

        combustivel = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbCombustivel")))
        combustivel.click()
        combustivel.send_keys("FLEX-GASOLINA")
        combustivel.send_keys(Keys.RETURN)

        uf_licenciamento = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbUfLicenciamento")))
        uf_licenciamento.click()
        uf_licenciamento.send_keys("DF - Distrito Federal")
        uf_licenciamento.send_keys(Keys.RETURN)

        valor_bem = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:valorBem")))
        valor_bem.send_keys("2800000")  # Corrigido para incluir centavos

        valor_entrada = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:valorEntrada")))
        valor_entrada.send_keys("1400000")  # Corrigido para incluir centavos

        consultar_btn = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:botaoConsultar")))
        consultar_btn.click()

        WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID, "frm:carne")))

    except Exception as e:
        print(f"Ocorreu um erro ao preencher os dados do veículo: {e}")

def preencher_condicoes_negocio(driver):
    try:
        driver.find_element(By.ID, "frm:carne").click()

        tabela = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbTabelaFaixaProdutoCdc")))
        tabela.click()
        tabela.send_keys("50")
        time.sleep(0.5)
        tabela.send_keys(Keys.RETURN)

        vencimento_parcela = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbCarencia")))
        vencimento_parcela.click()
        vencimento_parcela.send_keys(Keys.DOWN)
        vencimento_parcela.send_keys(Keys.DOWN)
        vencimento_parcela.send_keys(Keys.RETURN)

        valor_retorno = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:valorRetorno")))
        valor_retorno.click()
        valor_retorno.send_keys("3,6")

        btn_avancar = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:botaoAvancar")))
        btn_avancar.click()

    except Exception as e:
        print(f"Ocorreu um erro ao preencher as condições de negócio: {e}")

def capturar_resultado(driver, diretorio):
    try:
        miolo = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, "miolo")))
        resultado_texto = miolo.text

        # Determina o perfil do cliente
        if "proposta será encaminhada para análise" in resultado_texto.lower():
            perfil_cliente = "Proposta será encaminhada para análise"
        elif "Pré-aprovado" in resultado_texto:
            perfil_cliente = "Pré-aprovado"
        elif "Reprovado" in resultado_texto:
            perfil_cliente = "Reprovado"
        else:
            perfil_cliente = "Desconhecido"

        print(f"Perfil do cliente: {perfil_cliente}")

        screenshot_path = os.path.join(diretorio, 'resultado_pre_analise.png')
        miolo.screenshot(screenshot_path)
        return perfil_cliente

    except Exception as e:
        print(f"Ocorreu um erro ao capturar o resultado da pré-análise: {e}")
        return None

def main():
    try:
        with open('temp_cpf.txt', 'r') as file:
            cpf_cnpj = file.read().strip()
    except FileNotFoundError:
        print("Arquivo temp_cpf.txt não encontrado.")
        return

    # Criação do diretório com o nome do CPF
    diretorio = os.path.join(os.getcwd(), cpf_cnpj)
    if not os.path.exists(diretorio):
        os.makedirs(diretorio)
    
    driver = webdriver.Firefox()
    driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")

    try:
        usuario = "V01042.44774"
        senha = "bradesco"

        usuario_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
        )
        usuario_input.send_keys(usuario)
        usuario_input.send_keys(Keys.TAB)

        senha_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
        )
        senha_input.send_keys(senha)
        senha_input.send_keys(Keys.RETURN)

        incluir_proposta_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="topmenu_2"]'))
        )
        incluir_proposta_link.click()

        WebDriverWait(driver, 10).until(EC.frame_to_be_available_and_switch_to_it((By.TAG_NAME, 'iframe')))

        radio_botao = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.NAME, "frm:radioAgenteCertificado"))
        )
        radio_botao.click()

        btn_avancar = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "frm:btnAvancarConsultaPrevia"))
        )
        btn_avancar.click()

        inserir_cpf_digito_a_digito(driver, cpf_cnpj)
        preencher_dados_veiculo(driver)
        preencher_condicoes_negocio(driver)

        perfil_cliente = capturar_resultado(driver, diretorio)

        if perfil_cliente:
            print(f"CPF: {cpf_cnpj} - Perfil do cliente: {perfil_cliente}")
        else:
            print("Falha ao determinar o perfil do cliente.")

    except Exception as e:
        print(f"Ocorreu um erro: {e}")
    finally:
        driver.quit()
        # Pergunta ao usuário sobre personalização
        personalizar = input("Você quer personalizar o resultado? (S/N) ").strip().lower()
        if personalizar == 's':
            with open('analisepersonalizada.txt', 'r') as file:
                conteudo = file.read()
                print(conteudo)  # a função print já faz o echo com as cores
            opcao = input("Escolha o tipo de personalização da análise:\n1. Pré-aprovado\n2. Cliente aceito na mesa de avaliação\n").strip()
            if opcao == '1':
                # Aqui você pode chamar outro script ou continuar a lógica para personalizar o resultado.
                print("Opção 1 selecionada.")
                # Lógica adicional para personalização será necessária.
            elif opcao == '2':
                print("Opção 2 selecionada.")
                # Lógica adicional para personalização será necessária.

if __name__ == "__main__":
    main()
