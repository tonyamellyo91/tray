#!/bin/bash
# Verificar e instalar dependências necessárias
if ! command -v python3 &> /dev/null
then
    echo "Python3 não encontrado. Instalando..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip
fi

if ! pip3 show selenium &> /dev/null
then
    echo "Selenium não encontrado. Instalando..."
    pip3 install selenium
fi

if ! command -v geckodriver &> /dev/null
then
    echo "Geckodriver não encontrado. Instalando..."
    sudo apt-get install -y firefox-geckodriver
fi

# Ler o CPF do arquivo temp_cpf.txt
if [ -f temp_cpf.txt ]; then
    cpf=$(cat temp_cpf.txt)
else
    echo "Arquivo temp_cpf.txt não encontrado."
    exit 1
fi

# Criar script Python para automação
cat <<EOF > automate.py
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Argumentos passados do script bash
cpf_cnpj = sys.argv[1]

# Inicializar o navegador
driver = webdriver.Firefox()
driver.get('https://www.situacao-cadastral.com')

try:
    # Esperar até que o campo de entrada esteja presente
    input_field = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.ID, 'doc'))
    )
    # Inserir o CPF/CNPJ
    input_field.send_keys(cpf_cnpj)
    
    # Encontrar e clicar no botão de consulta
    submit_button = driver.find_element(By.ID, 'consultar')
    submit_button.click()

    # Esperar os resultados serem carregados
    name_element = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, '//span[@class="dados nome"]'))
    )
    status_element = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, '//span[@class="dados situacao"]/span'))
    )

    # Extrair os dados do resultado
    name = name_element.text
    status = status_element.text

    # Escrever os dados em um arquivo de saída
    output_filename = f'{name.replace(" ", "_")}.txt'
    with open(output_filename, 'w') as file:
        file.write(f'{name}\n{status}')

    print(f'Resultado salvo em {output_filename}')

finally:
    # Fechar o navegador
    driver.quit()
EOF

# Executar o script Python
python3 automate.py "$cpf"
