import os
import time
import io
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from PIL import Image

def inserir_cpf_digito_a_digito(driver, cpf):
    partes = [cpf[:3], cpf[3:6], cpf[6:9], cpf[9:]]
    ids_campos_cpf = ["frm:txtCPF1", "frm:txtCPF2", "frm:txtCPF3", "frm:txtCPF4"]

    for parte, id_campo in zip(partes, ids_campos_cpf):
        campo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, id_campo)))
        campo.click()

        for digito in parte:
            campo.send_keys(digito)
            time.sleep(0.2)
        
        campo.send_keys(Keys.TAB)
        time.sleep(0.2)

    campo.send_keys(Keys.RETURN)

def preencher_dados_veiculo(driver):
    try:
        tipo_bem = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbTiposBem")))
        tipo_bem.click()
        tipo_bem.send_keys("AUTOMÓVEIS")
        tipo_bem.send_keys(Keys.RETURN)

        marca = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbMarca")))
        marca.click()
        marca.send_keys("VOLKSWAGEN")
        marca.send_keys(Keys.RETURN)

        ano_modelo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbAnoModelo")))
        ano_modelo.click()
        ano_modelo.send_keys("2012")
        ano_modelo.send_keys(Keys.RETURN)

        ano_fabricacao = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbAnoFabricacao")))
        ano_fabricacao.click()
        ano_fabricacao.send_keys("2011")
        ano_fabricacao.send_keys(Keys.RETURN)

        modelo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbModelo")))
        modelo.click()
        modelo.send_keys("GOL FLEX COM")
        modelo.send_keys(Keys.RETURN)

        versao = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbVersao")))
        versao.click()
        versao.send_keys("(TREND)G4 1.0 8V A/G 4P")
        versao.send_keys(Keys.RETURN)

        combustivel = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbCombustivel")))
        combustivel.click()
        combustivel.send_keys("FLEX-GASOLINA")
        combustivel.send_keys(Keys.RETURN)

        uf_licenciamento = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbUfLicenciamento")))
        uf_licenciamento.click()
        uf_licenciamento.send_keys("DF - Distrito Federal")
        uf_licenciamento.send_keys(Keys.RETURN)

        valor_bem = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:valorBem")))
        valor_bem.send_keys("2800000")

        valor_entrada = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:valorEntrada")))
        valor_entrada.send_keys("1400000")

        consultar_btn = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:botaoConsultar")))
        consultar_btn.click()
        
        WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID, "frm:carne")))

    except Exception as e:
        print(f"Ocorreu um erro ao preencher os dados do veículo: {e}")

def preencher_condicoes_negocio(driver):
    try:
        driver.find_element(By.ID, "frm:carne").click()

        tabela = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbTabelaFaixaProdutoCdc")))
        tabela.click()
        tabela.send_keys("50")
        time.sleep(0.5)
        tabela.send_keys(Keys.RETURN)
        
        vencimento_parcela = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "cmbCarencia")))
        vencimento_parcela.click()
        vencimento_parcela.send_keys(Keys.DOWN)
        vencimento_parcela.send_keys(Keys.DOWN)
        vencimento_parcela.send_keys(Keys.RETURN)

        valor_retorno = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:valorRetorno")))
        valor_retorno.click()
        valor_retorno.send_keys("3,6")

        btn_avancar = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "frm:botaoAvancar")))
        btn_avancar.click()

    except Exception as e:
        print(f"Ocorreu um erro ao preencher as condições de negócio: {e}")

def definir_zoom(driver, percentual):
    driver.execute_script(f"document.body.style.zoom='{percentual}%'")
    time.sleep(2)

def capturar_area_analise(driver, diretorio):
    try:
        analise_text = WebDriverWait(driver, 20).until(
            EC.visibility_of_element_located((By.XPATH, "//*[contains(text(), 'PRÉ-APROVADO') or contains(text(), 'Não enquadrado nas normas de crédito') or contains(text(), 'Proposta será encaminhada para análise do crédito')]"))
        )
        
        driver.execute_script("arguments[0].scrollIntoView();", analise_text)
        time.sleep(2)

        tela = driver.get_screenshot_as_png()

        localizacao = analise_text.location
        tamanho = analise_text.size

        x = localizacao['x']
        y = localizacao['y']
        largura = tamanho['width']
        altura = tamanho['height']

        imagem = Image.open(io.BytesIO(tela))
        imagem_cortada = imagem.crop((x, y, x + largura, y + altura))

        caminho_screenshot = os.path.join(diretorio, 'resultado_analise.png')
        imagem_cortada.save(caminho_screenshot)

        print(f"Captura de tela da área de pré-análise salva em: {caminho_screenshot}")

        texto_analise = analise_text.text

        if "PRÉ-APROVADO" in texto_analise:
            perfil = "Perfil do cliente: Pré-aprovado"
        elif "Não enquadrado nas normas de crédito" in texto_analise:
            perfil = "Perfil do cliente: Reprovado"
        elif "Proposta será encaminhada para análise do crédito" in texto_analise:
            perfil = "Perfil do cliente: Cliente aceito nos critérios para avaliação, a ficha será encaminhada para mesa"
        else:
            perfil = "Perfil do cliente: Desconhecido"

        perfil_path = os.path.join(diretorio, 'perfil_cliente.txt')
        
        with open(perfil_path, 'w') as file:
            file.write(perfil)
        
        print(f"Perfil do cliente salvo em: {perfil_path}")

    except Exception as e:
        print(f"Ocorreu um erro ao capturar a tela de pré-análise: {e}")

def main():
    try:
        with open('temp_cpf.txt', 'r') as file:
            cpf_cnpj = file.read().strip()
    except FileNotFoundError:
        print("Arquivo temp_cpf.txt não encontrado.")
        return

    # Criação do diretório com o nome do CPF
    diretorio = os.path.join(os.getcwd(), cpf_cnpj)
    if not os.path.exists(diretorio):
        os.makedirs(diretorio)
        print(f"Diretório {diretorio} criado com sucesso.")
    else:
        print(f"Diretório {diretorio} já existe.")

    driver = webdriver.Firefox()
    driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")

    try:
        usuario = "V01042.44774"
        senha = "bradesco"

        usuario_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
        )
        usuario_input.send_keys(usuario)
        usuario_input.send_keys(Keys.TAB)

        senha_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
        )
        senha_input.send_keys(senha)
        senha_input.send_keys(Keys.RETURN)

        incluir_proposta_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="topmenu_2"]'))
        )
        incluir_proposta_link.click()

        WebDriverWait(driver, 10).until(EC.frame_to_be_available_and_switch_to_it((By.TAG_NAME, 'iframe')))

        radio_botao = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.NAME, "frm:radioAgenteCertificado"))
        )
        radio_botao.click()

        btn_avancar = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "frm:btnAvancarConsultaPrevia"))
        )
        btn_avancar.click()

        inserir_cpf_digito_a_digito(driver, cpf_cnpj)
        preencher_dados_veiculo(driver)
        preencher_condicoes_negocio(driver)

        # Definir o zoom para 50%
        definir_zoom(driver, 50)

        # Capturar área de análise e salvar no diretório
        capturar_area_analise(driver, diretorio)

    except Exception as e:
        print(f"Ocorreu um erro: {e}")
    finally:
        print("Fechando o navegador.")
        driver.quit()

if __name__ == "__main__":
    main()
