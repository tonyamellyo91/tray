from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Credenciais de login
usuario = "V01042.44774"
senha = "bradesco"

# Inicializar o navegador
driver = webdriver.Firefox()
driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")

try:
    # Esperar até que o campo de usuário esteja presente e seja visível
    usuario_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
    )
    usuario_input.send_keys(usuario)

    # Pressionar TAB para mover para o próximo campo (senha)
    usuario_input.send_keys(Keys.TAB)

    # Esperar até que o campo de senha esteja presente e seja visível
    senha_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
    )
    senha_input.send_keys(senha)

    # Enviar o formulário de login
    senha_input.send_keys(Keys.RETURN)

    # Esperar até que o link para "Incluir Proposta" esteja presente e seja clicável
    incluir_proposta_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="topmenu_2"]'))
    )

    # Clicar no link "Incluir Proposta"
    incluir_proposta_link.click()

    # Aqui você pode adicionar mais etapas para serem executadas na página "Incluir Proposta"

except Exception as e:
    print(f"Erro: {e}")

# Não fechar o navegador automaticamente
# Outras ações podem ser adicionadas aqui
