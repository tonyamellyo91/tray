import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def inserir_cpf_digito_a_digito(driver, cpf):
    # Dividir o CPF em partes
    partes = [cpf[:3], cpf[3:6], cpf[6:9], cpf[9:]]
    
    # IDs dos campos de CPF
    ids_campos_cpf = ["frm:txtCPF1", "frm:txtCPF2", "frm:txtCPF3", "frm:txtCPF4"]
    
    for parte, id_campo in zip(partes, ids_campos_cpf):
        campo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, id_campo)))
        campo.click()
        
        for digito in parte:
            campo.send_keys(digito)
            time.sleep(0.2)  # Ajuste o intervalo conforme necessário para replicar a digitação humana

        # Pressionar TAB se não for o último campo
        if id_campo != ids_campos_cpf[-1]:
            campo.send_keys(Keys.TAB)
        else:
            campo.send_keys(Keys.RETURN)
    
    # Pausa após a inserção completa do CPF
    time.sleep(0.2)

# Ler o CPF do arquivo temp_cpf.txt
try:
    with open('temp_cpf.txt', 'r') as file:
        cpf_cnpj = file.read().strip()
except FileNotFoundError:
    print("Arquivo temp_cpf.txt não encontrado.")
    exit(1)

# Inicializar o navegador
driver = webdriver.Firefox()
driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")

try:
    # Credenciais de login
    usuario = "V01042.44774"
    senha = "bradesco"

    # Esperar até que o campo de usuário esteja presente e seja visível
    usuario_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
    )
    usuario_input.send_keys(usuario)

    # Pressionar TAB para mover para o próximo campo (senha)
    usuario_input.send_keys(Keys.TAB)

    # Esperar até que o campo de senha esteja presente e seja visível
    senha_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
    )
    senha_input.send_keys(senha)

    # Enviar o formulário de login
    senha_input.send_keys(Keys.RETURN)

    # Esperar até que o link para "Incluir Proposta" esteja presente e seja clicável
    incluir_proposta_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="topmenu_2"]'))
    )
    incluir_proposta_link.click()

    # Trocar para o frame necessário
    WebDriverWait(driver, 10).until(EC.frame_to_be_available_and_switch_to_it((By.TAG_NAME, 'iframe')))

    # Clicar no botão de rádio e no botão para avançar
    radio_botao = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.NAME, "frm:radioAgenteCertificado"))
    )
    radio_botao.click()

    btn_avancar = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "frm:btnAvancarConsultaPrevia"))
    )
    btn_avancar.click()

    # Inserção digito a digito do CPF
    inserir_cpf_digito_a_digito(driver, cpf_cnpj)

except Exception as e:
    print(f"Ocorreu um erro: {e}")
finally:
    # Manter o navegador aberto para próximas etapas manuais
    print("Navegador estará aberto para próximas etapas manuais. Não será fechado automaticamente.")
    #driver.quit()  # Descomente se desejar fechar o navegador automaticamente
