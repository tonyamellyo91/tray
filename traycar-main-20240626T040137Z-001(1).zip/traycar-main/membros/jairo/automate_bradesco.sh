#!/bin/bash

# Verificar e instalar dependências necessárias
if ! command -v python3 &> /dev/null
then
    echo "Python3 não encontrado. Instalando..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip
fi

if ! pip3 show selenium &> /dev/null
then
    echo "Selenium não encontrado. Instalando..."
    pip3 install selenium
fi

if ! command -v geckodriver &> /dev/null
then
    echo "Geckodriver não encontrado. Instalando..."
    sudo apt-get install -y firefox-geckodriver
fi

# Credenciais criptografadas
usuario_enc="VjAxMDQyLjQ0Nzc0"
senha_enc="YnJhZGVzY28="

# Função para descriptografar as credenciais
descriptografar_credenciais() {
    usuario=$(echo "$1" | base64 --decode)
    senha=$(echo "$2" | base64 --decode)
}

# Descriptografar as credenciais
descriptografar_credenciais "$usuario_enc" "$senha_enc"

# Criar script Python para automação de login
cat <<EOF > automate_bradesco.py
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Credenciais de login
usuario = "$usuario"
senha = "$senha"

# Inicializar o navegador
driver = webdriver.Firefox()
driver.get("https://wwwsn.bradescofinanciamentos.com.br/finilojmobile/#/login-beta")

try:
    # Esperar até que o campo de usuário esteja presente e seja visível
    usuario_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="username"]'))
    )
    usuario_input.send_keys(usuario)

    # Pressionar TAB para mover para o próximo campo (senha)
    usuario_input.send_keys(Keys.TAB)

    # Esperar até que o campo de senha esteja presente e seja visível
    senha_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="password"]'))
    )
    senha_input.send_keys(senha)

    # Enviar o formulário de login
    senha_input.send_keys(Keys.RETURN)

except Exception as e:
    print(f"Erro: {e}")

# O navegador não será fechado automaticamente
EOF

# Executar o script Python
python3 automate_bradesco.py
